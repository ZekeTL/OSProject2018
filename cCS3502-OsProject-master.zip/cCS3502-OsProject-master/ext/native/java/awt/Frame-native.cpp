// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar
#include <java/awt/Frame.hpp>

extern void unimplemented_(const char16_t* name);

/* private: void java::awt::Frame::initIDs() */
