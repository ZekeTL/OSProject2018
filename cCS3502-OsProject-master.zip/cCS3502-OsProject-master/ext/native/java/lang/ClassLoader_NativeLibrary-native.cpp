// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar
#include <java/lang/ClassLoader_NativeLibrary.hpp>

extern void unimplemented_(const char16_t* name);

int64_t java::lang::ClassLoader_NativeLibrary::find(String* arg0)
{ /* native */
    unimplemented_(u"int64_t java::lang::ClassLoader_NativeLibrary::find(String* arg0)");
    return 0;
}

void java::lang::ClassLoader_NativeLibrary::load(String* arg0, bool arg1)
{ /* native */
    unimplemented_(u"void java::lang::ClassLoader_NativeLibrary::load(String* arg0, bool arg1)");
}

void java::lang::ClassLoader_NativeLibrary::unload(String* arg0, bool arg1)
{ /* native */
    unimplemented_(u"void java::lang::ClassLoader_NativeLibrary::unload(String* arg0, bool arg1)");
}

