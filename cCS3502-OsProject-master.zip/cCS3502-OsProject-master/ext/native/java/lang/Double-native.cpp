// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar
#include <java/lang/Double.hpp>

extern void unimplemented_(const char16_t* name);

int64_t java::lang::Double::doubleToRawLongBits(double arg0)
{ /* native */
    clinit();
    unimplemented_(u"int64_t java::lang::Double::doubleToRawLongBits(double arg0)");
    return 0;
}

double java::lang::Double::longBitsToDouble(int64_t arg0)
{ /* native */
    clinit();
    unimplemented_(u"double java::lang::Double::longBitsToDouble(int64_t arg0)");
    return 0;
}

