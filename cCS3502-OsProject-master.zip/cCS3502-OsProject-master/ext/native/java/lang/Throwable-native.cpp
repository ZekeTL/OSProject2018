// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar
#include <java/lang/Throwable.hpp>

extern void unimplemented_(const char16_t* name);

/* private: java::lang::Throwable* java::lang::Throwable::fillInStackTrace(int32_t arg0) */
int32_t java::lang::Throwable::getStackTraceDepth()
{ /* native */
    unimplemented_(u"int32_t java::lang::Throwable::getStackTraceDepth()");
    return 0;
}

java::lang::StackTraceElement* java::lang::Throwable::getStackTraceElement(int32_t arg0)
{ /* native */
    unimplemented_(u"java::lang::StackTraceElement* java::lang::Throwable::getStackTraceElement(int32_t arg0)");
    return 0;
}

