// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar
#include <java/lang/ClassLoader.hpp>

extern void unimplemented_(const char16_t* name);

/* private: java::lang::Class* java::lang::ClassLoader::defineClass0(String* arg0, ::int8_tArray* arg1, int32_t arg2, int32_t arg3, ::java::security::ProtectionDomain* arg4) */
/* private: java::lang::Class* java::lang::ClassLoader::defineClass1(String* arg0, ::int8_tArray* arg1, int32_t arg2, int32_t arg3, ::java::security::ProtectionDomain* arg4, String* arg5) */
/* private: java::lang::Class* java::lang::ClassLoader::defineClass2(String* arg0, ::java::nio::ByteBuffer* arg1, int32_t arg2, int32_t arg3, ::java::security::ProtectionDomain* arg4, String* arg5) */
/* private: java::lang::Class* java::lang::ClassLoader::findBootstrapClass(String* arg0) */
/* private: java::lang::String* java::lang::ClassLoader::findBuiltinLib(String* arg0) */
/* private: java::lang::Class* java::lang::ClassLoader::findLoadedClass0(String* arg0) */
/* private: void java::lang::ClassLoader::registerNatives() */
/* private: void java::lang::ClassLoader::resolveClass0(Class* arg0) */
/* private: java::lang::AssertionStatusDirectives* java::lang::ClassLoader::retrieveDirectives() */
