// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar
#include <java/lang/Object.hpp>

extern void unimplemented_(const char16_t* name);

java::lang::Object* java::lang::Object::clone()
{ /* native */
    unimplemented_(u"java::lang::Object* java::lang::Object::clone()");
    return 0;
}

java::lang::Class* java::lang::Object::getClass()
{ /* native */
    unimplemented_(u"java::lang::Class* java::lang::Object::getClass()");
    return 0;
}

int32_t java::lang::Object::hashCode()
{ /* native */
    unimplemented_(u"int32_t java::lang::Object::hashCode()");
    return 0;
}

void java::lang::Object::notify()
{ /* native */
    unimplemented_(u"void java::lang::Object::notify()");
}

void java::lang::Object::notifyAll()
{ /* native */
    unimplemented_(u"void java::lang::Object::notifyAll()");
}

/* private: void java::lang::Object::registerNatives() */
void java::lang::Object::wait(int64_t timeout)
{ /* native */
    unimplemented_(u"void java::lang::Object::wait(int64_t timeout)");
}

