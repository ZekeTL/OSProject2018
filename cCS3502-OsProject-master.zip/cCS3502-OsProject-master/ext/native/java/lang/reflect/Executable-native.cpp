// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar
#include <java/lang/reflect/Executable.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace lang
    {
        namespace reflect
        {
typedef ::SubArray< ::java::lang::reflect::AnnotatedElement, ::java::lang::ObjectArray > AnnotatedElementArray;
typedef ::SubArray< ::java::lang::reflect::Parameter, ::java::lang::ObjectArray, AnnotatedElementArray > ParameterArray;
        } // reflect
    } // lang
} // java

extern void unimplemented_(const char16_t* name);

/* private: java::lang::reflect::ParameterArray* java::lang::reflect::Executable::getParameters0() */
int8_tArray* java::lang::reflect::Executable::getTypeAnnotationBytes0()
{ /* native */
    unimplemented_(u"int8_tArray* java::lang::reflect::Executable::getTypeAnnotationBytes0()");
    return 0;
}

