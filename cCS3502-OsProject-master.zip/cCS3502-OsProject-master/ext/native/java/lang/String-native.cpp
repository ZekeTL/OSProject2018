// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar
#include <java/lang/String.hpp>

extern void unimplemented_(const char16_t* name);

java::lang::String* java::lang::String::intern()
{ /* native */
    unimplemented_(u"java::lang::String* java::lang::String::intern()");
    return 0;
}

