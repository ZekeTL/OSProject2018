// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar
#include <java/lang/System.hpp>

extern void unimplemented_(const char16_t* name);

void java::lang::System::arraycopy(Object* src, int32_t srcPos, Object* dest, int32_t destPos, int32_t length)
{ /* native */
    clinit();
    unimplemented_(u"void java::lang::System::arraycopy(Object* src, int32_t srcPos, Object* dest, int32_t destPos, int32_t length)");
}

int64_t java::lang::System::currentTimeMillis()
{ /* native */
    clinit();
    unimplemented_(u"int64_t java::lang::System::currentTimeMillis()");
    return 0;
}

int32_t java::lang::System::identityHashCode(Object* x)
{ /* native */
    clinit();
    unimplemented_(u"int32_t java::lang::System::identityHashCode(Object* x)");
    return 0;
}

/* private: java::util::Properties* java::lang::System::initProperties(::java::util::Properties* arg0) */
java::lang::String* java::lang::System::mapLibraryName(String* libname)
{ /* native */
    clinit();
    unimplemented_(u"java::lang::String* java::lang::System::mapLibraryName(String* libname)");
    return 0;
}

int64_t java::lang::System::nanoTime()
{ /* native */
    clinit();
    unimplemented_(u"int64_t java::lang::System::nanoTime()");
    return 0;
}

/* private: void java::lang::System::registerNatives() */
/* private: void java::lang::System::setErr0(::java::io::PrintStream* arg0) */
/* private: void java::lang::System::setIn0(::java::io::InputStream* arg0) */
/* private: void java::lang::System::setOut0(::java::io::PrintStream* arg0) */
