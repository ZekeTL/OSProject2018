// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct javax::accessibility::Accessible
    : public virtual ::java::lang::Object
{

    virtual AccessibleContext* getAccessibleContext() = 0;

    // Generated
    static ::java::lang::Class *class_();
};
