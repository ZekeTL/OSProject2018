// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct javax::accessibility::AccessibleText
    : public virtual ::java::lang::Object
{
    static constexpr int32_t CHARACTER { int32_t(1) };
    static constexpr int32_t SENTENCE { int32_t(3) };
    static constexpr int32_t WORD { int32_t(2) };

    virtual ::java::lang::String* getAfterIndex(int32_t arg0, int32_t arg1) = 0;
    virtual ::java::lang::String* getAtIndex(int32_t arg0, int32_t arg1) = 0;
    virtual ::java::lang::String* getBeforeIndex(int32_t arg0, int32_t arg1) = 0;
    virtual int32_t getCaretPosition() = 0;
    virtual int32_t getCharCount() = 0;
    virtual ::javax::swing::text::AttributeSet* getCharacterAttribute(int32_t arg0) = 0;
    virtual ::java::awt::Rectangle* getCharacterBounds(int32_t arg0) = 0;
    virtual int32_t getIndexAtPoint(::java::awt::Point* arg0) = 0;
    virtual ::java::lang::String* getSelectedText() = 0;
    virtual int32_t getSelectionEnd() = 0;
    virtual int32_t getSelectionStart() = 0;

    // Generated
    static ::java::lang::Class *class_();
};
