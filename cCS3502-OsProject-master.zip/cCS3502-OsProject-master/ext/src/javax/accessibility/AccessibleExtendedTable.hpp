// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/AccessibleTable.hpp>

struct javax::accessibility::AccessibleExtendedTable
    : public virtual AccessibleTable
{

    virtual int32_t getAccessibleColumn(int32_t arg0) = 0;
    virtual int32_t getAccessibleIndex(int32_t arg0, int32_t arg1) = 0;
    virtual int32_t getAccessibleRow(int32_t arg0) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
