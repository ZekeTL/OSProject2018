// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/AccessibleComponent.hpp>

struct javax::accessibility::AccessibleExtendedComponent
    : public virtual AccessibleComponent
{

    virtual AccessibleKeyBinding* getAccessibleKeyBinding() = 0;
    virtual ::java::lang::String* getTitledBorderText() = 0;
    virtual ::java::lang::String* getToolTipText() = 0;

    // Generated
    static ::java::lang::Class *class_();
};
