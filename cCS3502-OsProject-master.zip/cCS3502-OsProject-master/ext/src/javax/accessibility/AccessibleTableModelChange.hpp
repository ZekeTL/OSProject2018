// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct javax::accessibility::AccessibleTableModelChange
    : public virtual ::java::lang::Object
{
    static constexpr int32_t DELETE { int32_t(-1) };
    static constexpr int32_t INSERT { int32_t(1) };
    static constexpr int32_t UPDATE { int32_t(0) };

    virtual int32_t getFirstColumn() = 0;
    virtual int32_t getFirstRow() = 0;
    virtual int32_t getLastColumn() = 0;
    virtual int32_t getLastRow() = 0;
    virtual int32_t getType() = 0;

    // Generated
    static ::java::lang::Class *class_();
};
