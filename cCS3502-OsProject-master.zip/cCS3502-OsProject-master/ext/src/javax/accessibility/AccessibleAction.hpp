// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct javax::accessibility::AccessibleAction
    : public virtual ::java::lang::Object
{

private:
    static ::java::lang::String* CLICK_;
    static ::java::lang::String* DECREMENT_;
    static ::java::lang::String* INCREMENT_;
    static ::java::lang::String* TOGGLE_EXPAND_;
    static ::java::lang::String* TOGGLE_POPUP_;


public:
    virtual bool doAccessibleAction(int32_t arg0) = 0;
    virtual int32_t getAccessibleActionCount() = 0;
    virtual ::java::lang::String* getAccessibleActionDescription(int32_t arg0) = 0;

    // Generated
    static ::java::lang::Class *class_();
    static ::java::lang::String*& CLICK();
    static ::java::lang::String*& DECREMENT();
    static ::java::lang::String*& INCREMENT();
    static ::java::lang::String*& TOGGLE_EXPAND();
    static ::java::lang::String*& TOGGLE_POPUP();
};
