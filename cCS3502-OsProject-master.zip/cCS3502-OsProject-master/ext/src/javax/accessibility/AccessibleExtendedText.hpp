// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct javax::accessibility::AccessibleExtendedText
    : public virtual ::java::lang::Object
{
    static constexpr int32_t ATTRIBUTE_RUN { int32_t(5) };
    static constexpr int32_t LINE { int32_t(4) };

    virtual ::java::awt::Rectangle* getTextBounds(int32_t arg0, int32_t arg1) = 0;
    virtual ::java::lang::String* getTextRange(int32_t arg0, int32_t arg1) = 0;
    virtual AccessibleTextSequence* getTextSequenceAfter(int32_t arg0, int32_t arg1) = 0;
    virtual AccessibleTextSequence* getTextSequenceAt(int32_t arg0, int32_t arg1) = 0;
    virtual AccessibleTextSequence* getTextSequenceBefore(int32_t arg0, int32_t arg1) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
