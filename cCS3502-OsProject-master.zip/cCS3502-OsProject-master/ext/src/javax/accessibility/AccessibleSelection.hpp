// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct javax::accessibility::AccessibleSelection
    : public virtual ::java::lang::Object
{

    virtual void addAccessibleSelection(int32_t arg0) = 0;
    virtual void clearAccessibleSelection() = 0;
    virtual Accessible* getAccessibleSelection(int32_t arg0) = 0;
    virtual int32_t getAccessibleSelectionCount() = 0;
    virtual bool isAccessibleChildSelected(int32_t arg0) = 0;
    virtual void removeAccessibleSelection(int32_t arg0) = 0;
    virtual void selectAllAccessibleSelection() = 0;

    // Generated
    static ::java::lang::Class *class_();
};
