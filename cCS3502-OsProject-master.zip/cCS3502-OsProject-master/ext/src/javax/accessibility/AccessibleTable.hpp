// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct javax::accessibility::AccessibleTable
    : public virtual ::java::lang::Object
{

    virtual Accessible* getAccessibleAt(int32_t arg0, int32_t arg1) = 0;
    virtual Accessible* getAccessibleCaption() = 0;
    virtual int32_t getAccessibleColumnCount() = 0;
    virtual Accessible* getAccessibleColumnDescription(int32_t arg0) = 0;
    virtual int32_t getAccessibleColumnExtentAt(int32_t arg0, int32_t arg1) = 0;
    virtual AccessibleTable* getAccessibleColumnHeader() = 0;
    virtual int32_t getAccessibleRowCount() = 0;
    virtual Accessible* getAccessibleRowDescription(int32_t arg0) = 0;
    virtual int32_t getAccessibleRowExtentAt(int32_t arg0, int32_t arg1) = 0;
    virtual AccessibleTable* getAccessibleRowHeader() = 0;
    virtual Accessible* getAccessibleSummary() = 0;
    virtual ::int32_tArray* getSelectedAccessibleColumns() = 0;
    virtual ::int32_tArray* getSelectedAccessibleRows() = 0;
    virtual bool isAccessibleColumnSelected(int32_t arg0) = 0;
    virtual bool isAccessibleRowSelected(int32_t arg0) = 0;
    virtual bool isAccessibleSelected(int32_t arg0, int32_t arg1) = 0;
    virtual void setAccessibleCaption(Accessible* arg0) = 0;
    virtual void setAccessibleColumnDescription(int32_t arg0, Accessible* arg1) = 0;
    virtual void setAccessibleColumnHeader(AccessibleTable* arg0) = 0;
    virtual void setAccessibleRowDescription(int32_t arg0, Accessible* arg1) = 0;
    virtual void setAccessibleRowHeader(AccessibleTable* arg0) = 0;
    virtual void setAccessibleSummary(Accessible* arg0) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
