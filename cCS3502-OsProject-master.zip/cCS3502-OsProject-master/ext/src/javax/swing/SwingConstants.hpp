// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct javax::swing::SwingConstants
    : public virtual ::java::lang::Object
{
    static constexpr int32_t BOTTOM { int32_t(3) };
    static constexpr int32_t CENTER { int32_t(0) };
    static constexpr int32_t EAST { int32_t(3) };
    static constexpr int32_t HORIZONTAL { int32_t(0) };
    static constexpr int32_t LEADING { int32_t(10) };
    static constexpr int32_t LEFT { int32_t(2) };
    static constexpr int32_t NEXT { int32_t(12) };
    static constexpr int32_t NORTH { int32_t(1) };
    static constexpr int32_t NORTH_EAST { int32_t(2) };
    static constexpr int32_t NORTH_WEST { int32_t(8) };
    static constexpr int32_t PREVIOUS { int32_t(13) };
    static constexpr int32_t RIGHT { int32_t(4) };
    static constexpr int32_t SOUTH { int32_t(5) };
    static constexpr int32_t SOUTH_EAST { int32_t(4) };
    static constexpr int32_t SOUTH_WEST { int32_t(6) };
    static constexpr int32_t TOP { int32_t(1) };
    static constexpr int32_t TRAILING { int32_t(11) };
    static constexpr int32_t VERTICAL { int32_t(1) };
    static constexpr int32_t WEST { int32_t(7) };


    // Generated
    static ::java::lang::Class *class_();
};
