// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/io/Serializable.hpp>

struct default_init_tag;

class javax::swing::ActionMap
    : public virtual ::java::lang::Object
    , public virtual ::java::io::Serializable
{

public:
    typedef ::java::lang::Object super;

private:
    ArrayTable* arrayTable {  };
    ActionMap* parent {  };

protected:
    void ctor();

public:
    virtual ::java::lang::ObjectArray* allKeys();
    virtual void clear();
    virtual Action* get(::java::lang::Object* arg0);
    virtual ActionMap* getParent();
    virtual ::java::lang::ObjectArray* keys();
    virtual void put(::java::lang::Object* arg0, Action* arg1);
    /*void readObject(::java::io::ObjectInputStream* arg0); (private) */
    virtual void remove(::java::lang::Object* arg0);
    virtual void setParent(ActionMap* arg0);
    virtual int32_t size();
    /*void writeObject(::java::io::ObjectOutputStream* arg0); (private) */

    // Generated
    ActionMap();
protected:
    ActionMap(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
