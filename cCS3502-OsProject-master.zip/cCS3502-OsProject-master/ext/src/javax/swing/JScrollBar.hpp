// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/plaf/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/JComponent.hpp>
#include <java/awt/Adjustable.hpp>
#include <javax/accessibility/Accessible.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace util
    {
typedef ::SubArray< ::java::util::EventListener, ::java::lang::ObjectArray > EventListenerArray;
    } // util

    namespace awt
    {
        namespace event
        {
typedef ::SubArray< ::java::awt::event::AdjustmentListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > AdjustmentListenerArray;
        } // event
    } // awt
} // java

struct default_init_tag;

class javax::swing::JScrollBar
    : public JComponent
    , public virtual ::java::awt::Adjustable
    , public virtual ::javax::accessibility::Accessible
{

public:
    typedef JComponent super;

public: /* protected */
    int32_t blockIncrement {  };

private:
    ::javax::swing::event::ChangeListener* fwdAdjustmentEvents {  };

public: /* protected */
    BoundedRangeModel* model {  };
    int32_t orientation {  };

private:
    static ::java::lang::String* uiClassID_;

public: /* protected */
    int32_t unitIncrement {  };

protected:
    void ctor();
    void ctor(int32_t arg0);
    void ctor(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3, int32_t arg4);

public:
    void addAdjustmentListener(::java::awt::event::AdjustmentListener* arg0) override;
    /*void checkOrientation(int32_t arg0); (private) */

public: /* protected */
    virtual void fireAdjustmentValueChanged(int32_t arg0, int32_t arg1, int32_t arg2);
    /*void fireAdjustmentValueChanged(int32_t arg0, int32_t arg1, int32_t arg2, bool arg3); (private) */

public:
    ::javax::accessibility::AccessibleContext* getAccessibleContext() override;
    virtual ::java::awt::event::AdjustmentListenerArray* getAdjustmentListeners();
    int32_t getBlockIncrement() override;
    virtual int32_t getBlockIncrement(int32_t arg0);
    int32_t getMaximum() override;
    ::java::awt::Dimension* getMaximumSize() override;
    int32_t getMinimum() override;
    ::java::awt::Dimension* getMinimumSize() override;
    virtual BoundedRangeModel* getModel();
    int32_t getOrientation() override;
    virtual ::javax::swing::plaf::ScrollBarUI* getUI();
    ::java::lang::String* getUIClassID() override;
    int32_t getUnitIncrement() override;
    virtual int32_t getUnitIncrement(int32_t arg0);
    int32_t getValue() override;
    virtual bool getValueIsAdjusting();
    int32_t getVisibleAmount() override;

public: /* protected */
    ::java::lang::String* paramString() override;

public:
    void removeAdjustmentListener(::java::awt::event::AdjustmentListener* arg0) override;
    void setBlockIncrement(int32_t arg0) override;
    void setEnabled(bool arg0) override;
    void setMaximum(int32_t arg0) override;
    void setMinimum(int32_t arg0) override;
    virtual void setModel(BoundedRangeModel* arg0);
    virtual void setOrientation(int32_t arg0);
    virtual void setUI(::javax::swing::plaf::ScrollBarUI* arg0);
    void setUnitIncrement(int32_t arg0) override;
    void setValue(int32_t arg0) override;
    virtual void setValueIsAdjusting(bool arg0);
    virtual void setValues(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3);
    void setVisibleAmount(int32_t arg0) override;
    void updateUI() override;
    /*void writeObject(::java::io::ObjectOutputStream* arg0); (private) */

    // Generated
    JScrollBar();
    JScrollBar(int32_t arg0);
    JScrollBar(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3, int32_t arg4);
protected:
    JScrollBar(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

public: /* protected */
    virtual void setUI(::javax::swing::plaf::ComponentUI* newUI);

private:
    static ::java::lang::String*& uiClassID();
    virtual ::java::lang::Class* getClass0();
};
