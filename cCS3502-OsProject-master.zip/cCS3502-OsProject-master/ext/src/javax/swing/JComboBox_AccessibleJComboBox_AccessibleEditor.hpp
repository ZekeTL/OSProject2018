// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <javax/accessibility/Accessible.hpp>

struct default_init_tag;

class javax::swing::JComboBox_AccessibleJComboBox_AccessibleEditor
    : public virtual ::java::lang::Object
    , public virtual ::javax::accessibility::Accessible
{

public:
    typedef ::java::lang::Object super;

public: /* package */
    JComboBox_AccessibleJComboBox* this$1 {  };

    /*void ctor(); (private) */

public:
    ::javax::accessibility::AccessibleContext* getAccessibleContext() override;

    // Generated
    JComboBox_AccessibleJComboBox_AccessibleEditor(JComboBox_AccessibleJComboBox *JComboBox_AccessibleJComboBox_this);
protected:
    JComboBox_AccessibleJComboBox_AccessibleEditor(JComboBox_AccessibleJComboBox *JComboBox_AccessibleJComboBox_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JComboBox_AccessibleJComboBox *JComboBox_AccessibleJComboBox_this;

private:
    virtual ::java::lang::Class* getClass0();
};
