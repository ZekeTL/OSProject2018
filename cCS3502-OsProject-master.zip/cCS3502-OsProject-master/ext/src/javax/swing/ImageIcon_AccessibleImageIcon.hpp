// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/AccessibleContext.hpp>
#include <javax/accessibility/AccessibleIcon.hpp>
#include <java/io/Serializable.hpp>

struct default_init_tag;

class javax::swing::ImageIcon_AccessibleImageIcon
    : public ::javax::accessibility::AccessibleContext
    , public virtual ::javax::accessibility::AccessibleIcon
    , public virtual ::java::io::Serializable
{

public:
    typedef ::javax::accessibility::AccessibleContext super;

public: /* package */
    ImageIcon* this$0 {  };

protected:
    void ctor();

public:
    ::javax::accessibility::Accessible* getAccessibleChild(int32_t arg0) override;
    int32_t getAccessibleChildrenCount() override;
    ::java::lang::String* getAccessibleIconDescription() override;
    int32_t getAccessibleIconHeight() override;
    int32_t getAccessibleIconWidth() override;
    int32_t getAccessibleIndexInParent() override;
    ::javax::accessibility::Accessible* getAccessibleParent() override;
    ::javax::accessibility::AccessibleRole* getAccessibleRole() override;
    ::javax::accessibility::AccessibleStateSet* getAccessibleStateSet() override;
    ::java::util::Locale* getLocale() override;
    /*void readObject(::java::io::ObjectInputStream* arg0); (private) */
    void setAccessibleIconDescription(::java::lang::String* arg0) override;
    /*void writeObject(::java::io::ObjectOutputStream* arg0); (private) */

    // Generated

public: /* protected */
    ImageIcon_AccessibleImageIcon(ImageIcon *ImageIcon_this);
protected:
    ImageIcon_AccessibleImageIcon(ImageIcon *ImageIcon_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    ImageIcon *ImageIcon_this;

private:
    virtual ::java::lang::Class* getClass0();
};
