// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/datatransfer/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/dnd/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/beans/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/io/Serializable.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace io
    {
typedef ::SubArray< ::java::io::Serializable, ::java::lang::ObjectArray > SerializableArray;
typedef ::SubArray< ::java::io::Externalizable, ::java::lang::ObjectArray, SerializableArray > ExternalizableArray;
    } // io

    namespace lang
    {
typedef ::SubArray< ::java::lang::Cloneable, ObjectArray > CloneableArray;
    } // lang

    namespace awt
    {
        namespace datatransfer
        {
typedef ::SubArray< ::java::awt::datatransfer::DataFlavor, ::java::lang::ObjectArray, ::java::io::ExternalizableArray, ::java::lang::CloneableArray > DataFlavorArray;
        } // datatransfer
    } // awt
} // java

struct default_init_tag;

class javax::swing::TransferHandler
    : public virtual ::java::lang::Object
    , public virtual ::java::io::Serializable
{

public:
    typedef ::java::lang::Object super;
    static constexpr int32_t COPY { int32_t(1) };
    static constexpr int32_t COPY_OR_MOVE { int32_t(3) };
    static constexpr int32_t LINK { int32_t(1073741824) };
    static constexpr int32_t MOVE { int32_t(2) };
    static constexpr int32_t NONE { int32_t(0) };

private:
    static Action* copyAction_;
    static Action* cutAction_;
    ::java::awt::Image* dragImage {  };
    ::java::awt::Point* dragImageOffset {  };
    static Action* pasteAction_;
    ::java::lang::String* propertyName {  };
    static TransferHandler_SwingDragGestureRecognizer* recognizer_;

protected:
    void ctor();
    void ctor(::java::lang::String* arg0);

public:
    virtual bool canImport(TransferHandler_TransferSupport* arg0);
    virtual bool canImport(JComponent* arg0, ::java::awt::datatransfer::DataFlavorArray* arg1);

public: /* protected */
    virtual ::java::awt::datatransfer::Transferable* createTransferable(JComponent* arg0);

public:
    virtual void exportAsDrag(JComponent* arg0, ::java::awt::event::InputEvent* arg1, int32_t arg2);

public: /* protected */
    virtual void exportDone(JComponent* arg0, ::java::awt::datatransfer::Transferable* arg1, int32_t arg2);

public:
    virtual void exportToClipboard(JComponent* arg0, ::java::awt::datatransfer::Clipboard* arg1, int32_t arg2);
    static Action* getCopyAction();
    static Action* getCutAction();
    virtual ::java::awt::Image* getDragImage();
    virtual ::java::awt::Point* getDragImageOffset();
    /*static ::java::awt::dnd::DropTargetListener* getDropTargetListener(); (private) */
    static Action* getPasteAction();
    /*::java::awt::datatransfer::DataFlavor* getPropertyDataFlavor(::java::lang::Class* arg0, ::java::awt::datatransfer::DataFlavorArray* arg1); (private) */
    /*::java::beans::PropertyDescriptor* getPropertyDescriptor(JComponent* arg0); (private) */
    virtual int32_t getSourceActions(JComponent* arg0);
    virtual Icon* getVisualRepresentation(::java::awt::datatransfer::Transferable* arg0);
    virtual bool importData(TransferHandler_TransferSupport* arg0);
    virtual bool importData(JComponent* arg0, ::java::awt::datatransfer::Transferable* arg1);
    virtual void setDragImage(::java::awt::Image* arg0);
    virtual void setDragImageOffset(::java::awt::Point* arg0);

    // Generated

public: /* protected */
    TransferHandler();

public:
    TransferHandler(::java::lang::String* arg0);
protected:
    TransferHandler(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

public: /* package */
    static Action*& copyAction();
    static Action*& cutAction();
    static Action*& pasteAction();

private:
    static TransferHandler_SwingDragGestureRecognizer*& recognizer();
    virtual ::java::lang::Class* getClass0();
};
