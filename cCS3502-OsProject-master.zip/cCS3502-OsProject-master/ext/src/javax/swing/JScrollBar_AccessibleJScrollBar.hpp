// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/JComponent_AccessibleJComponent.hpp>
#include <javax/accessibility/AccessibleValue.hpp>

struct default_init_tag;

class javax::swing::JScrollBar_AccessibleJScrollBar
    : public JComponent_AccessibleJComponent
    , public virtual ::javax::accessibility::AccessibleValue
{

public:
    typedef JComponent_AccessibleJComponent super;

public: /* package */
    JScrollBar* this$0 {  };

protected:
    void ctor();

public:
    ::javax::accessibility::AccessibleRole* getAccessibleRole() override;
    ::javax::accessibility::AccessibleStateSet* getAccessibleStateSet() override;
    ::javax::accessibility::AccessibleValue* getAccessibleValue() override;
    ::java::lang::Number* getCurrentAccessibleValue() override;
    ::java::lang::Number* getMaximumAccessibleValue() override;
    ::java::lang::Number* getMinimumAccessibleValue() override;
    bool setCurrentAccessibleValue(::java::lang::Number* arg0) override;

    // Generated

public: /* protected */
    JScrollBar_AccessibleJScrollBar(JScrollBar *JScrollBar_this);
protected:
    JScrollBar_AccessibleJScrollBar(JScrollBar *JScrollBar_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JScrollBar *JScrollBar_this;

private:
    virtual ::java::lang::Class* getClass0();
};
