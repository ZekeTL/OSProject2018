// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/border/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct javax::swing::border::Border
    : public virtual ::java::lang::Object
{

    virtual ::java::awt::Insets* getBorderInsets(::java::awt::Component* arg0) = 0;
    virtual bool isBorderOpaque() = 0;
    virtual void paintBorder(::java::awt::Component* arg0, ::java::awt::Graphics* arg1, int32_t arg2, int32_t arg3, int32_t arg4, int32_t arg5) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
