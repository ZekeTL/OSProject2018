// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/border/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/border/EmptyBorder.hpp>

struct default_init_tag;

class javax::swing::border::MatteBorder
    : public EmptyBorder
{

public:
    typedef EmptyBorder super;

public: /* protected */
    ::java::awt::Color* color {  };
    ::javax::swing::Icon* tileIcon {  };

protected:
    void ctor(::javax::swing::Icon* arg0);
    void ctor(::java::awt::Insets* arg0, ::java::awt::Color* arg1);
    void ctor(::java::awt::Insets* arg0, ::javax::swing::Icon* arg1);
    void ctor(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3, ::java::awt::Color* arg4);
    void ctor(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3, ::javax::swing::Icon* arg4);
    /*::java::awt::Insets* computeInsets(::java::awt::Insets* arg0); (private) */

public:
    ::java::awt::Insets* getBorderInsets() override;
    ::java::awt::Insets* getBorderInsets(::java::awt::Component* arg0, ::java::awt::Insets* arg1) override;
    virtual ::java::awt::Color* getMatteColor();
    virtual ::javax::swing::Icon* getTileIcon();
    bool isBorderOpaque() override;
    void paintBorder(::java::awt::Component* arg0, ::java::awt::Graphics* arg1, int32_t arg2, int32_t arg3, int32_t arg4, int32_t arg5) override;
    /*void paintEdge(::java::awt::Component* arg0, ::java::awt::Graphics* arg1, int32_t arg2, int32_t arg3, int32_t arg4, int32_t arg5, int32_t arg6, int32_t arg7); (private) */

    // Generated
    MatteBorder(::javax::swing::Icon* arg0);
    MatteBorder(::java::awt::Insets* arg0, ::java::awt::Color* arg1);
    MatteBorder(::java::awt::Insets* arg0, ::javax::swing::Icon* arg1);
    MatteBorder(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3, ::java::awt::Color* arg4);
    MatteBorder(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3, ::javax::swing::Icon* arg4);
protected:
    MatteBorder(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    ::java::awt::Insets* getBorderInsets(::java::awt::Component* arg0);

private:
    virtual ::java::lang::Class* getClass0();
};
