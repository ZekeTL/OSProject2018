// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/border/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/border/AbstractBorder.hpp>
#include <java/io/Serializable.hpp>

struct default_init_tag;

class javax::swing::border::EmptyBorder
    : public AbstractBorder
    , public virtual ::java::io::Serializable
{

public:
    typedef AbstractBorder super;

public: /* protected */
    int32_t bottom {  };
    int32_t left {  };
    int32_t right {  };
    int32_t top {  };

protected:
    void ctor(::java::awt::Insets* arg0);
    void ctor(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3);

public:
    virtual ::java::awt::Insets* getBorderInsets();
    ::java::awt::Insets* getBorderInsets(::java::awt::Component* arg0, ::java::awt::Insets* arg1) override;
    bool isBorderOpaque() override;
    void paintBorder(::java::awt::Component* arg0, ::java::awt::Graphics* arg1, int32_t arg2, int32_t arg3, int32_t arg4, int32_t arg5) override;

    // Generated
    EmptyBorder(::java::awt::Insets* arg0);
    EmptyBorder(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3);
protected:
    EmptyBorder(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    ::java::awt::Insets* getBorderInsets(::java::awt::Component* c);

private:
    virtual ::java::lang::Class* getClass0();
};
