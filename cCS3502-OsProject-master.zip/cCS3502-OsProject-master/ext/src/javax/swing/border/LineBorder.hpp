// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/border/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/border/AbstractBorder.hpp>

struct default_init_tag;

class javax::swing::border::LineBorder
    : public AbstractBorder
{

public:
    typedef AbstractBorder super;

private:
    static Border* blackLine_;
    static Border* grayLine_;

public: /* protected */
    ::java::awt::Color* lineColor {  };
    bool roundedCorners {  };
    int32_t thickness {  };

protected:
    void ctor(::java::awt::Color* arg0);
    void ctor(::java::awt::Color* arg0, int32_t arg1);
    void ctor(::java::awt::Color* arg0, int32_t arg1, bool arg2);

public:
    static Border* createBlackLineBorder();
    static Border* createGrayLineBorder();
    ::java::awt::Insets* getBorderInsets(::java::awt::Component* arg0, ::java::awt::Insets* arg1) override;
    virtual ::java::awt::Color* getLineColor();
    virtual bool getRoundedCorners();
    virtual int32_t getThickness();
    bool isBorderOpaque() override;
    void paintBorder(::java::awt::Component* arg0, ::java::awt::Graphics* arg1, int32_t arg2, int32_t arg3, int32_t arg4, int32_t arg5) override;

    // Generated
    LineBorder(::java::awt::Color* arg0);
    LineBorder(::java::awt::Color* arg0, int32_t arg1);
    LineBorder(::java::awt::Color* arg0, int32_t arg1, bool arg2);
protected:
    LineBorder(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    ::java::awt::Insets* getBorderInsets(::java::awt::Component* arg0);

private:
    static Border*& blackLine();
    static Border*& grayLine();
    virtual ::java::lang::Class* getClass0();
};
