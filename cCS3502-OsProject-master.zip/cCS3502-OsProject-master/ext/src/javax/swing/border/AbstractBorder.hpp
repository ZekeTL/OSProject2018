// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/border/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <javax/swing/border/Border.hpp>
#include <java/io/Serializable.hpp>

struct default_init_tag;

class javax::swing::border::AbstractBorder
    : public virtual ::java::lang::Object
    , public virtual Border
    , public virtual ::java::io::Serializable
{

public:
    typedef ::java::lang::Object super;

protected:
    void ctor();

public:
    virtual int32_t getBaseline(::java::awt::Component* c, int32_t width, int32_t height);
    virtual ::java::awt::Component_BaselineResizeBehavior* getBaselineResizeBehavior(::java::awt::Component* c);
    ::java::awt::Insets* getBorderInsets(::java::awt::Component* c) override;
    virtual ::java::awt::Insets* getBorderInsets(::java::awt::Component* c, ::java::awt::Insets* insets);
    virtual ::java::awt::Rectangle* getInteriorRectangle(::java::awt::Component* c, int32_t x, int32_t y, int32_t width, int32_t height);
    static ::java::awt::Rectangle* getInteriorRectangle(::java::awt::Component* c, Border* b, int32_t x, int32_t y, int32_t width, int32_t height);
    bool isBorderOpaque() override;

public: /* package */
    static bool isLeftToRight(::java::awt::Component* arg0);

public:
    void paintBorder(::java::awt::Component* c, ::java::awt::Graphics* g, int32_t x, int32_t y, int32_t width, int32_t height) override;

    // Generated
    AbstractBorder();
protected:
    AbstractBorder(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
