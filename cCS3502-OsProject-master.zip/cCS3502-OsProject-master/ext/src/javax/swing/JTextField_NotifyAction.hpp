// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/TextAction.hpp>

struct default_init_tag;

class javax::swing::JTextField_NotifyAction
    : public ::javax::swing::text::TextAction
{

public:
    typedef ::javax::swing::text::TextAction super;

protected:
    void ctor();

public:
    void actionPerformed(::java::awt::event::ActionEvent* arg0) override;
    bool isEnabled() override;

    // Generated

public: /* package */
    JTextField_NotifyAction();
protected:
    JTextField_NotifyAction(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
