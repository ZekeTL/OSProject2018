// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/JComponent_AccessibleJComponent.hpp>
#include <javax/accessibility/AccessibleAction.hpp>
#include <javax/accessibility/AccessibleValue.hpp>
#include <javax/accessibility/AccessibleText.hpp>
#include <javax/accessibility/AccessibleExtendedComponent.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace javax
{
    namespace accessibility
    {
typedef ::SubArray< ::javax::accessibility::AccessibleIcon, ::java::lang::ObjectArray > AccessibleIconArray;
    } // accessibility
} // javax

struct default_init_tag;

class javax::swing::AbstractButton_AccessibleAbstractButton
    : public JComponent_AccessibleJComponent
    , public virtual ::javax::accessibility::AccessibleAction
    , public virtual ::javax::accessibility::AccessibleValue
    , public virtual ::javax::accessibility::AccessibleText
    , public virtual ::javax::accessibility::AccessibleExtendedComponent
{

public:
    typedef JComponent_AccessibleJComponent super;

public: /* package */
    AbstractButton* this$0 {  };

protected:
    void ctor();

public:
    bool doAccessibleAction(int32_t arg0) override;
    ::javax::accessibility::AccessibleAction* getAccessibleAction() override;
    int32_t getAccessibleActionCount() override;
    ::java::lang::String* getAccessibleActionDescription(int32_t arg0) override;

public: /* package */
    ::javax::accessibility::AccessibleExtendedComponent* getAccessibleExtendedComponent() override;

public:
    ::javax::accessibility::AccessibleIconArray* getAccessibleIcon() override;
    ::javax::accessibility::AccessibleKeyBinding* getAccessibleKeyBinding() override;
    ::java::lang::String* getAccessibleName() override;
    ::javax::accessibility::AccessibleRelationSet* getAccessibleRelationSet() override;
    ::javax::accessibility::AccessibleStateSet* getAccessibleStateSet() override;
    ::javax::accessibility::AccessibleText* getAccessibleText() override;
    ::javax::accessibility::AccessibleValue* getAccessibleValue() override;
    ::java::lang::String* getAfterIndex(int32_t arg0, int32_t arg1) override;
    ::java::lang::String* getAtIndex(int32_t arg0, int32_t arg1) override;
    ::java::lang::String* getBeforeIndex(int32_t arg0, int32_t arg1) override;
    int32_t getCaretPosition() override;
    int32_t getCharCount() override;
    ::javax::swing::text::AttributeSet* getCharacterAttribute(int32_t arg0) override;
    ::java::awt::Rectangle* getCharacterBounds(int32_t arg0) override;
    ::java::lang::Number* getCurrentAccessibleValue() override;
    int32_t getIndexAtPoint(::java::awt::Point* arg0) override;
    ::java::lang::Number* getMaximumAccessibleValue() override;
    ::java::lang::Number* getMinimumAccessibleValue() override;
    ::java::lang::String* getSelectedText() override;
    int32_t getSelectionEnd() override;
    int32_t getSelectionStart() override;
    /*::java::lang::String* getText(int32_t arg0, int32_t arg1); (private) */
    /*::java::awt::Rectangle* getTextRectangle(); (private) */
    ::java::lang::String* getTitledBorderText() override;
    ::java::lang::String* getToolTipText() override;
    bool setCurrentAccessibleValue(::java::lang::Number* arg0) override;

    // Generated

public: /* protected */
    AbstractButton_AccessibleAbstractButton(AbstractButton *AbstractButton_this);
protected:
    AbstractButton_AccessibleAbstractButton(AbstractButton *AbstractButton_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    virtual void addFocusListener(::java::awt::event::FocusListener* arg0);
    virtual bool contains(::java::awt::Point* arg0);
    virtual ::javax::accessibility::Accessible* getAccessibleAt(::java::awt::Point* arg0);
    virtual ::java::awt::Color* getBackground();
    virtual ::java::awt::Rectangle* getBounds();
    virtual ::java::awt::Cursor* getCursor();
    virtual ::java::awt::Font* getFont();
    virtual ::java::awt::FontMetrics* getFontMetrics(::java::awt::Font* arg0);
    virtual ::java::awt::Color* getForeground();
    virtual ::java::awt::Point* getLocation();
    virtual ::java::awt::Point* getLocationOnScreen();
    virtual ::java::awt::Dimension* getSize();
    virtual bool isEnabled();
    virtual bool isFocusTraversable();
    virtual bool isShowing();
    virtual bool isVisible();
    virtual void removeFocusListener(::java::awt::event::FocusListener* arg0);
    virtual void requestFocus();
    virtual void setBackground(::java::awt::Color* arg0);
    virtual void setBounds(::java::awt::Rectangle* arg0);
    virtual void setCursor(::java::awt::Cursor* arg0);
    virtual void setEnabled(bool arg0);
    virtual void setFont(::java::awt::Font* arg0);
    virtual void setForeground(::java::awt::Color* arg0);
    virtual void setLocation(::java::awt::Point* arg0);
    virtual void setSize(::java::awt::Dimension* arg0);
    virtual void setVisible(bool arg0);
    AbstractButton *AbstractButton_this;

private:
    virtual ::java::lang::Class* getClass0();
};
