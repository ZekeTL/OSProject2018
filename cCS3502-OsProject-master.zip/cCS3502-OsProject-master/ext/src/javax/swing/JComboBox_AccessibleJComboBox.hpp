// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/JComponent_AccessibleJComponent.hpp>
#include <javax/accessibility/AccessibleAction.hpp>
#include <javax/accessibility/AccessibleSelection.hpp>

struct default_init_tag;

class javax::swing::JComboBox_AccessibleJComboBox
    : public JComponent_AccessibleJComponent
    , public virtual ::javax::accessibility::AccessibleAction
    , public virtual ::javax::accessibility::AccessibleSelection
{

public:
    typedef JComponent_AccessibleJComponent super;

private:
    JComboBox_AccessibleJComboBox_EditorAccessibleContext* editorAccessibleContext {  };
    JList* popupList {  };
    ::javax::accessibility::Accessible* previousSelectedAccessible {  };

public: /* package */
    JComboBox* this$0 {  };

protected:
    void ctor();

public:
    void addAccessibleSelection(int32_t i) override;
    void clearAccessibleSelection() override;
    bool doAccessibleAction(int32_t i) override;
    ::javax::accessibility::AccessibleAction* getAccessibleAction() override;
    int32_t getAccessibleActionCount() override;
    ::java::lang::String* getAccessibleActionDescription(int32_t i) override;
    ::javax::accessibility::Accessible* getAccessibleChild(int32_t i) override;
    int32_t getAccessibleChildrenCount() override;
    ::javax::accessibility::AccessibleRole* getAccessibleRole() override;
    ::javax::accessibility::AccessibleSelection* getAccessibleSelection() override;
    ::javax::accessibility::Accessible* getAccessibleSelection(int32_t i) override;
    int32_t getAccessibleSelectionCount() override;
    ::javax::accessibility::AccessibleStateSet* getAccessibleStateSet() override;
    bool isAccessibleChildSelected(int32_t i) override;
    void removeAccessibleSelection(int32_t i) override;
    void selectAllAccessibleSelection() override;
    /*void setEditorNameAndDescription(); (private) */

    // Generated
    JComboBox_AccessibleJComboBox(JComboBox *JComboBox_this);
protected:
    JComboBox_AccessibleJComboBox(JComboBox *JComboBox_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JComboBox *JComboBox_this;

private:
    virtual ::java::lang::Class* getClass0();
};
