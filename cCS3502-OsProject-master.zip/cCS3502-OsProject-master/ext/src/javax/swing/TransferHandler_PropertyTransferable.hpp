// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/datatransfer/fwd-CS3502-OsProject-master.hpp>
#include <java/beans/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/awt/datatransfer/Transferable.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace io
    {
typedef ::SubArray< ::java::io::Serializable, ::java::lang::ObjectArray > SerializableArray;
typedef ::SubArray< ::java::io::Externalizable, ::java::lang::ObjectArray, SerializableArray > ExternalizableArray;
    } // io

    namespace lang
    {
typedef ::SubArray< ::java::lang::Cloneable, ObjectArray > CloneableArray;
    } // lang

    namespace awt
    {
        namespace datatransfer
        {
typedef ::SubArray< ::java::awt::datatransfer::DataFlavor, ::java::lang::ObjectArray, ::java::io::ExternalizableArray, ::java::lang::CloneableArray > DataFlavorArray;
        } // datatransfer
    } // awt
} // java

struct default_init_tag;

class javax::swing::TransferHandler_PropertyTransferable
    : public virtual ::java::lang::Object
    , public virtual ::java::awt::datatransfer::Transferable
{

public:
    typedef ::java::lang::Object super;

public: /* package */
    JComponent* component {  };
    ::java::beans::PropertyDescriptor* property {  };

protected:
    void ctor(::java::beans::PropertyDescriptor* arg0, JComponent* arg1);

public:
    ::java::lang::Object* getTransferData(::java::awt::datatransfer::DataFlavor* arg0) override;
    ::java::awt::datatransfer::DataFlavorArray* getTransferDataFlavors() override;
    bool isDataFlavorSupported(::java::awt::datatransfer::DataFlavor* arg0) override;

    // Generated

public: /* package */
    TransferHandler_PropertyTransferable(::java::beans::PropertyDescriptor* arg0, JComponent* arg1);
protected:
    TransferHandler_PropertyTransferable(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
