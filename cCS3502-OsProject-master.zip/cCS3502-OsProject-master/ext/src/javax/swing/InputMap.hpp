// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/io/Serializable.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace io
    {
typedef ::SubArray< ::java::io::Serializable, ::java::lang::ObjectArray > SerializableArray;
    } // io

    namespace awt
    {
typedef ::SubArray< ::java::awt::AWTKeyStroke, ::java::lang::ObjectArray, ::java::io::SerializableArray > AWTKeyStrokeArray;
    } // awt
} // java

namespace javax
{
    namespace swing
    {
typedef ::SubArray< ::javax::swing::KeyStroke, ::java::awt::AWTKeyStrokeArray > KeyStrokeArray;
    } // swing
} // javax

struct default_init_tag;

class javax::swing::InputMap
    : public virtual ::java::lang::Object
    , public virtual ::java::io::Serializable
{

public:
    typedef ::java::lang::Object super;

private:
    ArrayTable* arrayTable {  };
    InputMap* parent {  };

protected:
    void ctor();

public:
    virtual KeyStrokeArray* allKeys();
    virtual void clear();
    virtual ::java::lang::Object* get(KeyStroke* arg0);
    virtual InputMap* getParent();
    virtual KeyStrokeArray* keys();
    virtual void put(KeyStroke* arg0, ::java::lang::Object* arg1);
    /*void readObject(::java::io::ObjectInputStream* arg0); (private) */
    virtual void remove(KeyStroke* arg0);
    virtual void setParent(InputMap* arg0);
    virtual int32_t size();
    /*void writeObject(::java::io::ObjectOutputStream* arg0); (private) */

    // Generated
    InputMap();
protected:
    InputMap(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
