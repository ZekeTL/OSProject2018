// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <javax/accessibility/AccessibleKeyBinding.hpp>

struct default_init_tag;

class javax::swing::AbstractButton_AccessibleAbstractButton_ButtonKeyBinding
    : public virtual ::java::lang::Object
    , public virtual ::javax::accessibility::AccessibleKeyBinding
{

public:
    typedef ::java::lang::Object super;

public: /* package */
    int32_t mnemonic {  };
    AbstractButton_AccessibleAbstractButton* this$1 {  };

protected:
    void ctor(int32_t arg0);

public:
    ::java::lang::Object* getAccessibleKeyBinding(int32_t arg0) override;
    int32_t getAccessibleKeyBindingCount() override;

    // Generated

public: /* package */
    AbstractButton_AccessibleAbstractButton_ButtonKeyBinding(AbstractButton_AccessibleAbstractButton *AbstractButton_AccessibleAbstractButton_this, int32_t arg0);
protected:
    AbstractButton_AccessibleAbstractButton_ButtonKeyBinding(AbstractButton_AccessibleAbstractButton *AbstractButton_AccessibleAbstractButton_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    AbstractButton_AccessibleAbstractButton *AbstractButton_AccessibleAbstractButton_this;

private:
    virtual ::java::lang::Class* getClass0();
};
