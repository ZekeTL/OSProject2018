// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/Frame.hpp>
#include <java/awt/event/WindowListener.hpp>

struct default_init_tag;

class javax::swing::SwingUtilities_SharedOwnerFrame
    : public ::java::awt::Frame
    , public virtual ::java::awt::event::WindowListener
{

public:
    typedef ::java::awt::Frame super;

protected:
    void ctor();

public:
    void addNotify() override;
    void dispose() override;

public: /* package */
    virtual void installListeners();

public:
    void show() override;
    void windowActivated(::java::awt::event::WindowEvent* arg0) override;
    void windowClosed(::java::awt::event::WindowEvent* arg0) override;
    void windowClosing(::java::awt::event::WindowEvent* arg0) override;
    void windowDeactivated(::java::awt::event::WindowEvent* arg0) override;
    void windowDeiconified(::java::awt::event::WindowEvent* arg0) override;
    void windowIconified(::java::awt::event::WindowEvent* arg0) override;
    void windowOpened(::java::awt::event::WindowEvent* arg0) override;

    // Generated

public: /* package */
    SwingUtilities_SharedOwnerFrame();
protected:
    SwingUtilities_SharedOwnerFrame(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    virtual void show(bool arg0);

private:
    virtual ::java::lang::Class* getClass0();
};
