// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/beans/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <javax/swing/Action.hpp>

struct default_init_tag;

class javax::swing::JComponent_ActionStandin final
    : public virtual ::java::lang::Object
    , public Action
{

public:
    typedef ::java::lang::Object super;

private:
    Action* action {  };
    ::java::awt::event::ActionListener* actionListener {  };
    ::java::lang::String* command {  };

public: /* package */
    JComponent* this$0 {  };

protected:
    void ctor(::java::awt::event::ActionListener* arg0, ::java::lang::String* arg1);

public:
    void actionPerformed(::java::awt::event::ActionEvent* arg0) override;
    void addPropertyChangeListener(::java::beans::PropertyChangeListener* arg0) override;
    ::java::lang::Object* getValue(::java::lang::String* arg0) override;
    bool isEnabled() override;
    void putValue(::java::lang::String* arg0, ::java::lang::Object* arg1) override;
    void removePropertyChangeListener(::java::beans::PropertyChangeListener* arg0) override;
    void setEnabled(bool arg0) override;

    // Generated

public: /* package */
    JComponent_ActionStandin(JComponent *JComponent_this, ::java::awt::event::ActionListener* arg0, ::java::lang::String* arg1);
protected:
    JComponent_ActionStandin(JComponent *JComponent_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JComponent *JComponent_this;

private:
    virtual ::java::lang::Class* getClass0();
};
