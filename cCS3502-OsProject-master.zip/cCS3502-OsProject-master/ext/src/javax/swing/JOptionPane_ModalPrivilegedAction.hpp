// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/reflect/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/security/PrivilegedAction.hpp>
#include <java/lang/reflect/Method.hpp>

struct default_init_tag;

class javax::swing::JOptionPane_ModalPrivilegedAction
    : public virtual ::java::lang::Object
    , public virtual ::java::security::PrivilegedAction
{

public:
    typedef ::java::lang::Object super;

private:
    ::java::lang::Class* clazz {  };
    ::java::lang::String* methodName {  };

protected:
    void ctor(::java::lang::Class* arg0, ::java::lang::String* arg1);

public:
    ::java::lang::reflect::Method* run() override;

    // Generated
    JOptionPane_ModalPrivilegedAction(::java::lang::Class* arg0, ::java::lang::String* arg1);
protected:
    JOptionPane_ModalPrivilegedAction(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
