// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct javax::swing::CellEditor
    : public virtual ::java::lang::Object
{

    virtual void addCellEditorListener(::javax::swing::event::CellEditorListener* l) = 0;
    virtual void cancelCellEditing() = 0;
    virtual ::java::lang::Object* getCellEditorValue() = 0;
    virtual bool isCellEditable(::java::util::EventObject* anEvent) = 0;
    virtual void removeCellEditorListener(::javax::swing::event::CellEditorListener* l) = 0;
    virtual bool shouldSelectCell(::java::util::EventObject* anEvent) = 0;
    virtual bool stopCellEditing() = 0;

    // Generated
    static ::java::lang::Class *class_();
};
