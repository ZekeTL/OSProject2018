// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/DefaultCellEditor.hpp>

struct default_init_tag;

class javax::swing::JTable_BooleanEditor
    : public DefaultCellEditor
{

public:
    typedef DefaultCellEditor super;

protected:
    void ctor();

    // Generated

public:
    JTable_BooleanEditor();
protected:
    JTable_BooleanEditor(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
