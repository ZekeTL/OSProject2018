// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/print/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/awt/print/Printable.hpp>

struct default_init_tag;

class javax::swing::JTable_ThreadSafePrintable
    : public virtual ::java::lang::Object
    , public virtual ::java::awt::print::Printable
{

public:
    typedef ::java::lang::Object super;

private:
    ::java::awt::print::Printable* printDelegate {  };
    ::java::lang::Throwable* retThrowable {  };
    int32_t retVal {  };

public: /* package */
    JTable* this$0 {  };

protected:
    void ctor(::java::awt::print::Printable* arg0);

public:
    int32_t print(::java::awt::Graphics* arg0, ::java::awt::print::PageFormat* arg1, int32_t arg2) override;

    // Generated
    JTable_ThreadSafePrintable(JTable *JTable_this, ::java::awt::print::Printable* arg0);
protected:
    JTable_ThreadSafePrintable(JTable *JTable_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JTable *JTable_this;

private:
    virtual ::java::lang::Class* getClass0();
};
