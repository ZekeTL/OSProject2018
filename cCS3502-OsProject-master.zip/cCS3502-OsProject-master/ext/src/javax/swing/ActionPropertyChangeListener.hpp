// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/beans/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/ref/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/beans/PropertyChangeListener.hpp>
#include <java/io/Serializable.hpp>

struct default_init_tag;

class javax::swing::ActionPropertyChangeListener
    : public virtual ::java::lang::Object
    , public virtual ::java::beans::PropertyChangeListener
    , public virtual ::java::io::Serializable
{

public:
    typedef ::java::lang::Object super;

private:
    Action* action {  };
    static ::java::lang::ref::ReferenceQueue* queue_;
    ActionPropertyChangeListener_OwnedWeakReference* target {  };

protected:
    void ctor(JComponent* arg0, Action* arg1);

public: /* protected */
    virtual void actionPropertyChanged(JComponent* arg0, Action* arg1, ::java::beans::PropertyChangeEvent* arg2) = 0;

public:
    virtual Action* getAction();
    /*static ::java::lang::ref::ReferenceQueue* getQueue(); (private) */
    virtual JComponent* getTarget();
    void propertyChange(::java::beans::PropertyChangeEvent* arg0) override;
    /*void readObject(::java::io::ObjectInputStream* arg0); (private) */
    /*void setTarget(JComponent* arg0); (private) */
    /*void writeObject(::java::io::ObjectOutputStream* arg0); (private) */

    // Generated
    ActionPropertyChangeListener(JComponent* arg0, Action* arg1);
protected:
    ActionPropertyChangeListener(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    static ::java::lang::ref::ReferenceQueue*& queue();
    virtual ::java::lang::Class* getClass0();
};
