// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/plaf/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/JComponent.hpp>
#include <javax/accessibility/Accessible.hpp>

struct default_init_tag;

class javax::swing::JOptionPane
    : public JComponent
    , public virtual ::javax::accessibility::Accessible
{

public:
    typedef JComponent super;
    static constexpr int32_t CANCEL_OPTION { int32_t(2) };
    static constexpr int32_t CLOSED_OPTION { int32_t(-1) };
    static constexpr int32_t DEFAULT_OPTION { int32_t(-1) };
    static constexpr int32_t ERROR_MESSAGE { int32_t(0) };

private:
    static ::java::lang::String* ICON_PROPERTY_;

public:
    static constexpr int32_t INFORMATION_MESSAGE { int32_t(1) };

private:
    static ::java::lang::String* INITIAL_SELECTION_VALUE_PROPERTY_;
    static ::java::lang::String* INITIAL_VALUE_PROPERTY_;
    static ::java::lang::String* INPUT_VALUE_PROPERTY_;
    static ::java::lang::String* MESSAGE_PROPERTY_;
    static ::java::lang::String* MESSAGE_TYPE_PROPERTY_;

public:
    static constexpr int32_t NO_OPTION { int32_t(1) };
    static constexpr int32_t OK_CANCEL_OPTION { int32_t(2) };
    static constexpr int32_t OK_OPTION { int32_t(0) };

private:
    static ::java::lang::String* OPTIONS_PROPERTY_;
    static ::java::lang::String* OPTION_TYPE_PROPERTY_;

public:
    static constexpr int32_t PLAIN_MESSAGE { int32_t(-1) };
    static constexpr int32_t QUESTION_MESSAGE { int32_t(3) };

private:
    static ::java::lang::String* SELECTION_VALUES_PROPERTY_;
    static ::java::lang::Object* UNINITIALIZED_VALUE_;
    static ::java::lang::String* VALUE_PROPERTY_;
    static ::java::lang::String* WANTS_INPUT_PROPERTY_;

public:
    static constexpr int32_t WARNING_MESSAGE { int32_t(2) };
    static constexpr int32_t YES_NO_CANCEL_OPTION { int32_t(1) };
    static constexpr int32_t YES_NO_OPTION { int32_t(0) };
    static constexpr int32_t YES_OPTION { int32_t(0) };

public: /* protected */
    Icon* icon {  };
    ::java::lang::Object* initialSelectionValue {  };
    ::java::lang::Object* initialValue {  };
    ::java::lang::Object* inputValue {  };
    ::java::lang::Object* message {  };
    int32_t messageType {  };
    int32_t optionType {  };
    ::java::lang::ObjectArray* options {  };
    ::java::lang::ObjectArray* selectionValues {  };

private:
    static ::java::lang::Object* sharedFrameKey_;
    static ::java::lang::String* uiClassID_;

public: /* protected */
    ::java::lang::Object* value {  };
    bool wantsInput {  };

protected:
    void ctor();
    void ctor(::java::lang::Object* arg0);
    void ctor(::java::lang::Object* arg0, int32_t arg1);
    void ctor(::java::lang::Object* arg0, int32_t arg1, int32_t arg2);
    void ctor(::java::lang::Object* arg0, int32_t arg1, int32_t arg2, Icon* arg3);
    void ctor(::java::lang::Object* arg0, int32_t arg1, int32_t arg2, Icon* arg3, ::java::lang::ObjectArray* arg4);
    void ctor(::java::lang::Object* arg0, int32_t arg1, int32_t arg2, Icon* arg3, ::java::lang::ObjectArray* arg4, ::java::lang::Object* arg5);

public:
    virtual JDialog* createDialog(::java::lang::String* arg0);
    virtual JDialog* createDialog(::java::awt::Component* arg0, ::java::lang::String* arg1);
    /*JDialog* createDialog(::java::awt::Component* arg0, ::java::lang::String* arg1, int32_t arg2); (private) */
    virtual JInternalFrame* createInternalFrame(::java::awt::Component* arg0, ::java::lang::String* arg1);
    ::javax::accessibility::AccessibleContext* getAccessibleContext() override;
    static JDesktopPane* getDesktopPaneForComponent(::java::awt::Component* arg0);
    static ::java::awt::Frame* getFrameForComponent(::java::awt::Component* arg0);
    virtual Icon* getIcon();
    virtual ::java::lang::Object* getInitialSelectionValue();
    virtual ::java::lang::Object* getInitialValue();
    virtual ::java::lang::Object* getInputValue();
    virtual int32_t getMaxCharactersPerLineCount();
    virtual ::java::lang::Object* getMessage();
    virtual int32_t getMessageType();
    virtual int32_t getOptionType();
    virtual ::java::lang::ObjectArray* getOptions();
    static ::java::awt::Frame* getRootFrame();
    virtual ::java::lang::ObjectArray* getSelectionValues();
    virtual ::javax::swing::plaf::OptionPaneUI* getUI();
    ::java::lang::String* getUIClassID() override;
    virtual ::java::lang::Object* getValue();
    virtual bool getWantsInput();

public: /* package */
    static ::java::awt::Window* getWindowForComponent(::java::awt::Component* arg0);
    /*void initDialog(JDialog* arg0, int32_t arg1, ::java::awt::Component* arg2); (private) */

public: /* protected */
    ::java::lang::String* paramString() override;
    /*void readObject(::java::io::ObjectInputStream* arg0); (private) */

public:
    virtual void selectInitialValue();
    virtual void setIcon(Icon* arg0);
    virtual void setInitialSelectionValue(::java::lang::Object* arg0);
    virtual void setInitialValue(::java::lang::Object* arg0);
    virtual void setInputValue(::java::lang::Object* arg0);
    virtual void setMessage(::java::lang::Object* arg0);
    virtual void setMessageType(int32_t arg0);
    virtual void setOptionType(int32_t arg0);
    virtual void setOptions(::java::lang::ObjectArray* arg0);
    static void setRootFrame(::java::awt::Frame* arg0);
    virtual void setSelectionValues(::java::lang::ObjectArray* arg0);
    virtual void setUI(::javax::swing::plaf::OptionPaneUI* arg0);
    virtual void setValue(::java::lang::Object* arg0);
    virtual void setWantsInput(bool arg0);
    static int32_t showConfirmDialog(::java::awt::Component* arg0, ::java::lang::Object* arg1);
    static int32_t showConfirmDialog(::java::awt::Component* arg0, ::java::lang::Object* arg1, ::java::lang::String* arg2, int32_t arg3);
    static int32_t showConfirmDialog(::java::awt::Component* arg0, ::java::lang::Object* arg1, ::java::lang::String* arg2, int32_t arg3, int32_t arg4);
    static int32_t showConfirmDialog(::java::awt::Component* arg0, ::java::lang::Object* arg1, ::java::lang::String* arg2, int32_t arg3, int32_t arg4, Icon* arg5);
    static ::java::lang::String* showInputDialog(::java::lang::Object* arg0);
    static ::java::lang::String* showInputDialog(::java::lang::Object* arg0, ::java::lang::Object* arg1);
    static ::java::lang::String* showInputDialog(::java::awt::Component* arg0, ::java::lang::Object* arg1);
    static ::java::lang::String* showInputDialog(::java::awt::Component* arg0, ::java::lang::Object* arg1, ::java::lang::Object* arg2);
    static ::java::lang::String* showInputDialog(::java::awt::Component* arg0, ::java::lang::Object* arg1, ::java::lang::String* arg2, int32_t arg3);
    static ::java::lang::Object* showInputDialog(::java::awt::Component* arg0, ::java::lang::Object* arg1, ::java::lang::String* arg2, int32_t arg3, Icon* arg4, ::java::lang::ObjectArray* arg5, ::java::lang::Object* arg6);
    static int32_t showInternalConfirmDialog(::java::awt::Component* arg0, ::java::lang::Object* arg1);
    static int32_t showInternalConfirmDialog(::java::awt::Component* arg0, ::java::lang::Object* arg1, ::java::lang::String* arg2, int32_t arg3);
    static int32_t showInternalConfirmDialog(::java::awt::Component* arg0, ::java::lang::Object* arg1, ::java::lang::String* arg2, int32_t arg3, int32_t arg4);
    static int32_t showInternalConfirmDialog(::java::awt::Component* arg0, ::java::lang::Object* arg1, ::java::lang::String* arg2, int32_t arg3, int32_t arg4, Icon* arg5);
    static ::java::lang::String* showInternalInputDialog(::java::awt::Component* arg0, ::java::lang::Object* arg1);
    static ::java::lang::String* showInternalInputDialog(::java::awt::Component* arg0, ::java::lang::Object* arg1, ::java::lang::String* arg2, int32_t arg3);
    static ::java::lang::Object* showInternalInputDialog(::java::awt::Component* arg0, ::java::lang::Object* arg1, ::java::lang::String* arg2, int32_t arg3, Icon* arg4, ::java::lang::ObjectArray* arg5, ::java::lang::Object* arg6);
    static void showInternalMessageDialog(::java::awt::Component* arg0, ::java::lang::Object* arg1);
    static void showInternalMessageDialog(::java::awt::Component* arg0, ::java::lang::Object* arg1, ::java::lang::String* arg2, int32_t arg3);
    static void showInternalMessageDialog(::java::awt::Component* arg0, ::java::lang::Object* arg1, ::java::lang::String* arg2, int32_t arg3, Icon* arg4);
    static int32_t showInternalOptionDialog(::java::awt::Component* arg0, ::java::lang::Object* arg1, ::java::lang::String* arg2, int32_t arg3, int32_t arg4, Icon* arg5, ::java::lang::ObjectArray* arg6, ::java::lang::Object* arg7);
    static void showMessageDialog(::java::awt::Component* arg0, ::java::lang::Object* arg1);
    static void showMessageDialog(::java::awt::Component* arg0, ::java::lang::Object* arg1, ::java::lang::String* arg2, int32_t arg3);
    static void showMessageDialog(::java::awt::Component* arg0, ::java::lang::Object* arg1, ::java::lang::String* arg2, int32_t arg3, Icon* arg4);
    static int32_t showOptionDialog(::java::awt::Component* arg0, ::java::lang::Object* arg1, ::java::lang::String* arg2, int32_t arg3, int32_t arg4, Icon* arg5, ::java::lang::ObjectArray* arg6, ::java::lang::Object* arg7);
    /*static int32_t styleFromMessageType(int32_t arg0); (private) */
    void updateUI() override;
    /*void writeObject(::java::io::ObjectOutputStream* arg0); (private) */

    // Generated
    JOptionPane();
    JOptionPane(::java::lang::Object* arg0);
    JOptionPane(::java::lang::Object* arg0, int32_t arg1);
    JOptionPane(::java::lang::Object* arg0, int32_t arg1, int32_t arg2);
    JOptionPane(::java::lang::Object* arg0, int32_t arg1, int32_t arg2, Icon* arg3);
    JOptionPane(::java::lang::Object* arg0, int32_t arg1, int32_t arg2, Icon* arg3, ::java::lang::ObjectArray* arg4);
    JOptionPane(::java::lang::Object* arg0, int32_t arg1, int32_t arg2, Icon* arg3, ::java::lang::ObjectArray* arg4, ::java::lang::Object* arg5);
protected:
    JOptionPane(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

public: /* protected */
    virtual void setUI(::javax::swing::plaf::ComponentUI* newUI);

public:
    static ::java::lang::String*& ICON_PROPERTY();
    static ::java::lang::String*& INITIAL_SELECTION_VALUE_PROPERTY();
    static ::java::lang::String*& INITIAL_VALUE_PROPERTY();
    static ::java::lang::String*& INPUT_VALUE_PROPERTY();
    static ::java::lang::String*& MESSAGE_PROPERTY();
    static ::java::lang::String*& MESSAGE_TYPE_PROPERTY();
    static ::java::lang::String*& OPTIONS_PROPERTY();
    static ::java::lang::String*& OPTION_TYPE_PROPERTY();
    static ::java::lang::String*& SELECTION_VALUES_PROPERTY();
    static ::java::lang::Object*& UNINITIALIZED_VALUE();
    static ::java::lang::String*& VALUE_PROPERTY();
    static ::java::lang::String*& WANTS_INPUT_PROPERTY();

private:
    static ::java::lang::Object*& sharedFrameKey();
    static ::java::lang::String*& uiClassID();
    virtual ::java::lang::Class* getClass0();
};
