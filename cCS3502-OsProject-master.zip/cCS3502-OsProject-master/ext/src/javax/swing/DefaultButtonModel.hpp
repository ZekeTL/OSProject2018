// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <javax/swing/ButtonModel.hpp>
#include <java/io/Serializable.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace util
    {
typedef ::SubArray< ::java::util::EventListener, ::java::lang::ObjectArray > EventListenerArray;
    } // util

    namespace awt
    {
        namespace event
        {
typedef ::SubArray< ::java::awt::event::ActionListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > ActionListenerArray;
typedef ::SubArray< ::java::awt::event::ItemListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > ItemListenerArray;
        } // event
    } // awt
} // java

namespace javax
{
    namespace swing
    {
        namespace event
        {
typedef ::SubArray< ::javax::swing::event::ChangeListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > ChangeListenerArray;
        } // event
    } // swing
} // javax

struct default_init_tag;

class javax::swing::DefaultButtonModel
    : public virtual ::java::lang::Object
    , public virtual ButtonModel
    , public virtual ::java::io::Serializable
{

public:
    typedef ::java::lang::Object super;
    static constexpr int32_t ARMED { int32_t(1) };
    static constexpr int32_t ENABLED { int32_t(8) };
    static constexpr int32_t PRESSED { int32_t(4) };
    static constexpr int32_t ROLLOVER { int32_t(16) };
    static constexpr int32_t SELECTED { int32_t(2) };

public: /* protected */
    ::java::lang::String* actionCommand {  };
    ::javax::swing::event::ChangeEvent* changeEvent {  };
    ButtonGroup* group {  };
    ::javax::swing::event::EventListenerList* listenerList {  };

private:
    bool menuItem {  };

public: /* protected */
    int32_t mnemonic {  };
    int32_t stateMask {  };

protected:
    void ctor();

public:
    void addActionListener(::java::awt::event::ActionListener* arg0) override;
    void addChangeListener(::javax::swing::event::ChangeListener* arg0) override;
    void addItemListener(::java::awt::event::ItemListener* arg0) override;

public: /* protected */
    virtual void fireActionPerformed(::java::awt::event::ActionEvent* arg0);
    virtual void fireItemStateChanged(::java::awt::event::ItemEvent* arg0);
    virtual void fireStateChanged();

public:
    ::java::lang::String* getActionCommand() override;
    virtual ::java::awt::event::ActionListenerArray* getActionListeners();
    virtual ::javax::swing::event::ChangeListenerArray* getChangeListeners();
    virtual ButtonGroup* getGroup();
    virtual ::java::awt::event::ItemListenerArray* getItemListeners();
    virtual ::java::util::EventListenerArray* getListeners(::java::lang::Class* arg0);
    int32_t getMnemonic() override;
    ::java::lang::ObjectArray* getSelectedObjects() override;
    bool isArmed() override;
    bool isEnabled() override;

public: /* package */
    virtual bool isMenuItem();

public:
    bool isPressed() override;
    bool isRollover() override;
    bool isSelected() override;
    void removeActionListener(::java::awt::event::ActionListener* arg0) override;
    void removeChangeListener(::javax::swing::event::ChangeListener* arg0) override;
    void removeItemListener(::java::awt::event::ItemListener* arg0) override;
    void setActionCommand(::java::lang::String* arg0) override;
    void setArmed(bool arg0) override;
    void setEnabled(bool arg0) override;
    void setGroup(ButtonGroup* arg0) override;

public: /* package */
    virtual void setMenuItem(bool arg0);

public:
    void setMnemonic(int32_t arg0) override;
    void setPressed(bool arg0) override;
    void setRollover(bool arg0) override;
    void setSelected(bool arg0) override;

    // Generated
    DefaultButtonModel();
protected:
    DefaultButtonModel(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
