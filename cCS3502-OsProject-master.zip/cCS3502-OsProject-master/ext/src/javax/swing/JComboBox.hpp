// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/beans/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/plaf/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/JComponent.hpp>
#include <java/awt/ItemSelectable.hpp>
#include <javax/swing/event/ListDataListener.hpp>
#include <java/awt/event/ActionListener.hpp>
#include <javax/accessibility/Accessible.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace util
    {
typedef ::SubArray< ::java::util::EventListener, ::java::lang::ObjectArray > EventListenerArray;
    } // util

    namespace awt
    {
        namespace event
        {
typedef ::SubArray< ::java::awt::event::ActionListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > ActionListenerArray;
typedef ::SubArray< ::java::awt::event::ItemListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > ItemListenerArray;
        } // event
    } // awt
} // java

namespace javax
{
    namespace swing
    {
        namespace event
        {
typedef ::SubArray< ::javax::swing::event::PopupMenuListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > PopupMenuListenerArray;
        } // event
    } // swing
} // javax

struct default_init_tag;

class javax::swing::JComboBox
    : public JComponent
    , public virtual ::java::awt::ItemSelectable
    , public virtual ::javax::swing::event::ListDataListener
    , public virtual ::java::awt::event::ActionListener
    , public virtual ::javax::accessibility::Accessible
{

public:
    typedef JComponent super;

private:
    Action* action_ {  };

public: /* protected */
    ::java::lang::String* actionCommand {  };

private:
    ::java::beans::PropertyChangeListener* actionPropertyChangeListener {  };

public: /* protected */
    ComboBoxModel* dataModel {  };
    ComboBoxEditor* editor {  };

private:
    bool firingActionEvent {  };

public: /* protected */
    bool isEditable_ {  };
    JComboBox_KeySelectionManager* keySelectionManager {  };
    bool lightWeightPopupEnabled {  };
    int32_t maximumRowCount {  };

private:
    ::java::lang::Object* prototypeDisplayValue {  };

public: /* protected */
    ListCellRenderer* renderer {  };
    ::java::lang::Object* selectedItemReminder {  };

private:
    bool selectingItem {  };
    static ::java::lang::String* uiClassID_;

protected:
    void ctor();
    void ctor(ComboBoxModel* arg0);
    void ctor(::java::lang::ObjectArray* arg0);
    void ctor(::java::util::Vector* arg0);

public:
    void actionPerformed(::java::awt::event::ActionEvent* arg0) override;

public: /* protected */
    virtual void actionPropertyChanged(Action* arg0, ::java::lang::String* arg1);

public:
    virtual void addActionListener(::java::awt::event::ActionListener* arg0);
    virtual void addItem(::java::lang::Object* arg0);
    void addItemListener(::java::awt::event::ItemListener* arg0) override;
    virtual void addPopupMenuListener(::javax::swing::event::PopupMenuListener* arg0);

public: /* package */
    virtual void checkMutableComboBoxModel();

public:
    virtual void configureEditor(ComboBoxEditor* arg0, ::java::lang::Object* arg1);

public: /* protected */
    virtual void configurePropertiesFromAction(Action* arg0);

public:
    void contentsChanged(::javax::swing::event::ListDataEvent* arg0) override;

public: /* protected */
    virtual ::java::beans::PropertyChangeListener* createActionPropertyChangeListener(Action* arg0);
    virtual JComboBox_KeySelectionManager* createDefaultKeySelectionManager();
    virtual void fireActionEvent();
    virtual void fireItemStateChanged(::java::awt::event::ItemEvent* arg0);

public:
    virtual void firePopupMenuCanceled();
    virtual void firePopupMenuWillBecomeInvisible();
    virtual void firePopupMenuWillBecomeVisible();
    ::javax::accessibility::AccessibleContext* getAccessibleContext() override;
    virtual Action* getAction();
    virtual ::java::lang::String* getActionCommand();
    virtual ::java::awt::event::ActionListenerArray* getActionListeners();
    virtual ComboBoxEditor* getEditor();
    virtual ::java::lang::Object* getItemAt(int32_t arg0);
    virtual int32_t getItemCount();
    virtual ::java::awt::event::ItemListenerArray* getItemListeners();
    virtual JComboBox_KeySelectionManager* getKeySelectionManager();
    virtual int32_t getMaximumRowCount();
    virtual ComboBoxModel* getModel();
    virtual ::javax::swing::event::PopupMenuListenerArray* getPopupMenuListeners();
    virtual ::java::lang::Object* getPrototypeDisplayValue();
    virtual ListCellRenderer* getRenderer();
    virtual int32_t getSelectedIndex();
    virtual ::java::lang::Object* getSelectedItem();
    ::java::lang::ObjectArray* getSelectedObjects() override;
    virtual ::javax::swing::plaf::ComboBoxUI* getUI();
    ::java::lang::String* getUIClassID() override;
    virtual void hidePopup();
    /*void init_(); (private) */
    virtual void insertItemAt(::java::lang::Object* arg0, int32_t arg1);

public: /* protected */
    virtual void installAncestorListener();

public:
    void intervalAdded(::javax::swing::event::ListDataEvent* arg0) override;
    void intervalRemoved(::javax::swing::event::ListDataEvent* arg0) override;
    virtual bool isEditable();
    virtual bool isLightWeightPopupEnabled();
    /*bool isListener(::java::lang::Class* arg0, ::java::awt::event::ActionListener* arg1); (private) */
    virtual bool isPopupVisible();

public: /* protected */
    ::java::lang::String* paramString() override;
    bool processKeyBinding(KeyStroke* arg0, ::java::awt::event::KeyEvent* arg1, int32_t arg2, bool arg3) override;

public:
    void processKeyEvent(::java::awt::event::KeyEvent* arg0) override;
    virtual void removeActionListener(::java::awt::event::ActionListener* arg0);
    virtual void removeAllItems();
    virtual void removeItem(::java::lang::Object* arg0);
    virtual void removeItemAt(int32_t arg0);
    void removeItemListener(::java::awt::event::ItemListener* arg0) override;
    virtual void removePopupMenuListener(::javax::swing::event::PopupMenuListener* arg0);
    virtual bool selectWithKeyChar(char16_t arg0);

public: /* protected */
    virtual void selectedItemChanged();

public:
    virtual void setAction(Action* arg0);
    virtual void setActionCommand(::java::lang::String* arg0);
    /*void setActionCommandFromAction(Action* arg0); (private) */
    virtual void setEditable(bool arg0);
    virtual void setEditor(ComboBoxEditor* arg0);
    void setEnabled(bool arg0) override;
    virtual void setKeySelectionManager(JComboBox_KeySelectionManager* arg0);
    virtual void setLightWeightPopupEnabled(bool arg0);
    virtual void setMaximumRowCount(int32_t arg0);
    virtual void setModel(ComboBoxModel* arg0);
    virtual void setPopupVisible(bool arg0);
    virtual void setPrototypeDisplayValue(::java::lang::Object* arg0);
    virtual void setRenderer(ListCellRenderer* arg0);
    virtual void setSelectedIndex(int32_t arg0);
    virtual void setSelectedItem(::java::lang::Object* arg0);
    virtual void setUI(::javax::swing::plaf::ComboBoxUI* arg0);
    virtual void showPopup();
    void updateUI() override;
    /*void writeObject(::java::io::ObjectOutputStream* arg0); (private) */

    // Generated
    JComboBox();
    JComboBox(ComboBoxModel* arg0);
    JComboBox(::java::lang::ObjectArray* arg0);
    JComboBox(::java::util::Vector* arg0);
protected:
    JComboBox(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

public: /* protected */
    virtual void setUI(::javax::swing::plaf::ComponentUI* arg0);

private:
    static ::java::lang::String*& uiClassID();
    virtual ::java::lang::Class* getClass0();
};
