// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/border/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/plaf/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/JComponent.hpp>
#include <javax/swing/ScrollPaneConstants.hpp>
#include <javax/accessibility/Accessible.hpp>

struct default_init_tag;

class javax::swing::JScrollPane
    : public JComponent
    , public virtual ScrollPaneConstants
    , public virtual ::javax::accessibility::Accessible
{

public:
    typedef JComponent super;

public: /* protected */
    JViewport* columnHeader {  };
    JScrollBar* horizontalScrollBar {  };
    int32_t horizontalScrollBarPolicy {  };
    ::java::awt::Component* lowerLeft {  };
    ::java::awt::Component* lowerRight {  };
    JViewport* rowHeader {  };

private:
    static ::java::lang::String* uiClassID_;

public: /* protected */
    ::java::awt::Component* upperLeft {  };
    ::java::awt::Component* upperRight {  };
    JScrollBar* verticalScrollBar {  };
    int32_t verticalScrollBarPolicy {  };
    JViewport* viewport {  };

private:
    ::javax::swing::border::Border* viewportBorder {  };
    bool wheelScrollState {  };

protected:
    void ctor();
    void ctor(::java::awt::Component* arg0);
    void ctor(int32_t arg0, int32_t arg1);
    void ctor(::java::awt::Component* arg0, int32_t arg1, int32_t arg2);

public:
    virtual JScrollBar* createHorizontalScrollBar();
    virtual JScrollBar* createVerticalScrollBar();

public: /* protected */
    virtual JViewport* createViewport();

public:
    ::javax::accessibility::AccessibleContext* getAccessibleContext() override;
    virtual JViewport* getColumnHeader();
    virtual ::java::awt::Component* getCorner(::java::lang::String* arg0);
    virtual JScrollBar* getHorizontalScrollBar();
    virtual int32_t getHorizontalScrollBarPolicy();
    virtual JViewport* getRowHeader();
    virtual ::javax::swing::plaf::ScrollPaneUI* getUI();
    ::java::lang::String* getUIClassID() override;
    virtual JScrollBar* getVerticalScrollBar();
    virtual int32_t getVerticalScrollBarPolicy();
    virtual JViewport* getViewport();
    virtual ::javax::swing::border::Border* getViewportBorder();
    virtual ::java::awt::Rectangle* getViewportBorderBounds();
    bool isValidateRoot() override;
    virtual bool isWheelScrollingEnabled();

public: /* protected */
    ::java::lang::String* paramString() override;

public:
    virtual void setColumnHeader(JViewport* arg0);
    virtual void setColumnHeaderView(::java::awt::Component* arg0);
    void setComponentOrientation(::java::awt::ComponentOrientation* arg0) override;
    virtual void setCorner(::java::lang::String* arg0, ::java::awt::Component* arg1);
    virtual void setHorizontalScrollBar(JScrollBar* arg0);
    virtual void setHorizontalScrollBarPolicy(int32_t arg0);
    void setLayout(::java::awt::LayoutManager* arg0) override;
    virtual void setRowHeader(JViewport* arg0);
    virtual void setRowHeaderView(::java::awt::Component* arg0);
    virtual void setUI(::javax::swing::plaf::ScrollPaneUI* arg0);
    virtual void setVerticalScrollBar(JScrollBar* arg0);
    virtual void setVerticalScrollBarPolicy(int32_t arg0);
    virtual void setViewport(JViewport* arg0);
    virtual void setViewportBorder(::javax::swing::border::Border* arg0);
    virtual void setViewportView(::java::awt::Component* arg0);
    virtual void setWheelScrollingEnabled(bool arg0);
    void updateUI() override;
    /*void writeObject(::java::io::ObjectOutputStream* arg0); (private) */

    // Generated
    JScrollPane();
    JScrollPane(::java::awt::Component* arg0);
    JScrollPane(int32_t arg0, int32_t arg1);
    JScrollPane(::java::awt::Component* arg0, int32_t arg1, int32_t arg2);
protected:
    JScrollPane(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

public: /* protected */
    virtual void setUI(::javax::swing::plaf::ComponentUI* newUI);

private:
    static ::java::lang::String*& uiClassID();
    virtual ::java::lang::Class* getClass0();
};
