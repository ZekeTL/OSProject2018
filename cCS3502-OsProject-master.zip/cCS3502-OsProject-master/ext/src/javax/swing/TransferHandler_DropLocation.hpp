// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct default_init_tag;

class javax::swing::TransferHandler_DropLocation
    : public virtual ::java::lang::Object
{

public:
    typedef ::java::lang::Object super;

private:
    ::java::awt::Point* dropPoint {  };

protected:
    void ctor(::java::awt::Point* arg0);

public:
    ::java::awt::Point* getDropPoint();
    ::java::lang::String* toString() override;

    // Generated

public: /* protected */
    TransferHandler_DropLocation(::java::awt::Point* arg0);
protected:
    TransferHandler_DropLocation(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
