// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/AbstractButton_AccessibleAbstractButton.hpp>

struct default_init_tag;

class javax::swing::JButton_AccessibleJButton
    : public AbstractButton_AccessibleAbstractButton
{

public:
    typedef AbstractButton_AccessibleAbstractButton super;

public: /* package */
    JButton* this$0 {  };

protected:
    void ctor();

public:
    ::javax::accessibility::AccessibleRole* getAccessibleRole() override;

    // Generated

public: /* protected */
    JButton_AccessibleJButton(JButton *JButton_this);
protected:
    JButton_AccessibleJButton(JButton *JButton_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JButton *JButton_this;

private:
    virtual ::java::lang::Class* getClass0();
};
