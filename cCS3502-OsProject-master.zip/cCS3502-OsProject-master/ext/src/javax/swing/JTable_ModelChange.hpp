// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct default_init_tag;

class javax::swing::JTable_ModelChange final
    : public ::java::lang::Object
{

public:
    typedef ::java::lang::Object super;

public: /* package */
    bool allRowsChanged {  };
    int32_t endModelIndex {  };
    ::javax::swing::event::TableModelEvent* event {  };
    int32_t length {  };
    int32_t modelRowCount {  };
    int32_t startModelIndex {  };
    JTable* this$0 {  };
    int32_t type {  };

protected:
    void ctor(::javax::swing::event::TableModelEvent* arg0);

    // Generated

public: /* package */
    JTable_ModelChange(JTable *JTable_this, ::javax::swing::event::TableModelEvent* arg0);
protected:
    JTable_ModelChange(JTable *JTable_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JTable *JTable_this;

private:
    virtual ::java::lang::Class* getClass0();
};
