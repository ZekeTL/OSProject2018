// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct javax::swing::ScrollPaneConstants
    : public virtual ::java::lang::Object
{

private:
    static ::java::lang::String* COLUMN_HEADER_;
    static ::java::lang::String* HORIZONTAL_SCROLLBAR_;

public:
    static constexpr int32_t HORIZONTAL_SCROLLBAR_ALWAYS { int32_t(32) };
    static constexpr int32_t HORIZONTAL_SCROLLBAR_AS_NEEDED { int32_t(30) };
    static constexpr int32_t HORIZONTAL_SCROLLBAR_NEVER { int32_t(31) };

private:
    static ::java::lang::String* HORIZONTAL_SCROLLBAR_POLICY_;
    static ::java::lang::String* LOWER_LEADING_CORNER_;
    static ::java::lang::String* LOWER_LEFT_CORNER_;
    static ::java::lang::String* LOWER_RIGHT_CORNER_;
    static ::java::lang::String* LOWER_TRAILING_CORNER_;
    static ::java::lang::String* ROW_HEADER_;
    static ::java::lang::String* UPPER_LEADING_CORNER_;
    static ::java::lang::String* UPPER_LEFT_CORNER_;
    static ::java::lang::String* UPPER_RIGHT_CORNER_;
    static ::java::lang::String* UPPER_TRAILING_CORNER_;
    static ::java::lang::String* VERTICAL_SCROLLBAR_;

public:
    static constexpr int32_t VERTICAL_SCROLLBAR_ALWAYS { int32_t(22) };
    static constexpr int32_t VERTICAL_SCROLLBAR_AS_NEEDED { int32_t(20) };
    static constexpr int32_t VERTICAL_SCROLLBAR_NEVER { int32_t(21) };

private:
    static ::java::lang::String* VERTICAL_SCROLLBAR_POLICY_;
    static ::java::lang::String* VIEWPORT_;


    // Generated

public:
    static ::java::lang::Class *class_();
    static ::java::lang::String*& COLUMN_HEADER();
    static ::java::lang::String*& HORIZONTAL_SCROLLBAR();
    static ::java::lang::String*& HORIZONTAL_SCROLLBAR_POLICY();
    static ::java::lang::String*& LOWER_LEADING_CORNER();
    static ::java::lang::String*& LOWER_LEFT_CORNER();
    static ::java::lang::String*& LOWER_RIGHT_CORNER();
    static ::java::lang::String*& LOWER_TRAILING_CORNER();
    static ::java::lang::String*& ROW_HEADER();
    static ::java::lang::String*& UPPER_LEADING_CORNER();
    static ::java::lang::String*& UPPER_LEFT_CORNER();
    static ::java::lang::String*& UPPER_RIGHT_CORNER();
    static ::java::lang::String*& UPPER_TRAILING_CORNER();
    static ::java::lang::String*& VERTICAL_SCROLLBAR();
    static ::java::lang::String*& VERTICAL_SCROLLBAR_POLICY();
    static ::java::lang::String*& VIEWPORT();
};
