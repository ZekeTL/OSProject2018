// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/Dialog.hpp>
#include <javax/swing/WindowConstants.hpp>
#include <javax/accessibility/Accessible.hpp>
#include <javax/swing/RootPaneContainer.hpp>
#include <javax/swing/TransferHandler_HasGetTransferHandler.hpp>

struct default_init_tag;

class javax::swing::JDialog
    : public ::java::awt::Dialog
    , public virtual WindowConstants
    , public virtual ::javax::accessibility::Accessible
    , public virtual RootPaneContainer
    , public virtual TransferHandler_HasGetTransferHandler
{

public:
    typedef ::java::awt::Dialog super;

public: /* protected */
    ::javax::accessibility::AccessibleContext* accessibleContext {  };

private:
    int32_t defaultCloseOperation {  };
    static ::java::lang::Object* defaultLookAndFeelDecoratedKey_;

public: /* protected */
    JRootPane* rootPane {  };
    bool rootPaneCheckingEnabled {  };

private:
    TransferHandler* transferHandler {  };

protected:
    void ctor();
    void ctor(::java::awt::Frame* arg0);
    void ctor(::java::awt::Dialog* arg0);
    void ctor(::java::awt::Window* arg0);
    void ctor(::java::awt::Frame* arg0, bool arg1);
    void ctor(::java::awt::Frame* arg0, ::java::lang::String* arg1);
    void ctor(::java::awt::Dialog* arg0, bool arg1);
    void ctor(::java::awt::Dialog* arg0, ::java::lang::String* arg1);
    void ctor(::java::awt::Window* arg0, ::java::awt::Dialog_ModalityType* arg1);
    void ctor(::java::awt::Window* arg0, ::java::lang::String* arg1);
    void ctor(::java::awt::Frame* arg0, ::java::lang::String* arg1, bool arg2);
    void ctor(::java::awt::Dialog* arg0, ::java::lang::String* arg1, bool arg2);
    void ctor(::java::awt::Window* arg0, ::java::lang::String* arg1, ::java::awt::Dialog_ModalityType* arg2);
    void ctor(::java::awt::Frame* arg0, ::java::lang::String* arg1, bool arg2, ::java::awt::GraphicsConfiguration* arg3);
    void ctor(::java::awt::Dialog* arg0, ::java::lang::String* arg1, bool arg2, ::java::awt::GraphicsConfiguration* arg3);
    void ctor(::java::awt::Window* arg0, ::java::lang::String* arg1, ::java::awt::Dialog_ModalityType* arg2, ::java::awt::GraphicsConfiguration* arg3);

public: /* protected */
    void addImpl(::java::awt::Component* arg0, ::java::lang::Object* arg1, int32_t arg2) override;
    virtual JRootPane* createRootPane();
    virtual void dialogInit();

public:
    ::javax::accessibility::AccessibleContext* getAccessibleContext() override;
    ::java::awt::Container* getContentPane() override;
    virtual int32_t getDefaultCloseOperation();
    ::java::awt::Component* getGlassPane() override;
    ::java::awt::Graphics* getGraphics() override;
    virtual JMenuBar* getJMenuBar();
    JLayeredPane* getLayeredPane() override;
    JRootPane* getRootPane() override;
    TransferHandler* getTransferHandler() override;
    static bool isDefaultLookAndFeelDecorated();

public: /* protected */
    virtual bool isRootPaneCheckingEnabled();
    ::java::lang::String* paramString() override;
    void processWindowEvent(::java::awt::event::WindowEvent* arg0) override;

public:
    void remove(::java::awt::Component* arg0) override;
    void repaint(int64_t arg0, int32_t arg1, int32_t arg2, int32_t arg3, int32_t arg4) override;
    void setContentPane(::java::awt::Container* arg0) override;
    virtual void setDefaultCloseOperation(int32_t arg0);
    static void setDefaultLookAndFeelDecorated(bool arg0);
    void setGlassPane(::java::awt::Component* arg0) override;
    virtual void setJMenuBar(JMenuBar* arg0);
    void setLayeredPane(JLayeredPane* arg0) override;
    void setLayout(::java::awt::LayoutManager* arg0) override;

public: /* protected */
    virtual void setRootPane(JRootPane* arg0);
    virtual void setRootPaneCheckingEnabled(bool arg0);

public:
    virtual void setTransferHandler(TransferHandler* arg0);
    void update(::java::awt::Graphics* arg0) override;

    // Generated
    JDialog();
    JDialog(::java::awt::Frame* arg0);
    JDialog(::java::awt::Dialog* arg0);
    JDialog(::java::awt::Window* arg0);
    JDialog(::java::awt::Frame* arg0, bool arg1);
    JDialog(::java::awt::Frame* arg0, ::java::lang::String* arg1);
    JDialog(::java::awt::Dialog* arg0, bool arg1);
    JDialog(::java::awt::Dialog* arg0, ::java::lang::String* arg1);
    JDialog(::java::awt::Window* arg0, ::java::awt::Dialog_ModalityType* arg1);
    JDialog(::java::awt::Window* arg0, ::java::lang::String* arg1);
    JDialog(::java::awt::Frame* arg0, ::java::lang::String* arg1, bool arg2);
    JDialog(::java::awt::Dialog* arg0, ::java::lang::String* arg1, bool arg2);
    JDialog(::java::awt::Window* arg0, ::java::lang::String* arg1, ::java::awt::Dialog_ModalityType* arg2);
    JDialog(::java::awt::Frame* arg0, ::java::lang::String* arg1, bool arg2, ::java::awt::GraphicsConfiguration* arg3);
    JDialog(::java::awt::Dialog* arg0, ::java::lang::String* arg1, bool arg2, ::java::awt::GraphicsConfiguration* arg3);
    JDialog(::java::awt::Window* arg0, ::java::lang::String* arg1, ::java::awt::Dialog_ModalityType* arg2, ::java::awt::GraphicsConfiguration* arg3);
protected:
    JDialog(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    virtual void remove(int32_t arg0);
    void remove(::java::awt::MenuComponent* popup);
    virtual void repaint();
    virtual void repaint(int64_t tm);
    virtual void repaint(int32_t x, int32_t y, int32_t width, int32_t height);

private:
    static ::java::lang::Object*& defaultLookAndFeelDecoratedKey();
    virtual ::java::lang::Class* getClass0();
};
