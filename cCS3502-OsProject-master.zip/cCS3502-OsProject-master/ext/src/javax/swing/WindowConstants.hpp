// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct javax::swing::WindowConstants
    : public virtual ::java::lang::Object
{
    static constexpr int32_t DISPOSE_ON_CLOSE { int32_t(2) };
    static constexpr int32_t DO_NOTHING_ON_CLOSE { int32_t(0) };
    static constexpr int32_t EXIT_ON_CLOSE { int32_t(3) };
    static constexpr int32_t HIDE_ON_CLOSE { int32_t(1) };


    // Generated
    static ::java::lang::Class *class_();
};
