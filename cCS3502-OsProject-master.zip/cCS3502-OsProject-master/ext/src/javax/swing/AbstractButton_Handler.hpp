// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/awt/event/ActionListener.hpp>
#include <javax/swing/event/ChangeListener.hpp>
#include <java/awt/event/ItemListener.hpp>
#include <java/io/Serializable.hpp>

struct default_init_tag;

class javax::swing::AbstractButton_Handler
    : public virtual ::java::lang::Object
    , public virtual ::java::awt::event::ActionListener
    , public virtual ::javax::swing::event::ChangeListener
    , public virtual ::java::awt::event::ItemListener
    , public virtual ::java::io::Serializable
{

public:
    typedef ::java::lang::Object super;

public: /* package */
    AbstractButton* this$0 {  };

protected:
    void ctor();

public:
    void actionPerformed(::java::awt::event::ActionEvent* arg0) override;
    void itemStateChanged(::java::awt::event::ItemEvent* arg0) override;
    void stateChanged(::javax::swing::event::ChangeEvent* arg0) override;

    // Generated

public: /* package */
    AbstractButton_Handler(AbstractButton *AbstractButton_this);
protected:
    AbstractButton_Handler(AbstractButton *AbstractButton_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    AbstractButton *AbstractButton_this;

private:
    virtual ::java::lang::Class* getClass0();
};
