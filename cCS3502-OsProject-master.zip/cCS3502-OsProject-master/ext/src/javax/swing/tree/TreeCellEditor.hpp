// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/tree/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/CellEditor.hpp>

struct javax::swing::tree::TreeCellEditor
    : public virtual ::javax::swing::CellEditor
{

    virtual ::java::awt::Component* getTreeCellEditorComponent(::javax::swing::JTree* arg0, ::java::lang::Object* arg1, bool arg2, bool arg3, bool arg4, int32_t arg5) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
