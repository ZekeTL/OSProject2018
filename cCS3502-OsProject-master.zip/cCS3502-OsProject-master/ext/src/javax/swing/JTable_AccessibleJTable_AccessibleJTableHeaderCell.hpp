// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/beans/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/table/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/AccessibleContext.hpp>
#include <javax/accessibility/Accessible.hpp>
#include <javax/accessibility/AccessibleComponent.hpp>

struct default_init_tag;

class javax::swing::JTable_AccessibleJTable_AccessibleJTableHeaderCell
    : public ::javax::accessibility::AccessibleContext
    , public virtual ::javax::accessibility::Accessible
    , public virtual ::javax::accessibility::AccessibleComponent
{

public:
    typedef ::javax::accessibility::AccessibleContext super;

private:
    int32_t column {  };
    ::javax::swing::table::JTableHeader* parent {  };
    ::java::awt::Component* rendererComponent {  };
    int32_t row {  };

public: /* package */
    JTable_AccessibleJTable* this$1 {  };

protected:
    void ctor(int32_t arg0, int32_t arg1, ::javax::swing::table::JTableHeader* arg2, ::java::awt::Component* arg3);

public:
    void addFocusListener(::java::awt::event::FocusListener* arg0) override;
    void addPropertyChangeListener(::java::beans::PropertyChangeListener* arg0) override;
    bool contains(::java::awt::Point* arg0) override;
    ::javax::accessibility::AccessibleAction* getAccessibleAction() override;
    ::javax::accessibility::Accessible* getAccessibleAt(::java::awt::Point* arg0) override;
    ::javax::accessibility::Accessible* getAccessibleChild(int32_t arg0) override;
    int32_t getAccessibleChildrenCount() override;
    ::javax::accessibility::AccessibleComponent* getAccessibleComponent() override;
    ::javax::accessibility::AccessibleContext* getAccessibleContext() override;
    ::java::lang::String* getAccessibleDescription() override;
    int32_t getAccessibleIndexInParent() override;
    ::java::lang::String* getAccessibleName() override;
    ::javax::accessibility::Accessible* getAccessibleParent() override;
    ::javax::accessibility::AccessibleRole* getAccessibleRole() override;
    ::javax::accessibility::AccessibleSelection* getAccessibleSelection() override;
    ::javax::accessibility::AccessibleStateSet* getAccessibleStateSet() override;
    ::javax::accessibility::AccessibleText* getAccessibleText() override;
    ::javax::accessibility::AccessibleValue* getAccessibleValue() override;
    ::java::awt::Color* getBackground() override;
    ::java::awt::Rectangle* getBounds() override;
    /*::javax::accessibility::AccessibleContext* getCurrentAccessibleContext(); (private) */
    /*::java::awt::Component* getCurrentComponent(); (private) */
    ::java::awt::Cursor* getCursor() override;
    ::java::awt::Font* getFont() override;
    ::java::awt::FontMetrics* getFontMetrics(::java::awt::Font* arg0) override;
    ::java::awt::Color* getForeground() override;
    ::java::util::Locale* getLocale() override;
    ::java::awt::Point* getLocation() override;
    ::java::awt::Point* getLocationOnScreen() override;
    ::java::awt::Dimension* getSize() override;
    bool isEnabled() override;
    bool isFocusTraversable() override;
    bool isShowing() override;
    bool isVisible() override;
    void removeFocusListener(::java::awt::event::FocusListener* arg0) override;
    void removePropertyChangeListener(::java::beans::PropertyChangeListener* arg0) override;
    void requestFocus() override;
    void setAccessibleDescription(::java::lang::String* arg0) override;
    void setAccessibleName(::java::lang::String* arg0) override;
    void setBackground(::java::awt::Color* arg0) override;
    void setBounds(::java::awt::Rectangle* arg0) override;
    void setCursor(::java::awt::Cursor* arg0) override;
    void setEnabled(bool arg0) override;
    void setFont(::java::awt::Font* arg0) override;
    void setForeground(::java::awt::Color* arg0) override;
    void setLocation(::java::awt::Point* arg0) override;
    void setSize(::java::awt::Dimension* arg0) override;
    void setVisible(bool arg0) override;

    // Generated
    JTable_AccessibleJTable_AccessibleJTableHeaderCell(JTable_AccessibleJTable *JTable_AccessibleJTable_this, int32_t arg0, int32_t arg1, ::javax::swing::table::JTableHeader* arg2, ::java::awt::Component* arg3);
protected:
    JTable_AccessibleJTable_AccessibleJTableHeaderCell(JTable_AccessibleJTable *JTable_AccessibleJTable_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JTable_AccessibleJTable *JTable_AccessibleJTable_this;

private:
    virtual ::java::lang::Class* getClass0();
};
