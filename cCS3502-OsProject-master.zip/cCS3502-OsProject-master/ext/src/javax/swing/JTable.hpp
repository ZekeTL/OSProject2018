// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/print/fwd-CS3502-OsProject-master.hpp>
#include <java/beans/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/text/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/print/fwd-CS3502-OsProject-master.hpp>
#include <javax/print/attribute/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/plaf/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/table/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/JComponent.hpp>
#include <javax/swing/event/TableModelListener.hpp>
#include <javax/swing/Scrollable.hpp>
#include <javax/swing/event/TableColumnModelListener.hpp>
#include <javax/swing/event/ListSelectionListener.hpp>
#include <javax/swing/event/CellEditorListener.hpp>
#include <javax/accessibility/Accessible.hpp>
#include <javax/swing/event/RowSorterListener.hpp>
#include <javax/swing/JTable_DropLocation.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace io
    {
typedef ::SubArray< ::java::io::Serializable, ::java::lang::ObjectArray > SerializableArray;
    } // io

    namespace lang
    {
typedef ::SubArray< ::java::lang::Cloneable, ObjectArray > CloneableArray;
typedef ::SubArray< ::java::lang::ObjectArray, CloneableArray, ::java::io::SerializableArray > ObjectArrayArray;
    } // lang
} // java

struct default_init_tag;

class javax::swing::JTable
    : public JComponent
    , public virtual ::javax::swing::event::TableModelListener
    , public virtual Scrollable
    , public virtual ::javax::swing::event::TableColumnModelListener
    , public virtual ::javax::swing::event::ListSelectionListener
    , public virtual ::javax::swing::event::CellEditorListener
    , public virtual ::javax::accessibility::Accessible
    , public virtual ::javax::swing::event::RowSorterListener
{

public:
    typedef JComponent super;

private:
    static bool $assertionsDisabled_;

public:
    static constexpr int32_t AUTO_RESIZE_ALL_COLUMNS { int32_t(4) };
    static constexpr int32_t AUTO_RESIZE_LAST_COLUMN { int32_t(3) };
    static constexpr int32_t AUTO_RESIZE_NEXT_COLUMN { int32_t(1) };
    static constexpr int32_t AUTO_RESIZE_OFF { int32_t(0) };
    static constexpr int32_t AUTO_RESIZE_SUBSEQUENT_COLUMNS { int32_t(2) };

public: /* protected */
    bool autoCreateColumnsFromModel {  };

private:
    bool autoCreateRowSorter {  };

public: /* protected */
    int32_t autoResizeMode {  };
    ::javax::swing::table::TableCellEditor* cellEditor {  };
    bool cellSelectionEnabled {  };
    ::javax::swing::table::TableColumnModel* columnModel {  };

private:
    bool columnSelectionAdjusting {  };

public: /* protected */
    ::javax::swing::table::TableModel* dataModel {  };
    ::java::util::Hashtable* defaultEditorsByColumnClass {  };
    ::java::util::Hashtable* defaultRenderersByColumnClass {  };

private:
    bool dragEnabled {  };
    JTable_DropLocation* dropLocation {  };
    DropMode* dropMode {  };

public: /* protected */
    int32_t editingColumn {  };
    int32_t editingRow {  };
    ::java::awt::Component* editorComp {  };

private:
    ::java::beans::PropertyChangeListener* editorRemover {  };
    bool fillsViewportHeight {  };

public: /* protected */
    ::java::awt::Color* gridColor {  };

private:
    bool ignoreSortChange {  };
    bool isRowHeightSet {  };

public: /* protected */
    ::java::awt::Dimension* preferredViewportSize {  };

private:
    ::java::lang::Throwable* printError {  };

public: /* protected */
    int32_t rowHeight {  };
    int32_t rowMargin {  };

private:
    SizeSequence* rowModel {  };
    bool rowSelectionAdjusting {  };

public: /* protected */
    bool rowSelectionAllowed {  };
    ::java::awt::Color* selectionBackground {  };
    ::java::awt::Color* selectionForeground {  };
    ListSelectionModel* selectionModel {  };
    bool showHorizontalLines {  };
    bool showVerticalLines {  };

private:
    JTable_SortManager* sortManager {  };
    bool sorterChanged_ {  };
    bool surrendersFocusOnKeystroke {  };

public: /* protected */
    ::javax::swing::table::JTableHeader* tableHeader {  };

private:
    static ::java::lang::String* uiClassID_;
    bool updateSelectionOnSort {  };

protected:
    void ctor();
    void ctor(::javax::swing::table::TableModel* arg0);
    void ctor(::javax::swing::table::TableModel* arg0, ::javax::swing::table::TableColumnModel* arg1);
    void ctor(int32_t arg0, int32_t arg1);
    void ctor(::java::util::Vector* arg0, ::java::util::Vector* arg1);
    void ctor(::java::lang::ObjectArrayArray* arg0, ::java::lang::ObjectArray* arg1);
    void ctor(::javax::swing::table::TableModel* arg0, ::javax::swing::table::TableColumnModel* arg1, ListSelectionModel* arg2);
    /*void accommodateDelta(int32_t arg0, int32_t arg1); (private) */

public:
    virtual void addColumn(::javax::swing::table::TableColumn* arg0);
    virtual void addColumnSelectionInterval(int32_t arg0, int32_t arg1);
    void addNotify() override;
    virtual void addRowSelectionInterval(int32_t arg0, int32_t arg1);
    /*void adjustSizes(int64_t arg0, JTable_Resizable3* arg1, bool arg2); (private) */
    /*void adjustSizes(int64_t arg0, JTable_Resizable2* arg1, bool arg2); (private) */
    /*int32_t boundColumn(int32_t arg0); (private) */
    /*int32_t boundRow(int32_t arg0); (private) */
    virtual void changeSelection(int32_t arg0, int32_t arg1, bool arg2, bool arg3);
    /*void changeSelectionModel(ListSelectionModel* arg0, int32_t arg1, bool arg2, bool arg3, bool arg4, int32_t arg5, bool arg6); (private) */
    virtual void clearSelection();
    /*void clearSelectionAndLeadAnchor(); (private) */
    void columnAdded(::javax::swing::event::TableColumnModelEvent* arg0) override;
    virtual int32_t columnAtPoint(::java::awt::Point* arg0);
    void columnMarginChanged(::javax::swing::event::ChangeEvent* arg0) override;
    void columnMoved(::javax::swing::event::TableColumnModelEvent* arg0) override;
    void columnRemoved(::javax::swing::event::TableColumnModelEvent* arg0) override;
    void columnSelectionChanged(::javax::swing::event::ListSelectionEvent* arg0) override;

public: /* package */
    void compWriteObjectNotify() override;

public: /* protected */
    virtual void configureEnclosingScrollPane();
    /*void configureEnclosingScrollPaneUI(); (private) */

public:
    virtual int32_t convertColumnIndexToModel(int32_t arg0);
    virtual int32_t convertColumnIndexToView(int32_t arg0);
    virtual int32_t convertRowIndexToModel(int32_t arg0);
    /*int32_t convertRowIndexToModel(::javax::swing::event::RowSorterEvent* arg0, int32_t arg1); (private) */
    virtual int32_t convertRowIndexToView(int32_t arg0);
    /*int32_t convertRowIndexToView(int32_t arg0, JTable_ModelChange* arg1); (private) */
    /*::int32_tArray* convertSelectionToModel(::javax::swing::event::RowSorterEvent* arg0); (private) */

public: /* protected */
    virtual ::javax::swing::table::TableColumnModel* createDefaultColumnModel();

public:
    virtual void createDefaultColumnsFromModel();

public: /* protected */
    virtual ::javax::swing::table::TableModel* createDefaultDataModel();
    virtual void createDefaultEditors();
    virtual void createDefaultRenderers();
    virtual ListSelectionModel* createDefaultSelectionModel();
    virtual ::javax::swing::table::JTableHeader* createDefaultTableHeader();

public:
    static JScrollPane* createScrollPaneForTable(JTable* arg0);
    void doLayout() override;

public: /* package */
    JTable_DropLocation* dropLocationForPoint(::java::awt::Point* arg0) override;

public:
    virtual bool editCellAt(int32_t arg0, int32_t arg1);
    virtual bool editCellAt(int32_t arg0, int32_t arg1, ::java::util::EventObject* arg2);
    void editingCanceled(::javax::swing::event::ChangeEvent* arg0) override;
    void editingStopped(::javax::swing::event::ChangeEvent* arg0) override;
    ::javax::accessibility::AccessibleContext* getAccessibleContext() override;
    /*int32_t getAdjustedIndex(int32_t arg0, bool arg1); (private) */
    virtual bool getAutoCreateColumnsFromModel();
    virtual bool getAutoCreateRowSorter();
    virtual int32_t getAutoResizeMode();
    virtual ::javax::swing::table::TableCellEditor* getCellEditor();
    virtual ::javax::swing::table::TableCellEditor* getCellEditor(int32_t arg0, int32_t arg1);
    virtual ::java::awt::Rectangle* getCellRect(int32_t arg0, int32_t arg1, bool arg2);
    virtual ::javax::swing::table::TableCellRenderer* getCellRenderer(int32_t arg0, int32_t arg1);
    virtual bool getCellSelectionEnabled();
    virtual ::javax::swing::table::TableColumn* getColumn(::java::lang::Object* arg0);
    virtual ::java::lang::Class* getColumnClass(int32_t arg0);
    virtual int32_t getColumnCount();
    virtual ::javax::swing::table::TableColumnModel* getColumnModel();
    virtual ::java::lang::String* getColumnName(int32_t arg0);
    virtual bool getColumnSelectionAllowed();
    virtual ::javax::swing::table::TableCellEditor* getDefaultEditor(::java::lang::Class* arg0);
    virtual ::javax::swing::table::TableCellRenderer* getDefaultRenderer(::java::lang::Class* arg0);
    virtual bool getDragEnabled();
    JTable_DropLocation* getDropLocation();
    DropMode* getDropMode();
    virtual int32_t getEditingColumn();
    virtual int32_t getEditingRow();
    virtual ::java::awt::Component* getEditorComponent();
    virtual bool getFillsViewportHeight();
    virtual ::java::awt::Color* getGridColor();
    virtual ::java::awt::Dimension* getIntercellSpacing();
    /*int32_t getLeadingCol(::java::awt::Rectangle* arg0); (private) */
    /*int32_t getLeadingRow(::java::awt::Rectangle* arg0); (private) */
    virtual ::javax::swing::table::TableModel* getModel();
    /*int32_t getNextBlockIncrement(::java::awt::Rectangle* arg0, int32_t arg1); (private) */
    ::java::awt::Dimension* getPreferredScrollableViewportSize() override;
    /*int32_t getPreviousBlockIncrement(::java::awt::Rectangle* arg0, int32_t arg1); (private) */
    virtual ::java::awt::print::Printable* getPrintable(JTable_PrintMode* arg0, ::java::text::MessageFormat* arg1, ::java::text::MessageFormat* arg2);
    /*::javax::swing::table::TableColumn* getResizingColumn(); (private) */
    virtual int32_t getRowCount();
    virtual int32_t getRowHeight();
    virtual int32_t getRowHeight(int32_t arg0);
    virtual int32_t getRowMargin();
    /*SizeSequence* getRowModel(); (private) */
    virtual bool getRowSelectionAllowed();
    virtual RowSorter* getRowSorter();
    int32_t getScrollableBlockIncrement(::java::awt::Rectangle* arg0, int32_t arg1, int32_t arg2) override;
    bool getScrollableTracksViewportHeight() override;
    bool getScrollableTracksViewportWidth() override;
    int32_t getScrollableUnitIncrement(::java::awt::Rectangle* arg0, int32_t arg1, int32_t arg2) override;
    virtual int32_t getSelectedColumn();
    virtual int32_t getSelectedColumnCount();
    virtual ::int32_tArray* getSelectedColumns();
    virtual int32_t getSelectedRow();
    virtual int32_t getSelectedRowCount();
    virtual ::int32_tArray* getSelectedRows();
    virtual ::java::awt::Color* getSelectionBackground();
    virtual ::java::awt::Color* getSelectionForeground();
    virtual ListSelectionModel* getSelectionModel();
    virtual bool getShowHorizontalLines();
    virtual bool getShowVerticalLines();
    virtual bool getSurrendersFocusOnKeystroke();
    virtual ::javax::swing::table::JTableHeader* getTableHeader();
    ::java::lang::String* getToolTipText(::java::awt::event::MouseEvent* arg0) override;
    /*int32_t getTrailingCol(::java::awt::Rectangle* arg0); (private) */
    /*int32_t getTrailingRow(::java::awt::Rectangle* arg0); (private) */
    virtual ::javax::swing::plaf::TableUI* getUI();
    ::java::lang::String* getUIClassID() override;
    virtual bool getUpdateSelectionOnSort();
    virtual ::java::lang::Object* getValueAt(int32_t arg0, int32_t arg1);

public: /* protected */
    virtual void initializeLocalVars();

public:
    virtual bool isCellEditable(int32_t arg0, int32_t arg1);
    virtual bool isCellSelected(int32_t arg0, int32_t arg1);
    virtual bool isColumnSelected(int32_t arg0);
    virtual bool isEditing();
    virtual bool isRowSelected(int32_t arg0);
    /*int32_t leadingEdge(::java::awt::Rectangle* arg0, int32_t arg1); (private) */
    /*int32_t limit(int32_t arg0, int32_t arg1, int32_t arg2); (private) */
    virtual void moveColumn(int32_t arg0, int32_t arg1);
    /*void notifySorter(JTable_ModelChange* arg0); (private) */

public: /* protected */
    ::java::lang::String* paramString() override;

public:
    virtual ::java::awt::Component* prepareEditor(::javax::swing::table::TableCellEditor* arg0, int32_t arg1, int32_t arg2);
    virtual ::java::awt::Component* prepareRenderer(::javax::swing::table::TableCellRenderer* arg0, int32_t arg1, int32_t arg2);
    virtual bool print();
    virtual bool print(JTable_PrintMode* arg0);
    virtual bool print(JTable_PrintMode* arg0, ::java::text::MessageFormat* arg1, ::java::text::MessageFormat* arg2);
    virtual bool print(JTable_PrintMode* arg0, ::java::text::MessageFormat* arg1, ::java::text::MessageFormat* arg2, bool arg3, ::javax::print::attribute::PrintRequestAttributeSet* arg4, bool arg5);
    virtual bool print(JTable_PrintMode* arg0, ::java::text::MessageFormat* arg1, ::java::text::MessageFormat* arg2, bool arg3, ::javax::print::attribute::PrintRequestAttributeSet* arg4, bool arg5, ::javax::print::PrintService* arg6);

public: /* protected */
    bool processKeyBinding(KeyStroke* arg0, ::java::awt::event::KeyEvent* arg1, int32_t arg2, bool arg3) override;
    /*void readObject(::java::io::ObjectInputStream* arg0); (private) */

public:
    virtual void removeColumn(::javax::swing::table::TableColumn* arg0);
    virtual void removeColumnSelectionInterval(int32_t arg0, int32_t arg1);
    virtual void removeEditor();
    void removeNotify() override;
    virtual void removeRowSelectionInterval(int32_t arg0, int32_t arg1);
    /*void repaintSortedRows(JTable_ModelChange* arg0); (private) */

public: /* protected */
    virtual void resizeAndRepaint();
    /*void restoreSortingEditingRow(int32_t arg0); (private) */
    /*void restoreSortingSelection(::int32_tArray* arg0, int32_t arg1, JTable_ModelChange* arg2); (private) */

public:
    virtual int32_t rowAtPoint(::java::awt::Point* arg0);
    virtual void selectAll();
    virtual void setAutoCreateColumnsFromModel(bool arg0);
    virtual void setAutoCreateRowSorter(bool arg0);
    virtual void setAutoResizeMode(int32_t arg0);
    virtual void setCellEditor(::javax::swing::table::TableCellEditor* arg0);
    virtual void setCellSelectionEnabled(bool arg0);
    virtual void setColumnModel(::javax::swing::table::TableColumnModel* arg0);
    virtual void setColumnSelectionAllowed(bool arg0);
    virtual void setColumnSelectionInterval(int32_t arg0, int32_t arg1);
    virtual void setDefaultEditor(::java::lang::Class* arg0, ::javax::swing::table::TableCellEditor* arg1);
    virtual void setDefaultRenderer(::java::lang::Class* arg0, ::javax::swing::table::TableCellRenderer* arg1);
    virtual void setDragEnabled(bool arg0);

public: /* package */
    ::java::lang::Object* setDropLocation(TransferHandler_DropLocation* arg0, ::java::lang::Object* arg1, bool arg2) override;

public:
    void setDropMode(DropMode* arg0);
    virtual void setEditingColumn(int32_t arg0);
    virtual void setEditingRow(int32_t arg0);
    virtual void setFillsViewportHeight(bool arg0);
    virtual void setGridColor(::java::awt::Color* arg0);
    virtual void setIntercellSpacing(::java::awt::Dimension* arg0);
    virtual void setModel(::javax::swing::table::TableModel* arg0);
    virtual void setPreferredScrollableViewportSize(::java::awt::Dimension* arg0);
    virtual void setRowHeight(int32_t arg0);
    virtual void setRowHeight(int32_t arg0, int32_t arg1);
    virtual void setRowMargin(int32_t arg0);
    virtual void setRowSelectionAllowed(bool arg0);
    virtual void setRowSelectionInterval(int32_t arg0, int32_t arg1);
    virtual void setRowSorter(RowSorter* arg0);
    virtual void setSelectionBackground(::java::awt::Color* arg0);
    virtual void setSelectionForeground(::java::awt::Color* arg0);
    virtual void setSelectionMode(int32_t arg0);
    virtual void setSelectionModel(ListSelectionModel* arg0);
    virtual void setShowGrid(bool arg0);
    virtual void setShowHorizontalLines(bool arg0);
    virtual void setShowVerticalLines(bool arg0);
    virtual void setSurrendersFocusOnKeystroke(bool arg0);
    virtual void setTableHeader(::javax::swing::table::JTableHeader* arg0);
    virtual void setUI(::javax::swing::plaf::TableUI* arg0);

public: /* package */
    void setUIProperty(::java::lang::String* arg0, ::java::lang::Object* arg1) override;

public:
    virtual void setUpdateSelectionOnSort(bool arg0);
    virtual void setValueAt(::java::lang::Object* arg0, int32_t arg1, int32_t arg2);
    /*void setWidthsFromPreferredWidths(bool arg0); (private) */
    virtual void sizeColumnsToFit(bool arg0);
    virtual void sizeColumnsToFit(int32_t arg0);
    /*void sortedTableChanged(::javax::swing::event::RowSorterEvent* arg0, ::javax::swing::event::TableModelEvent* arg1); (private) */
    void sorterChanged(::javax::swing::event::RowSorterEvent* arg0) override;
    void tableChanged(::javax::swing::event::TableModelEvent* arg0) override;
    /*void tableRowsDeleted(::javax::swing::event::TableModelEvent* arg0); (private) */
    /*void tableRowsInserted(::javax::swing::event::TableModelEvent* arg0); (private) */
    /*int32_t trailingEdge(::java::awt::Rectangle* arg0, int32_t arg1); (private) */

public: /* protected */
    virtual void unconfigureEnclosingScrollPane();

public:
    void updateUI() override;
    void valueChanged(::javax::swing::event::ListSelectionEvent* arg0) override;
    /*int32_t viewIndexForColumn(::javax::swing::table::TableColumn* arg0); (private) */
    /*void writeObject(::java::io::ObjectOutputStream* arg0); (private) */

    // Generated
    JTable();
    JTable(::javax::swing::table::TableModel* arg0);
    JTable(::javax::swing::table::TableModel* arg0, ::javax::swing::table::TableColumnModel* arg1);
    JTable(int32_t arg0, int32_t arg1);
    JTable(::java::util::Vector* arg0, ::java::util::Vector* arg1);
    JTable(::java::lang::ObjectArrayArray* arg0, ::java::lang::ObjectArray* arg1);
    JTable(::javax::swing::table::TableModel* arg0, ::javax::swing::table::TableColumnModel* arg1, ListSelectionModel* arg2);
protected:
    JTable(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    virtual ::java::lang::String* getToolTipText();
    void print(::java::awt::Graphics* arg0);

public: /* protected */
    virtual void setUI(::javax::swing::plaf::ComponentUI* arg0);

public: /* package */
    static bool& $assertionsDisabled();

private:
    static ::java::lang::String*& uiClassID();
    virtual ::java::lang::Class* getClass0();
};
