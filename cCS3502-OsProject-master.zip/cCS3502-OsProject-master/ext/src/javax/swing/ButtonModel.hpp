// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/ItemSelectable.hpp>

struct javax::swing::ButtonModel
    : public virtual ::java::awt::ItemSelectable
{

    virtual void addActionListener(::java::awt::event::ActionListener* arg0) = 0;
    virtual void addChangeListener(::javax::swing::event::ChangeListener* arg0) = 0;
    /*void addItemListener(::java::awt::event::ItemListener* arg0); (already declared) */
    virtual ::java::lang::String* getActionCommand() = 0;
    virtual int32_t getMnemonic() = 0;
    virtual bool isArmed() = 0;
    virtual bool isEnabled() = 0;
    virtual bool isPressed() = 0;
    virtual bool isRollover() = 0;
    virtual bool isSelected() = 0;
    virtual void removeActionListener(::java::awt::event::ActionListener* arg0) = 0;
    virtual void removeChangeListener(::javax::swing::event::ChangeListener* arg0) = 0;
    /*void removeItemListener(::java::awt::event::ItemListener* arg0); (already declared) */
    virtual void setActionCommand(::java::lang::String* arg0) = 0;
    virtual void setArmed(bool arg0) = 0;
    virtual void setEnabled(bool arg0) = 0;
    virtual void setGroup(ButtonGroup* arg0) = 0;
    virtual void setMnemonic(int32_t arg0) = 0;
    virtual void setPressed(bool arg0) = 0;
    virtual void setRollover(bool arg0) = 0;
    virtual void setSelected(bool arg0) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
