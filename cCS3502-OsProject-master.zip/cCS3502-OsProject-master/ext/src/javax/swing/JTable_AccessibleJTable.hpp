// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/beans/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/JComponent_AccessibleJComponent.hpp>
#include <javax/accessibility/AccessibleSelection.hpp>
#include <javax/swing/event/ListSelectionListener.hpp>
#include <javax/swing/event/TableModelListener.hpp>
#include <javax/swing/event/TableColumnModelListener.hpp>
#include <javax/swing/event/CellEditorListener.hpp>
#include <java/beans/PropertyChangeListener.hpp>
#include <javax/accessibility/AccessibleExtendedTable.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace javax
{
    namespace accessibility
    {
typedef ::SubArray< ::javax::accessibility::Accessible, ::java::lang::ObjectArray > AccessibleArray;
    } // accessibility
} // javax

struct default_init_tag;

class javax::swing::JTable_AccessibleJTable
    : public JComponent_AccessibleJComponent
    , public virtual ::javax::accessibility::AccessibleSelection
    , public virtual ::javax::swing::event::ListSelectionListener
    , public virtual ::javax::swing::event::TableModelListener
    , public virtual ::javax::swing::event::TableColumnModelListener
    , public virtual ::javax::swing::event::CellEditorListener
    , public virtual ::java::beans::PropertyChangeListener
    , public virtual ::javax::accessibility::AccessibleExtendedTable
{

public:
    typedef JComponent_AccessibleJComponent super;

private:
    ::javax::accessibility::Accessible* caption {  };
    ::javax::accessibility::AccessibleArray* columnDescription {  };

public: /* package */
    int32_t previousFocusedCol {  };
    int32_t previousFocusedRow {  };

private:
    ::javax::accessibility::AccessibleArray* rowDescription {  };
    ::javax::accessibility::Accessible* summary {  };

public: /* package */
    JTable* this$0 {  };

protected:
    void ctor();

public:
    void addAccessibleSelection(int32_t arg0) override;
    void clearAccessibleSelection() override;
    void columnAdded(::javax::swing::event::TableColumnModelEvent* arg0) override;
    void columnMarginChanged(::javax::swing::event::ChangeEvent* arg0) override;
    void columnMoved(::javax::swing::event::TableColumnModelEvent* arg0) override;
    void columnRemoved(::javax::swing::event::TableColumnModelEvent* arg0) override;
    void columnSelectionChanged(::javax::swing::event::ListSelectionEvent* arg0) override;
    void editingCanceled(::javax::swing::event::ChangeEvent* arg0) override;
    void editingStopped(::javax::swing::event::ChangeEvent* arg0) override;
    ::javax::accessibility::Accessible* getAccessibleAt(::java::awt::Point* arg0) override;
    ::javax::accessibility::Accessible* getAccessibleAt(int32_t arg0, int32_t arg1) override;
    ::javax::accessibility::Accessible* getAccessibleCaption() override;
    ::javax::accessibility::Accessible* getAccessibleChild(int32_t arg0) override;
    int32_t getAccessibleChildrenCount() override;
    int32_t getAccessibleColumn(int32_t arg0) override;
    virtual int32_t getAccessibleColumnAtIndex(int32_t arg0);
    int32_t getAccessibleColumnCount() override;
    ::javax::accessibility::Accessible* getAccessibleColumnDescription(int32_t arg0) override;
    int32_t getAccessibleColumnExtentAt(int32_t arg0, int32_t arg1) override;
    ::javax::accessibility::AccessibleTable* getAccessibleColumnHeader() override;
    int32_t getAccessibleIndex(int32_t arg0, int32_t arg1) override;
    virtual int32_t getAccessibleIndexAt(int32_t arg0, int32_t arg1);
    ::javax::accessibility::AccessibleRole* getAccessibleRole() override;
    int32_t getAccessibleRow(int32_t arg0) override;
    virtual int32_t getAccessibleRowAtIndex(int32_t arg0);
    int32_t getAccessibleRowCount() override;
    ::javax::accessibility::Accessible* getAccessibleRowDescription(int32_t arg0) override;
    int32_t getAccessibleRowExtentAt(int32_t arg0, int32_t arg1) override;
    ::javax::accessibility::AccessibleTable* getAccessibleRowHeader() override;
    ::javax::accessibility::AccessibleSelection* getAccessibleSelection() override;
    ::javax::accessibility::Accessible* getAccessibleSelection(int32_t arg0) override;
    int32_t getAccessibleSelectionCount() override;
    ::javax::accessibility::Accessible* getAccessibleSummary() override;
    ::javax::accessibility::AccessibleTable* getAccessibleTable() override;
    ::int32_tArray* getSelectedAccessibleColumns() override;
    ::int32_tArray* getSelectedAccessibleRows() override;
    bool isAccessibleChildSelected(int32_t arg0) override;
    bool isAccessibleColumnSelected(int32_t arg0) override;
    bool isAccessibleRowSelected(int32_t arg0) override;
    bool isAccessibleSelected(int32_t arg0, int32_t arg1) override;
    void propertyChange(::java::beans::PropertyChangeEvent* arg0) override;
    void removeAccessibleSelection(int32_t arg0) override;
    void selectAllAccessibleSelection() override;
    void setAccessibleCaption(::javax::accessibility::Accessible* arg0) override;
    void setAccessibleColumnDescription(int32_t arg0, ::javax::accessibility::Accessible* arg1) override;
    void setAccessibleColumnHeader(::javax::accessibility::AccessibleTable* arg0) override;
    void setAccessibleRowDescription(int32_t arg0, ::javax::accessibility::Accessible* arg1) override;
    void setAccessibleRowHeader(::javax::accessibility::AccessibleTable* arg0) override;
    void setAccessibleSummary(::javax::accessibility::Accessible* arg0) override;
    void tableChanged(::javax::swing::event::TableModelEvent* arg0) override;
    virtual void tableRowsDeleted(::javax::swing::event::TableModelEvent* arg0);
    virtual void tableRowsInserted(::javax::swing::event::TableModelEvent* arg0);
    void valueChanged(::javax::swing::event::ListSelectionEvent* arg0) override;

    // Generated

public: /* protected */
    JTable_AccessibleJTable(JTable *JTable_this);
protected:
    JTable_AccessibleJTable(JTable *JTable_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JTable *JTable_this;

private:
    virtual ::java::lang::Class* getClass0();
};
