// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct javax::swing::Scrollable
    : public virtual ::java::lang::Object
{

    virtual ::java::awt::Dimension* getPreferredScrollableViewportSize() = 0;
    virtual int32_t getScrollableBlockIncrement(::java::awt::Rectangle* arg0, int32_t arg1, int32_t arg2) = 0;
    virtual bool getScrollableTracksViewportHeight() = 0;
    virtual bool getScrollableTracksViewportWidth() = 0;
    virtual int32_t getScrollableUnitIncrement(::java::awt::Rectangle* arg0, int32_t arg1, int32_t arg2) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
