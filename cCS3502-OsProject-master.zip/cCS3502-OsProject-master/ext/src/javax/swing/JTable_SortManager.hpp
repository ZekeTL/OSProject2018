// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct default_init_tag;

class javax::swing::JTable_SortManager final
    : public ::java::lang::Object
{

public:
    typedef ::java::lang::Object super;

private:
    ::int32_tArray* lastModelSelection {  };
    int32_t modelLeadIndex {  };
    SizeSequence* modelRowSizes {  };
    ListSelectionModel* modelSelection {  };

public: /* package */
    RowSorter* sorter {  };

private:
    bool syncingSelection {  };

public: /* package */
    JTable* this$0 {  };

protected:
    void ctor(RowSorter* arg0);

public:
    void allChanged();
    /*void cacheModelSelection(::javax::swing::event::RowSorterEvent* arg0); (private) */
    /*void cacheSelection(::javax::swing::event::RowSorterEvent* arg0, JTable_ModelChange* arg1); (private) */
    void dispose();
    void prepareForChange(::javax::swing::event::RowSorterEvent* arg0, JTable_ModelChange* arg1);
    void processChange(::javax::swing::event::RowSorterEvent* arg0, JTable_ModelChange* arg1, bool arg2);
    /*void restoreSelection(JTable_ModelChange* arg0); (private) */
    void setViewRowHeight(int32_t arg0, int32_t arg1);
    /*void setViewRowHeightsFromModel(); (private) */
    void viewSelectionChanged(::javax::swing::event::ListSelectionEvent* arg0);

    // Generated

public: /* package */
    JTable_SortManager(JTable *JTable_this, RowSorter* arg0);
protected:
    JTable_SortManager(JTable *JTable_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JTable *JTable_this;

private:
    virtual ::java::lang::Class* getClass0();
};
