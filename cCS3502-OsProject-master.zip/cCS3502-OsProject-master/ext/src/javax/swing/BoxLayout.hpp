// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/awt/LayoutManager2.hpp>
#include <java/io/Serializable.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace io
    {
typedef ::SubArray< ::java::io::Serializable, ::java::lang::ObjectArray > SerializableArray;
    } // io
} // java

namespace javax
{
    namespace swing
    {
typedef ::SubArray< ::javax::swing::SizeRequirements, ::java::lang::ObjectArray, ::java::io::SerializableArray > SizeRequirementsArray;
    } // swing
} // javax

struct default_init_tag;

class javax::swing::BoxLayout
    : public virtual ::java::lang::Object
    , public virtual ::java::awt::LayoutManager2
    , public virtual ::java::io::Serializable
{

public:
    typedef ::java::lang::Object super;
    static constexpr int32_t LINE_AXIS { int32_t(2) };
    static constexpr int32_t PAGE_AXIS { int32_t(3) };
    static constexpr int32_t X_AXIS { int32_t(0) };
    static constexpr int32_t Y_AXIS { int32_t(1) };

private:
    int32_t axis {  };
    ::java::io::PrintStream* dbg {  };
    ::java::awt::Container* target {  };
    SizeRequirementsArray* xChildren {  };
    SizeRequirements* xTotal {  };
    SizeRequirementsArray* yChildren {  };
    SizeRequirements* yTotal {  };

protected:
    void ctor(::java::awt::Container* arg0, int32_t arg1);
    void ctor(::java::awt::Container* arg0, int32_t arg1, ::java::io::PrintStream* arg2);

public:
    void addLayoutComponent(::java::lang::String* arg0, ::java::awt::Component* arg1) override;
    void addLayoutComponent(::java::awt::Component* arg0, ::java::lang::Object* arg1) override;

public: /* package */
    virtual void checkContainer(::java::awt::Container* arg0);
    virtual void checkRequests();

public:
    int32_t getAxis();
    float getLayoutAlignmentX(::java::awt::Container* arg0) override;
    float getLayoutAlignmentY(::java::awt::Container* arg0) override;
    ::java::awt::Container* getTarget();
    void invalidateLayout(::java::awt::Container* arg0) override;
    void layoutContainer(::java::awt::Container* arg0) override;
    ::java::awt::Dimension* maximumLayoutSize(::java::awt::Container* arg0) override;
    ::java::awt::Dimension* minimumLayoutSize(::java::awt::Container* arg0) override;
    ::java::awt::Dimension* preferredLayoutSize(::java::awt::Container* arg0) override;
    void removeLayoutComponent(::java::awt::Component* arg0) override;
    /*int32_t resolveAxis(int32_t arg0, ::java::awt::ComponentOrientation* arg1); (private) */

    // Generated
    BoxLayout(::java::awt::Container* arg0, int32_t arg1);

public: /* package */
    BoxLayout(::java::awt::Container* arg0, int32_t arg1, ::java::io::PrintStream* arg2);
protected:
    BoxLayout(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
