// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/TransferHandler_DropLocation.hpp>

struct default_init_tag;

class javax::swing::JTable_DropLocation final
    : public TransferHandler_DropLocation
{

public:
    typedef TransferHandler_DropLocation super;

private:
    int32_t col {  };
    bool isInsertCol {  };
    bool isInsertRow_ {  };
    int32_t row {  };

    /*void ctor(::java::awt::Point* arg0, int32_t arg1, int32_t arg2, bool arg3, bool arg4); (private) */

public:
    int32_t getColumn();
    int32_t getRow();
    bool isInsertColumn();
    bool isInsertRow();
    ::java::lang::String* toString() override;

    // Generated
    JTable_DropLocation();
protected:
    JTable_DropLocation(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
