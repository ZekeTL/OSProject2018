// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/Segment.hpp>

struct default_init_tag;

class javax::swing::text::JTextComponent_AccessibleJTextComponent_IndexedSegment
    : public Segment
{

public:
    typedef Segment super;
    int32_t modelOffset {  };

public: /* package */
    JTextComponent_AccessibleJTextComponent* this$1 {  };

    /*void ctor(); (private) */

    // Generated

public:
    JTextComponent_AccessibleJTextComponent_IndexedSegment(JTextComponent_AccessibleJTextComponent *JTextComponent_AccessibleJTextComponent_this);
protected:
    JTextComponent_AccessibleJTextComponent_IndexedSegment(JTextComponent_AccessibleJTextComponent *JTextComponent_AccessibleJTextComponent_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JTextComponent_AccessibleJTextComponent *JTextComponent_AccessibleJTextComponent_this;

private:
    virtual ::java::lang::Class* getClass0();
};
