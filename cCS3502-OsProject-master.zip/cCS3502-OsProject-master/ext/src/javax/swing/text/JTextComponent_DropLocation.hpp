// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/TransferHandler_DropLocation.hpp>

struct default_init_tag;

class javax::swing::text::JTextComponent_DropLocation final
    : public ::javax::swing::TransferHandler_DropLocation
{

public:
    typedef ::javax::swing::TransferHandler_DropLocation super;

private:
    Position_Bias* bias {  };
    int32_t index {  };

    /*void ctor(::java::awt::Point* arg0, int32_t arg1, Position_Bias* arg2); (private) */

public:
    Position_Bias* getBias();
    int32_t getIndex();
    ::java::lang::String* toString() override;

    // Generated
    JTextComponent_DropLocation();
protected:
    JTextComponent_DropLocation(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
