// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/lang/Cloneable.hpp>
#include <java/text/CharacterIterator.hpp>
#include <java/lang/CharSequence.hpp>

struct default_init_tag;

class javax::swing::text::Segment
    : public virtual ::java::lang::Object
    , public virtual ::java::lang::Cloneable
    , public virtual ::java::text::CharacterIterator
    , public virtual ::java::lang::CharSequence
{

public:
    typedef ::java::lang::Object super;
    ::char16_tArray* array {  };
    int32_t count {  };
    int32_t offset {  };

private:
    bool partialReturn {  };
    int32_t pos {  };

protected:
    void ctor();
    void ctor(::char16_tArray* arg0, int32_t arg1, int32_t arg2);

public:
    char16_t charAt(int32_t arg0) override;
    ::java::lang::Object* clone() override;
    char16_t current() override;
    char16_t first() override;
    int32_t getBeginIndex() override;
    int32_t getEndIndex() override;
    int32_t getIndex() override;
    virtual bool isPartialReturn();
    char16_t last() override;
    int32_t length() override;
    char16_t next() override;
    char16_t previous() override;
    char16_t setIndex(int32_t arg0) override;
    virtual void setPartialReturn(bool arg0);
    ::java::lang::CharSequence* subSequence(int32_t arg0, int32_t arg1) override;
    ::java::lang::String* toString() override;

    // Generated
    Segment();
    Segment(::char16_tArray* arg0, int32_t arg1, int32_t arg2);
protected:
    Segment(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
