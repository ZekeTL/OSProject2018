// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/CaretEvent.hpp>
#include <javax/swing/event/ChangeListener.hpp>
#include <java/awt/event/FocusListener.hpp>
#include <java/awt/event/MouseListener.hpp>

struct default_init_tag;

class javax::swing::text::JTextComponent_MutableCaretEvent
    : public ::javax::swing::event::CaretEvent
    , public virtual ::javax::swing::event::ChangeListener
    , public virtual ::java::awt::event::FocusListener
    , public virtual ::java::awt::event::MouseListener
{

public:
    typedef ::javax::swing::event::CaretEvent super;

private:
    int32_t dot {  };
    bool dragActive {  };
    int32_t mark {  };

protected:
    void ctor(JTextComponent* arg0);

public: /* package */
    void fire();

public:
    void focusGained(::java::awt::event::FocusEvent* arg0) override;
    void focusLost(::java::awt::event::FocusEvent* arg0) override;
    int32_t getDot() override;
    int32_t getMark() override;
    void mouseClicked(::java::awt::event::MouseEvent* arg0) override;
    void mouseEntered(::java::awt::event::MouseEvent* arg0) override;
    void mouseExited(::java::awt::event::MouseEvent* arg0) override;
    void mousePressed(::java::awt::event::MouseEvent* arg0) override;
    void mouseReleased(::java::awt::event::MouseEvent* arg0) override;
    void stateChanged(::javax::swing::event::ChangeEvent* arg0) override;
    ::java::lang::String* toString() override;

    // Generated

public: /* package */
    JTextComponent_MutableCaretEvent(JTextComponent* arg0);
protected:
    JTextComponent_MutableCaretEvent(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
