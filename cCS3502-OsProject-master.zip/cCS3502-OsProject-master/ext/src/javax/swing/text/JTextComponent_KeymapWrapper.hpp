// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/InputMap.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace io
    {
typedef ::SubArray< ::java::io::Serializable, ::java::lang::ObjectArray > SerializableArray;
    } // io

    namespace awt
    {
typedef ::SubArray< ::java::awt::AWTKeyStroke, ::java::lang::ObjectArray, ::java::io::SerializableArray > AWTKeyStrokeArray;
    } // awt
} // java

namespace javax
{
    namespace swing
    {
typedef ::SubArray< ::javax::swing::KeyStroke, ::java::awt::AWTKeyStrokeArray > KeyStrokeArray;
    } // swing
} // javax

struct default_init_tag;

class javax::swing::text::JTextComponent_KeymapWrapper
    : public ::javax::swing::InputMap
{

public:
    typedef ::javax::swing::InputMap super;

private:
    static ::java::lang::Object* DefaultActionKey_;
    Keymap* keymap {  };

protected:
    void ctor(Keymap* arg0);

public:
    ::java::lang::Object* get(::javax::swing::KeyStroke* arg0) override;
    ::javax::swing::KeyStrokeArray* keys() override;
    int32_t size() override;

    // Generated

public: /* package */
    JTextComponent_KeymapWrapper(Keymap* arg0);
protected:
    JTextComponent_KeymapWrapper(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

public: /* package */
    static ::java::lang::Object*& DefaultActionKey();

private:
    virtual ::java::lang::Class* getClass0();
};
