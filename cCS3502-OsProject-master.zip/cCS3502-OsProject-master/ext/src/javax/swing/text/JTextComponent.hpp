// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <com/sun/beans/util/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/im/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/print/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/text/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/print/fwd-CS3502-OsProject-master.hpp>
#include <javax/print/attribute/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/plaf/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/JComponent.hpp>
#include <javax/swing/Scrollable.hpp>
#include <javax/accessibility/Accessible.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace util
    {
typedef ::SubArray< ::java::util::EventListener, ::java::lang::ObjectArray > EventListenerArray;
    } // util

    namespace awt
    {
        namespace event
        {
typedef ::SubArray< ::java::awt::event::ActionListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > ActionListenerArray;
        } // event
    } // awt
} // java

namespace javax
{
    namespace swing
    {
typedef ::SubArray< ::javax::swing::Action, ::java::lang::ObjectArray, ::java::awt::event::ActionListenerArray > ActionArray;

        namespace event
        {
typedef ::SubArray< ::javax::swing::event::CaretListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > CaretListenerArray;
        } // event

        namespace text
        {
typedef ::SubArray< ::javax::swing::text::JTextComponent_KeyBinding, ::java::lang::ObjectArray > JTextComponent_KeyBindingArray;
        } // text
    } // swing
} // javax

struct default_init_tag;

class javax::swing::text::JTextComponent
    : public ::javax::swing::JComponent
    , public virtual ::javax::swing::Scrollable
    , public virtual ::javax::accessibility::Accessible
{

public:
    typedef ::javax::swing::JComponent super;

private:
    static ::java::lang::String* DEFAULT_KEYMAP_;
    static ::java::lang::Object* FOCUSED_COMPONENT_;
    static ::java::lang::String* FOCUS_ACCELERATOR_KEY_;
    static ::java::lang::Object* KEYMAP_TABLE_;
    static ::com::sun::beans::util::Cache* METHOD_OVERRIDDEN_;
    Caret* caret {  };
    ::java::awt::Color* caretColor {  };
    JTextComponent_MutableCaretEvent* caretEvent {  };
    bool checkedInputOverride {  };
    SimpleAttributeSet* composedTextAttribute {  };
    JTextComponent_ComposedTextCaret* composedTextCaret {  };
    ::java::lang::String* composedTextContent {  };
    Position* composedTextEnd {  };
    Position* composedTextStart {  };
    static JTextComponent_DefaultTransferHandler* defaultTransferHandler_;
    ::java::awt::Color* disabledTextColor {  };
    bool dragEnabled {  };
    JTextComponent_DropLocation* dropLocation {  };
    ::javax::swing::DropMode* dropMode {  };
    bool editable {  };
    char16_t focusAccelerator {  };
    Highlighter* highlighter {  };
    ::java::awt::im::InputMethodRequests* inputMethodRequestsHandler {  };
    Keymap* keymap {  };
    Position* latestCommittedTextEnd {  };
    Position* latestCommittedTextStart {  };
    ::java::awt::Insets* margin {  };
    Document* model {  };
    NavigationFilter* navigationFilter {  };
    bool needToSendKeyTypedEvent {  };
    Caret* originalCaret {  };
    ::java::awt::Color* selectedTextColor {  };
    ::java::awt::Color* selectionColor {  };

protected:
    void ctor();

public:
    virtual void addCaretListener(::javax::swing::event::CaretListener* arg0);
    void addInputMethodListener(::java::awt::event::InputMethodListener* arg0) override;
    static Keymap* addKeymap(::java::lang::String* arg0, Keymap* arg1);

public: /* package */
    virtual bool composedTextExists();

public:
    virtual void copy();
    /*void createComposedTextAttribute(int32_t arg0, ::java::text::AttributedCharacterIterator* arg1); (private) */
    virtual void cut();

public: /* package */
    virtual JTextComponent_DropLocation* JTextComponent_dropLocationForPoint(::java::awt::Point* arg0);
    /*void exchangeCaret(Caret* arg0, Caret* arg1); (private) */

public: /* protected */
    virtual void fireCaretUpdate(::javax::swing::event::CaretEvent* arg0);

public:
    ::javax::accessibility::AccessibleContext* getAccessibleContext() override;
    virtual ::javax::swing::ActionArray* getActions();
    virtual Caret* getCaret();
    virtual ::java::awt::Color* getCaretColor();
    virtual ::javax::swing::event::CaretListenerArray* getCaretListeners();
    virtual int32_t getCaretPosition();
    /*int32_t getCurrentEventModifiers(); (private) */
    virtual ::java::awt::Color* getDisabledTextColor();
    virtual Document* getDocument();
    virtual bool getDragEnabled();
    JTextComponent_DropLocation* getDropLocation();
    ::javax::swing::DropMode* getDropMode();
    virtual char16_t getFocusAccelerator();

public: /* package */
    static JTextComponent* getFocusedComponent();

public:
    virtual Highlighter* getHighlighter();
    ::java::awt::im::InputMethodRequests* getInputMethodRequests() override;
    virtual Keymap* getKeymap();
    static Keymap* getKeymap(::java::lang::String* arg0);
    /*static ::java::util::HashMap* getKeymapTable(); (private) */
    virtual ::java::awt::Insets* getMargin();
    virtual NavigationFilter* getNavigationFilter();
    ::java::awt::Dimension* getPreferredScrollableViewportSize() override;
    virtual ::java::awt::print::Printable* getPrintable(::java::text::MessageFormat* arg0, ::java::text::MessageFormat* arg1);
    int32_t getScrollableBlockIncrement(::java::awt::Rectangle* arg0, int32_t arg1, int32_t arg2) override;
    bool getScrollableTracksViewportHeight() override;
    bool getScrollableTracksViewportWidth() override;
    int32_t getScrollableUnitIncrement(::java::awt::Rectangle* arg0, int32_t arg1, int32_t arg2) override;
    virtual ::java::lang::String* getSelectedText();
    virtual ::java::awt::Color* getSelectedTextColor();
    virtual ::java::awt::Color* getSelectionColor();
    virtual int32_t getSelectionEnd();
    virtual int32_t getSelectionStart();
    virtual ::java::lang::String* getText();
    virtual ::java::lang::String* getText(int32_t arg0, int32_t arg1);
    ::java::lang::String* getToolTipText(::java::awt::event::MouseEvent* arg0) override;
    virtual ::javax::swing::plaf::TextUI* getUI();
    /*void installDefaultTransferHandlerIfNecessary(); (private) */
    /*void invokeAction(::java::lang::String* arg0, ::javax::swing::Action* arg1); (private) */
    virtual bool isEditable();
    static void loadKeymap(Keymap* arg0, JTextComponent_KeyBindingArray* arg1, ::javax::swing::ActionArray* arg2);
    /*void mapCommittedTextToAction(::java::lang::String* arg0); (private) */
    virtual ::java::awt::Rectangle* modelToView(int32_t arg0);
    virtual void moveCaretPosition(int32_t arg0);

public: /* protected */
    ::java::lang::String* paramString() override;

public:
    virtual void paste();
    virtual bool print();
    virtual bool print(::java::text::MessageFormat* arg0, ::java::text::MessageFormat* arg1);
    virtual bool print(::java::text::MessageFormat* arg0, ::java::text::MessageFormat* arg1, bool arg2, ::javax::print::PrintService* arg3, ::javax::print::attribute::PrintRequestAttributeSet* arg4, bool arg5);

public: /* protected */
    void processInputMethodEvent(::java::awt::event::InputMethodEvent* arg0) override;

public:
    virtual void read(::java::io::Reader* arg0, ::java::lang::Object* arg1);
    /*void readObject(::java::io::ObjectInputStream* arg0); (private) */
    virtual void removeCaretListener(::javax::swing::event::CaretListener* arg0);
    static Keymap* removeKeymap(::java::lang::String* arg0);
    void removeNotify() override;
    /*void replaceInputMethodText(::java::awt::event::InputMethodEvent* arg0); (private) */
    virtual void replaceSelection(::java::lang::String* arg0);

public: /* protected */
    virtual void restoreComposedText();
    virtual bool saveComposedText(int32_t arg0);

public:
    virtual void select(int32_t arg0, int32_t arg1);
    virtual void selectAll();
    virtual void setCaret(Caret* arg0);
    virtual void setCaretColor(::java::awt::Color* arg0);
    virtual void setCaretPosition(int32_t arg0);
    void setComponentOrientation(::java::awt::ComponentOrientation* arg0) override;
    virtual void setDisabledTextColor(::java::awt::Color* arg0);
    virtual void setDocument(Document* arg0);
    virtual void setDragEnabled(bool arg0);

public: /* package */
    virtual ::java::lang::Object* JTextComponent_setDropLocation(::javax::swing::TransferHandler_DropLocation* arg0, ::java::lang::Object* arg1, bool arg2);

public:
    void setDropMode(::javax::swing::DropMode* arg0);
    virtual void setEditable(bool arg0);
    virtual void setFocusAccelerator(char16_t arg0);
    virtual void setHighlighter(Highlighter* arg0);
    /*void setInputMethodCaretPosition(::java::awt::event::InputMethodEvent* arg0); (private) */
    virtual void setKeymap(Keymap* arg0);
    virtual void setMargin(::java::awt::Insets* arg0);
    virtual void setNavigationFilter(NavigationFilter* arg0);
    virtual void setSelectedTextColor(::java::awt::Color* arg0);
    virtual void setSelectionColor(::java::awt::Color* arg0);
    virtual void setSelectionEnd(int32_t arg0);
    virtual void setSelectionStart(int32_t arg0);
    virtual void setText(::java::lang::String* arg0);
    virtual void setUI(::javax::swing::plaf::TextUI* arg0);
    /*bool shouldSynthensizeKeyEvents(); (private) */

public: /* package */
    virtual void updateInputMap(Keymap* arg0, Keymap* arg1);

public:
    void updateUI() override;
    virtual int32_t viewToModel(::java::awt::Point* arg0);
    virtual void write(::java::io::Writer* arg0);

    // Generated
    JTextComponent();
protected:
    JTextComponent(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    virtual ::java::lang::String* getToolTipText();
    void print(::java::awt::Graphics* arg0);

public: /* protected */
    virtual void setUI(::javax::swing::plaf::ComponentUI* arg0);

public:
    static ::java::lang::String*& DEFAULT_KEYMAP();

private:
    static ::java::lang::Object*& FOCUSED_COMPONENT();

public:
    static ::java::lang::String*& FOCUS_ACCELERATOR_KEY();

private:
    static ::java::lang::Object*& KEYMAP_TABLE();
    static ::com::sun::beans::util::Cache*& METHOD_OVERRIDDEN();
    static JTextComponent_DefaultTransferHandler*& defaultTransferHandler();
    virtual ::java::lang::Class* getClass0();
};
