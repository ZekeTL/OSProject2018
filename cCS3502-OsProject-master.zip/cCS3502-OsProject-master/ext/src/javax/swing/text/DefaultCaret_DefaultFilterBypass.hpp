// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/NavigationFilter_FilterBypass.hpp>

struct default_init_tag;

class javax::swing::text::DefaultCaret_DefaultFilterBypass
    : public NavigationFilter_FilterBypass
{

public:
    typedef NavigationFilter_FilterBypass super;

public: /* package */
    DefaultCaret* this$0 {  };

    /*void ctor(); (private) */

public:
    Caret* getCaret() override;
    void moveDot(int32_t arg0, Position_Bias* arg1) override;
    void setDot(int32_t arg0, Position_Bias* arg1) override;

    // Generated
    DefaultCaret_DefaultFilterBypass(DefaultCaret *DefaultCaret_this);
protected:
    DefaultCaret_DefaultFilterBypass(DefaultCaret *DefaultCaret_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    DefaultCaret *DefaultCaret_this;

private:
    virtual ::java::lang::Class* getClass0();
};
