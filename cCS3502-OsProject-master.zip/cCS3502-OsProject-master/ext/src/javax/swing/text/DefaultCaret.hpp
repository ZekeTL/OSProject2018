// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/datatransfer/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/Rectangle.hpp>
#include <javax/swing/text/Caret.hpp>
#include <java/awt/event/FocusListener.hpp>
#include <java/awt/event/MouseListener.hpp>
#include <java/awt/event/MouseMotionListener.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace util
    {
typedef ::SubArray< ::java::util::EventListener, ::java::lang::ObjectArray > EventListenerArray;
    } // util
} // java

namespace javax
{
    namespace swing
    {
        namespace event
        {
typedef ::SubArray< ::javax::swing::event::ChangeListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > ChangeListenerArray;
        } // event
    } // swing
} // javax

struct default_init_tag;

class javax::swing::text::DefaultCaret
    : public ::java::awt::Rectangle
    , public virtual Caret
    , public virtual ::java::awt::event::FocusListener
    , public virtual ::java::awt::event::MouseListener
    , public virtual ::java::awt::event::MouseMotionListener
{

public:
    typedef ::java::awt::Rectangle super;
    static constexpr int32_t ALWAYS_UPDATE { int32_t(2) };
    static constexpr int32_t NEVER_UPDATE { int32_t(1) };
    static constexpr int32_t UPDATE_WHEN_ON_EDT { int32_t(0) };

public: /* package */
    bool active {  };

private:
    float aspectRatio {  };
    int32_t caretWidth {  };

public: /* protected */
    ::javax::swing::event::ChangeEvent* changeEvent {  };

public: /* package */
    JTextComponent* component {  };
    int32_t dot {  };
    Position_Bias* dotBias {  };
    bool dotLTR {  };

private:
    NavigationFilter_FilterBypass* filterBypass {  };
    ::int32_tArray* flagXPoints {  };
    ::int32_tArray* flagYPoints {  };

public: /* package */
    ::javax::swing::Timer* flasher {  };

private:
    bool forceCaretPositionChange {  };

public: /* package */
    DefaultCaret_Handler* handler {  };

public: /* protected */
    ::javax::swing::event::EventListenerList* listenerList {  };

public: /* package */
    ::java::awt::Point* magicCaretPosition {  };
    int32_t mark {  };
    Position_Bias* markBias {  };
    bool markLTR {  };

private:
    bool ownsSelection {  };
    static ::javax::swing::Action* selectLine_;
    static ::javax::swing::Action* selectWord__;
    ::java::awt::event::MouseEvent* selectedWordEvent {  };

public: /* package */
    ::java::lang::Object* selectionTag {  };
    bool selectionVisible {  };

private:
    bool shouldHandleRelease {  };

public: /* package */
    int32_t updatePolicy {  };
    bool visible {  };

protected:
    void ctor();
    /*bool _contains(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3); (private) */

public:
    void addChangeListener(::javax::swing::event::ChangeListener* arg0) override;
    /*void adjustCaret(::java::awt::event::MouseEvent* arg0); (private) */

public: /* package */
    virtual void adjustCaretAndFocus(::java::awt::event::MouseEvent* arg0);
    /*void adjustFocus(bool arg0); (private) */

public: /* protected */
    virtual void adjustVisibility(::java::awt::Rectangle* arg0);

public: /* package */
    virtual void changeCaretPosition(int32_t arg0, Position_Bias* arg1);

public: /* protected */
    virtual void damage(::java::awt::Rectangle* arg0);

public:
    void deinstall(JTextComponent* arg0) override;
    /*void ensureValidPosition(); (private) */
    bool equals(::java::lang::Object* arg0) override;

public: /* protected */
    virtual void fireStateChanged();

public:
    void focusGained(::java::awt::event::FocusEvent* arg0) override;
    void focusLost(::java::awt::event::FocusEvent* arg0) override;
    int32_t getBlinkRate() override;

public: /* package */
    virtual int32_t getCaretWidth(int32_t arg0);

public:
    virtual ::javax::swing::event::ChangeListenerArray* getChangeListeners();
    /*::java::awt::datatransfer::ClipboardOwner* getClipboardOwner(); (private) */

public: /* protected */
    JTextComponent* getComponent();

public:
    int32_t getDot() override;
    virtual Position_Bias* getDotBias();
    /*NavigationFilter_FilterBypass* getFilterBypass(); (private) */
    virtual ::java::util::EventListenerArray* getListeners(::java::lang::Class* arg0);
    ::java::awt::Point* getMagicCaretPosition() override;
    int32_t getMark() override;
    virtual Position_Bias* getMarkBias();

public: /* protected */
    virtual Highlighter_HighlightPainter* getSelectionPainter();
    /*::java::awt::datatransfer::Clipboard* getSystemSelection(); (private) */

public:
    virtual int32_t getUpdatePolicy();

public: /* package */
    virtual Position_Bias* guessBiasForOffset(int32_t arg0, Position_Bias* arg1, bool arg2);
    virtual void handleMoveDot(int32_t arg0, Position_Bias* arg1);
    virtual void handleSetDot(int32_t arg0, Position_Bias* arg1);

public:
    void install(JTextComponent* arg0) override;
    virtual bool isActive();

public: /* package */
    virtual bool isDotLeftToRight();
    virtual bool isMarkLeftToRight();
    virtual bool isPositionLTR(int32_t arg0, Position_Bias* arg1);

public:
    bool isSelectionVisible() override;
    bool isVisible() override;
    void mouseClicked(::java::awt::event::MouseEvent* arg0) override;
    void mouseDragged(::java::awt::event::MouseEvent* arg0) override;
    void mouseEntered(::java::awt::event::MouseEvent* arg0) override;
    void mouseExited(::java::awt::event::MouseEvent* arg0) override;
    void mouseMoved(::java::awt::event::MouseEvent* arg0) override;
    void mousePressed(::java::awt::event::MouseEvent* arg0) override;
    void mouseReleased(::java::awt::event::MouseEvent* arg0) override;

public: /* protected */
    virtual void moveCaret(::java::awt::event::MouseEvent* arg0);

public:
    void moveDot(int32_t arg0) override;
    virtual void moveDot(int32_t arg0, Position_Bias* arg1);
    void paint(::java::awt::Graphics* arg0) override;

public: /* protected */
    virtual void positionCaret(::java::awt::event::MouseEvent* arg0);
    /*void readObject(::java::io::ObjectInputStream* arg0); (private) */

public:
    void removeChangeListener(::javax::swing::event::ChangeListener* arg0) override;

public: /* protected */
    void repaint();

public: /* package */
    virtual void repaintNewCaret();
    /*void selectWord(::java::awt::event::MouseEvent* arg0); (private) */

public:
    void setBlinkRate(int32_t arg0) override;
    void setDot(int32_t arg0) override;
    virtual void setDot(int32_t arg0, Position_Bias* arg1);
    void setMagicCaretPosition(::java::awt::Point* arg0) override;
    void setSelectionVisible(bool arg0) override;
    virtual void setUpdatePolicy(int32_t arg0);
    void setVisible(bool arg0) override;
    ::java::lang::String* toString() override;
    /*void updateSystemSelection(); (private) */
    /*void writeObject(::java::io::ObjectOutputStream* arg0); (private) */

    // Generated
    DefaultCaret();
protected:
    DefaultCaret(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    static ::javax::swing::Action*& selectLine();
    static ::javax::swing::Action*& selectWord_();
    virtual ::java::lang::Class* getClass0();
};
