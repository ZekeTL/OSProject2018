// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/ActionMap.hpp>

struct default_init_tag;

class javax::swing::text::JTextComponent_KeymapActionMap
    : public ::javax::swing::ActionMap
{

public:
    typedef ::javax::swing::ActionMap super;

private:
    Keymap* keymap {  };

protected:
    void ctor(Keymap* arg0);

public:
    ::javax::swing::Action* get(::java::lang::Object* arg0) override;
    ::java::lang::ObjectArray* keys() override;
    int32_t size() override;

    // Generated

public: /* package */
    JTextComponent_KeymapActionMap(Keymap* arg0);
protected:
    JTextComponent_KeymapActionMap(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
