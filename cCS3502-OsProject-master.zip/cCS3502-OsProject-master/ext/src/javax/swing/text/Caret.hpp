// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct javax::swing::text::Caret
    : public virtual ::java::lang::Object
{

    virtual void addChangeListener(::javax::swing::event::ChangeListener* arg0) = 0;
    virtual void deinstall(JTextComponent* arg0) = 0;
    virtual int32_t getBlinkRate() = 0;
    virtual int32_t getDot() = 0;
    virtual ::java::awt::Point* getMagicCaretPosition() = 0;
    virtual int32_t getMark() = 0;
    virtual void install(JTextComponent* arg0) = 0;
    virtual bool isSelectionVisible() = 0;
    virtual bool isVisible() = 0;
    virtual void moveDot(int32_t arg0) = 0;
    virtual void paint(::java::awt::Graphics* arg0) = 0;
    virtual void removeChangeListener(::javax::swing::event::ChangeListener* arg0) = 0;
    virtual void setBlinkRate(int32_t arg0) = 0;
    virtual void setDot(int32_t arg0) = 0;
    virtual void setMagicCaretPosition(::java::awt::Point* arg0) = 0;
    virtual void setSelectionVisible(bool arg0) = 0;
    virtual void setVisible(bool arg0) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
