// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/font/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/text/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/awt/im/InputMethodRequests.hpp>
#include <javax/swing/event/DocumentListener.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace io
    {
typedef ::SubArray< ::java::io::Serializable, ::java::lang::ObjectArray > SerializableArray;
    } // io

    namespace text
    {
typedef ::SubArray< ::java::text::AttributedCharacterIterator_Attribute, ::java::lang::ObjectArray, ::java::io::SerializableArray > AttributedCharacterIterator_AttributeArray;
    } // text
} // java

struct default_init_tag;

class javax::swing::text::JTextComponent_InputMethodRequestsHandler
    : public virtual ::java::lang::Object
    , public virtual ::java::awt::im::InputMethodRequests
    , public virtual ::javax::swing::event::DocumentListener
{

public:
    typedef ::java::lang::Object super;

public: /* package */
    JTextComponent* this$0 {  };

protected:
    void ctor();

public:
    ::java::text::AttributedCharacterIterator* cancelLatestCommittedText(::java::text::AttributedCharacterIterator_AttributeArray* arg0) override;
    void changedUpdate(::javax::swing::event::DocumentEvent* arg0) override;
    ::java::text::AttributedCharacterIterator* getCommittedText(int32_t arg0, int32_t arg1, ::java::text::AttributedCharacterIterator_AttributeArray* arg2) override;
    int32_t getCommittedTextLength() override;
    int32_t getInsertPositionOffset() override;
    ::java::awt::font::TextHitInfo* getLocationOffset(int32_t arg0, int32_t arg1) override;
    ::java::text::AttributedCharacterIterator* getSelectedText(::java::text::AttributedCharacterIterator_AttributeArray* arg0) override;
    ::java::awt::Rectangle* getTextLocation(::java::awt::font::TextHitInfo* arg0) override;
    void insertUpdate(::javax::swing::event::DocumentEvent* arg0) override;
    void removeUpdate(::javax::swing::event::DocumentEvent* arg0) override;

    // Generated

public: /* package */
    JTextComponent_InputMethodRequestsHandler(JTextComponent *JTextComponent_this);
protected:
    JTextComponent_InputMethodRequestsHandler(JTextComponent *JTextComponent_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JTextComponent *JTextComponent_this;

private:
    virtual ::java::lang::Class* getClass0();
};
