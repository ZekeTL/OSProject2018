// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace io
    {
typedef ::SubArray< ::java::io::Serializable, ::java::lang::ObjectArray > SerializableArray;
    } // io

    namespace awt
    {
typedef ::SubArray< ::java::awt::AWTKeyStroke, ::java::lang::ObjectArray, ::java::io::SerializableArray > AWTKeyStrokeArray;
    } // awt

    namespace util
    {
typedef ::SubArray< ::java::util::EventListener, ::java::lang::ObjectArray > EventListenerArray;
    } // util

    namespace awt
    {
        namespace event
        {
typedef ::SubArray< ::java::awt::event::ActionListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > ActionListenerArray;
        } // event
    } // awt
} // java

namespace javax
{
    namespace swing
    {
typedef ::SubArray< ::javax::swing::Action, ::java::lang::ObjectArray, ::java::awt::event::ActionListenerArray > ActionArray;
typedef ::SubArray< ::javax::swing::KeyStroke, ::java::awt::AWTKeyStrokeArray > KeyStrokeArray;
    } // swing
} // javax

struct javax::swing::text::Keymap
    : public virtual ::java::lang::Object
{

    virtual void addActionForKeyStroke(::javax::swing::KeyStroke* arg0, ::javax::swing::Action* arg1) = 0;
    virtual ::javax::swing::Action* getAction(::javax::swing::KeyStroke* arg0) = 0;
    virtual ::javax::swing::ActionArray* getBoundActions() = 0;
    virtual ::javax::swing::KeyStrokeArray* getBoundKeyStrokes() = 0;
    virtual ::javax::swing::Action* getDefaultAction() = 0;
    virtual ::javax::swing::KeyStrokeArray* getKeyStrokesForAction(::javax::swing::Action* arg0) = 0;
    virtual ::java::lang::String* getName() = 0;
    virtual Keymap* getResolveParent() = 0;
    virtual bool isLocallyDefined(::javax::swing::KeyStroke* arg0) = 0;
    virtual void removeBindings() = 0;
    virtual void removeKeyStrokeBinding(::javax::swing::KeyStroke* arg0) = 0;
    virtual void setDefaultAction(::javax::swing::Action* arg0) = 0;
    virtual void setResolveParent(Keymap* arg0) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
