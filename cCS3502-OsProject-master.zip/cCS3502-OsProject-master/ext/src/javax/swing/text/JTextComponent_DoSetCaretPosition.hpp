// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <javax/swing/text/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/lang/Runnable.hpp>

struct default_init_tag;

class javax::swing::text::JTextComponent_DoSetCaretPosition
    : public virtual ::java::lang::Object
    , public virtual ::java::lang::Runnable
{

public:
    typedef ::java::lang::Object super;

public: /* package */
    JTextComponent* host {  };
    Position* newPos {  };
    JTextComponent* this$0 {  };

protected:
    void ctor(JTextComponent* arg0, Position* arg1);

public:
    void run() override;

    // Generated

public: /* package */
    JTextComponent_DoSetCaretPosition(JTextComponent *JTextComponent_this, JTextComponent* arg0, Position* arg1);
protected:
    JTextComponent_DoSetCaretPosition(JTextComponent *JTextComponent_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JTextComponent *JTextComponent_this;

private:
    virtual ::java::lang::Class* getClass0();
};
