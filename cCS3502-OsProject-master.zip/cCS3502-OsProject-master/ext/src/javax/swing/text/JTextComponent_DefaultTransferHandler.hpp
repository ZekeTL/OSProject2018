// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/datatransfer/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/TransferHandler.hpp>
#include <javax/swing/plaf/UIResource.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace io
    {
typedef ::SubArray< ::java::io::Serializable, ::java::lang::ObjectArray > SerializableArray;
typedef ::SubArray< ::java::io::Externalizable, ::java::lang::ObjectArray, SerializableArray > ExternalizableArray;
    } // io

    namespace lang
    {
typedef ::SubArray< ::java::lang::Cloneable, ObjectArray > CloneableArray;
    } // lang

    namespace awt
    {
        namespace datatransfer
        {
typedef ::SubArray< ::java::awt::datatransfer::DataFlavor, ::java::lang::ObjectArray, ::java::io::ExternalizableArray, ::java::lang::CloneableArray > DataFlavorArray;
        } // datatransfer
    } // awt
} // java

struct default_init_tag;

class javax::swing::text::JTextComponent_DefaultTransferHandler
    : public ::javax::swing::TransferHandler
    , public virtual ::javax::swing::plaf::UIResource
{

public:
    typedef ::javax::swing::TransferHandler super;

protected:
    void ctor();

public:
    bool canImport(::javax::swing::JComponent* arg0, ::java::awt::datatransfer::DataFlavorArray* arg1) override;
    void exportToClipboard(::javax::swing::JComponent* arg0, ::java::awt::datatransfer::Clipboard* arg1, int32_t arg2) override;
    /*::java::awt::datatransfer::DataFlavor* getFlavor(::java::awt::datatransfer::DataFlavorArray* arg0); (private) */
    int32_t getSourceActions(::javax::swing::JComponent* arg0) override;
    bool importData(::javax::swing::JComponent* arg0, ::java::awt::datatransfer::Transferable* arg1) override;

    // Generated

public: /* package */
    JTextComponent_DefaultTransferHandler();
protected:
    JTextComponent_DefaultTransferHandler(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    virtual bool canImport(::javax::swing::TransferHandler_TransferSupport* arg0);
    virtual bool importData(::javax::swing::TransferHandler_TransferSupport* arg0);

private:
    virtual ::java::lang::Class* getClass0();
};
