// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/DefaultCaret.hpp>
#include <java/io/Serializable.hpp>

struct default_init_tag;

class javax::swing::text::JTextComponent_ComposedTextCaret
    : public DefaultCaret
    , public virtual ::java::io::Serializable
{

public:
    typedef DefaultCaret super;

public: /* package */
    ::java::awt::Color* bg {  };
    JTextComponent* this$0 {  };

protected:
    void ctor();

public:
    void install(JTextComponent* arg0) override;
    void paint(::java::awt::Graphics* arg0) override;

public: /* protected */
    void positionCaret(::java::awt::event::MouseEvent* arg0) override;

    // Generated

public: /* package */
    JTextComponent_ComposedTextCaret(JTextComponent *JTextComponent_this);
protected:
    JTextComponent_ComposedTextCaret(JTextComponent *JTextComponent_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JTextComponent *JTextComponent_this;

private:
    virtual ::java::lang::Class* getClass0();
};
