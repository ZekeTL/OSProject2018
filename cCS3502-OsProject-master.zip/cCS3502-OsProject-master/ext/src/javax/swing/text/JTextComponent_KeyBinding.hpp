// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct default_init_tag;

class javax::swing::text::JTextComponent_KeyBinding
    : public virtual ::java::lang::Object
{

public:
    typedef ::java::lang::Object super;
    ::java::lang::String* actionName {  };
    ::javax::swing::KeyStroke* key {  };

protected:
    void ctor(::javax::swing::KeyStroke* arg0, ::java::lang::String* arg1);

    // Generated

public:
    JTextComponent_KeyBinding(::javax::swing::KeyStroke* arg0, ::java::lang::String* arg1);
protected:
    JTextComponent_KeyBinding(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
