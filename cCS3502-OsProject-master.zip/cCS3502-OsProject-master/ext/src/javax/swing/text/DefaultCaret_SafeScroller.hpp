// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/lang/Runnable.hpp>

struct default_init_tag;

class javax::swing::text::DefaultCaret_SafeScroller
    : public virtual ::java::lang::Object
    , public virtual ::java::lang::Runnable
{

public:
    typedef ::java::lang::Object super;

public: /* package */
    ::java::awt::Rectangle* r {  };
    DefaultCaret* this$0 {  };

protected:
    void ctor(::java::awt::Rectangle* arg0);

public:
    void run() override;

    // Generated

public: /* package */
    DefaultCaret_SafeScroller(DefaultCaret *DefaultCaret_this, ::java::awt::Rectangle* arg0);
protected:
    DefaultCaret_SafeScroller(DefaultCaret *DefaultCaret_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    DefaultCaret *DefaultCaret_this;

private:
    virtual ::java::lang::Class* getClass0();
};
