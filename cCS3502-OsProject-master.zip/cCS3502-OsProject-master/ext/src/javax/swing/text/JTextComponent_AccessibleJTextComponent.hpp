// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/JComponent_AccessibleJComponent.hpp>
#include <javax/accessibility/AccessibleText.hpp>
#include <javax/swing/event/CaretListener.hpp>
#include <javax/swing/event/DocumentListener.hpp>
#include <javax/accessibility/AccessibleAction.hpp>
#include <javax/accessibility/AccessibleEditableText.hpp>
#include <javax/accessibility/AccessibleExtendedText.hpp>

struct default_init_tag;

class javax::swing::text::JTextComponent_AccessibleJTextComponent
    : public ::javax::swing::JComponent_AccessibleJComponent
    , public virtual ::javax::accessibility::AccessibleText
    , public virtual ::javax::swing::event::CaretListener
    , public virtual ::javax::swing::event::DocumentListener
    , public virtual ::javax::accessibility::AccessibleAction
    , public virtual ::javax::accessibility::AccessibleEditableText
    , public virtual ::javax::accessibility::AccessibleExtendedText
{

public:
    typedef ::javax::swing::JComponent_AccessibleJComponent super;

public: /* package */
    int32_t caretPos {  };
    ::java::awt::Point* oldLocationOnScreen {  };
    JTextComponent* this$0 {  };

protected:
    void ctor();

public:
    void caretUpdate(::javax::swing::event::CaretEvent* arg0) override;
    void changedUpdate(::javax::swing::event::DocumentEvent* arg0) override;
    void cut(int32_t arg0, int32_t arg1) override;
    void delete_(int32_t arg0, int32_t arg1) override;
    bool doAccessibleAction(int32_t arg0) override;
    ::javax::accessibility::AccessibleAction* getAccessibleAction() override;
    int32_t getAccessibleActionCount() override;
    ::java::lang::String* getAccessibleActionDescription(int32_t arg0) override;
    ::javax::accessibility::AccessibleEditableText* getAccessibleEditableText() override;
    ::javax::accessibility::AccessibleRole* getAccessibleRole() override;
    ::javax::accessibility::AccessibleStateSet* getAccessibleStateSet() override;
    ::javax::accessibility::AccessibleText* getAccessibleText() override;
    ::java::lang::String* getAfterIndex(int32_t arg0, int32_t arg1) override;
    ::java::lang::String* getAtIndex(int32_t arg0, int32_t arg1) override;
    /*::java::lang::String* getAtIndex(int32_t arg0, int32_t arg1, int32_t arg2); (private) */
    ::java::lang::String* getBeforeIndex(int32_t arg0, int32_t arg1) override;
    int32_t getCaretPosition() override;
    int32_t getCharCount() override;
    AttributeSet* getCharacterAttribute(int32_t arg0) override;
    ::java::awt::Rectangle* getCharacterBounds(int32_t arg0) override;
    int32_t getIndexAtPoint(::java::awt::Point* arg0) override;
    /*Element* getParagraphElement(int32_t arg0); (private) */
    /*JTextComponent_AccessibleJTextComponent_IndexedSegment* getParagraphElementText(int32_t arg0); (private) */

public: /* package */
    virtual ::java::awt::Rectangle* getRootEditorRect();
    /*int32_t getRunEdge(int32_t arg0, int32_t arg1); (private) */
    /*JTextComponent_AccessibleJTextComponent_IndexedSegment* getSegmentAt(int32_t arg0, int32_t arg1); (private) */

public:
    ::java::lang::String* getSelectedText() override;
    int32_t getSelectionEnd() override;
    int32_t getSelectionStart() override;
    /*::javax::accessibility::AccessibleTextSequence* getSequenceAtIndex(int32_t arg0, int32_t arg1, int32_t arg2); (private) */
    ::java::awt::Rectangle* getTextBounds(int32_t arg0, int32_t arg1) override;
    ::java::lang::String* getTextRange(int32_t arg0, int32_t arg1) override;
    ::javax::accessibility::AccessibleTextSequence* getTextSequenceAfter(int32_t arg0, int32_t arg1) override;
    ::javax::accessibility::AccessibleTextSequence* getTextSequenceAt(int32_t arg0, int32_t arg1) override;
    ::javax::accessibility::AccessibleTextSequence* getTextSequenceBefore(int32_t arg0, int32_t arg1) override;
    void insertTextAtIndex(int32_t arg0, ::java::lang::String* arg1) override;
    void insertUpdate(::javax::swing::event::DocumentEvent* arg0) override;
    void paste(int32_t arg0) override;
    void removeUpdate(::javax::swing::event::DocumentEvent* arg0) override;
    void replaceText(int32_t arg0, int32_t arg1, ::java::lang::String* arg2) override;
    void selectText(int32_t arg0, int32_t arg1) override;
    void setAttributes(int32_t arg0, int32_t arg1, AttributeSet* arg2) override;
    void setTextContents(::java::lang::String* arg0) override;

    // Generated
    JTextComponent_AccessibleJTextComponent(JTextComponent *JTextComponent_this);
protected:
    JTextComponent_AccessibleJTextComponent(JTextComponent *JTextComponent_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JTextComponent *JTextComponent_this;

private:
    virtual ::java::lang::Class* getClass0();
};
