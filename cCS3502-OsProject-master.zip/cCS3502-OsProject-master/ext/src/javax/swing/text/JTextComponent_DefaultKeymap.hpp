// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <javax/swing/text/Keymap.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace io
    {
typedef ::SubArray< ::java::io::Serializable, ::java::lang::ObjectArray > SerializableArray;
    } // io

    namespace awt
    {
typedef ::SubArray< ::java::awt::AWTKeyStroke, ::java::lang::ObjectArray, ::java::io::SerializableArray > AWTKeyStrokeArray;
    } // awt

    namespace util
    {
typedef ::SubArray< ::java::util::EventListener, ::java::lang::ObjectArray > EventListenerArray;
    } // util

    namespace awt
    {
        namespace event
        {
typedef ::SubArray< ::java::awt::event::ActionListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > ActionListenerArray;
        } // event
    } // awt
} // java

namespace javax
{
    namespace swing
    {
typedef ::SubArray< ::javax::swing::Action, ::java::lang::ObjectArray, ::java::awt::event::ActionListenerArray > ActionArray;
typedef ::SubArray< ::javax::swing::KeyStroke, ::java::awt::AWTKeyStrokeArray > KeyStrokeArray;
    } // swing
} // javax

struct default_init_tag;

class javax::swing::text::JTextComponent_DefaultKeymap
    : public virtual ::java::lang::Object
    , public virtual Keymap
{

public:
    typedef ::java::lang::Object super;

public: /* package */
    ::java::util::Hashtable* bindings {  };
    ::javax::swing::Action* defaultAction {  };
    ::java::lang::String* nm {  };
    Keymap* parent {  };

protected:
    void ctor(::java::lang::String* arg0, Keymap* arg1);

public:
    void addActionForKeyStroke(::javax::swing::KeyStroke* arg0, ::javax::swing::Action* arg1) override;
    ::javax::swing::Action* getAction(::javax::swing::KeyStroke* arg0) override;
    ::javax::swing::ActionArray* getBoundActions() override;
    ::javax::swing::KeyStrokeArray* getBoundKeyStrokes() override;
    ::javax::swing::Action* getDefaultAction() override;
    ::javax::swing::KeyStrokeArray* getKeyStrokesForAction(::javax::swing::Action* arg0) override;
    ::java::lang::String* getName() override;
    Keymap* getResolveParent() override;
    bool isLocallyDefined(::javax::swing::KeyStroke* arg0) override;
    void removeBindings() override;
    void removeKeyStrokeBinding(::javax::swing::KeyStroke* arg0) override;
    void setDefaultAction(::javax::swing::Action* arg0) override;
    void setResolveParent(Keymap* arg0) override;
    ::java::lang::String* toString() override;

    // Generated

public: /* package */
    JTextComponent_DefaultKeymap(::java::lang::String* arg0, Keymap* arg1);
protected:
    JTextComponent_DefaultKeymap(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
