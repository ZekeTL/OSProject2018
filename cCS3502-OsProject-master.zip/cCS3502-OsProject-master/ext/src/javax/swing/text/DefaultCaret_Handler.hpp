// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/awt/datatransfer/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/beans/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/beans/PropertyChangeListener.hpp>
#include <javax/swing/event/DocumentListener.hpp>
#include <java/awt/event/ActionListener.hpp>
#include <java/awt/datatransfer/ClipboardOwner.hpp>

struct default_init_tag;

class javax::swing::text::DefaultCaret_Handler
    : public virtual ::java::lang::Object
    , public virtual ::java::beans::PropertyChangeListener
    , public virtual ::javax::swing::event::DocumentListener
    , public virtual ::java::awt::event::ActionListener
    , public virtual ::java::awt::datatransfer::ClipboardOwner
{

public:
    typedef ::java::lang::Object super;

public: /* package */
    DefaultCaret* this$0 {  };

protected:
    void ctor();

public:
    void actionPerformed(::java::awt::event::ActionEvent* arg0) override;
    void changedUpdate(::javax::swing::event::DocumentEvent* arg0) override;
    void insertUpdate(::javax::swing::event::DocumentEvent* arg0) override;
    void lostOwnership(::java::awt::datatransfer::Clipboard* arg0, ::java::awt::datatransfer::Transferable* arg1) override;
    void propertyChange(::java::beans::PropertyChangeEvent* arg0) override;
    void removeUpdate(::javax::swing::event::DocumentEvent* arg0) override;

    // Generated

public: /* package */
    DefaultCaret_Handler(DefaultCaret *DefaultCaret_this);
protected:
    DefaultCaret_Handler(DefaultCaret *DefaultCaret_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    DefaultCaret *DefaultCaret_this;

private:
    virtual ::java::lang::Class* getClass0();
};
