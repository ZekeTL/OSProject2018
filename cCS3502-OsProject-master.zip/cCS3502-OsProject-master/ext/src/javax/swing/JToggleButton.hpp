// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/AbstractButton.hpp>
#include <javax/accessibility/Accessible.hpp>

struct default_init_tag;

class javax::swing::JToggleButton
    : public AbstractButton
    , public virtual ::javax::accessibility::Accessible
{

public:
    typedef AbstractButton super;

private:
    static ::java::lang::String* uiClassID_;

protected:
    void ctor();
    void ctor(Icon* arg0);
    void ctor(::java::lang::String* arg0);
    void ctor(Action* arg0);
    void ctor(Icon* arg0, bool arg1);
    void ctor(::java::lang::String* arg0, bool arg1);
    void ctor(::java::lang::String* arg0, Icon* arg1);
    void ctor(::java::lang::String* arg0, Icon* arg1, bool arg2);

public:
    ::javax::accessibility::AccessibleContext* getAccessibleContext() override;
    ::java::lang::String* getUIClassID() override;

public: /* protected */
    ::java::lang::String* paramString() override;

public: /* package */
    bool shouldUpdateSelectedStateFromAction() override;

public:
    void updateUI() override;
    /*void writeObject(::java::io::ObjectOutputStream* arg0); (private) */

    // Generated
    JToggleButton();
    JToggleButton(Icon* arg0);
    JToggleButton(::java::lang::String* arg0);
    JToggleButton(Action* arg0);
    JToggleButton(Icon* arg0, bool arg1);
    JToggleButton(::java::lang::String* arg0, bool arg1);
    JToggleButton(::java::lang::String* arg0, Icon* arg1);
    JToggleButton(::java::lang::String* arg0, Icon* arg1, bool arg2);
protected:
    JToggleButton(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    static ::java::lang::String*& uiClassID();
    virtual ::java::lang::Class* getClass0();
};
