// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/beans/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/AccessibleContext.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace javax
{
    namespace accessibility
    {
typedef ::SubArray< ::javax::accessibility::AccessibleIcon, ::java::lang::ObjectArray > AccessibleIconArray;
    } // accessibility
} // javax

struct default_init_tag;

class javax::swing::JComboBox_AccessibleJComboBox_EditorAccessibleContext
    : public ::javax::accessibility::AccessibleContext
{

public:
    typedef ::javax::accessibility::AccessibleContext super;

private:
    ::javax::accessibility::AccessibleContext* ac {  };

public: /* package */
    JComboBox_AccessibleJComboBox* this$1 {  };

    /*void ctor(); (private) */
protected:
    void ctor(::javax::accessibility::Accessible* a0);

public:
    void addPropertyChangeListener(::java::beans::PropertyChangeListener* arg0) override;
    void firePropertyChange(::java::lang::String* arg0, ::java::lang::Object* arg1, ::java::lang::Object* arg2) override;
    ::javax::accessibility::AccessibleAction* getAccessibleAction() override;
    ::javax::accessibility::Accessible* getAccessibleChild(int32_t arg0) override;
    int32_t getAccessibleChildrenCount() override;
    ::javax::accessibility::AccessibleComponent* getAccessibleComponent() override;
    ::java::lang::String* getAccessibleDescription() override;
    ::javax::accessibility::AccessibleEditableText* getAccessibleEditableText() override;
    ::javax::accessibility::AccessibleIconArray* getAccessibleIcon() override;
    int32_t getAccessibleIndexInParent() override;
    ::java::lang::String* getAccessibleName() override;
    ::javax::accessibility::Accessible* getAccessibleParent() override;
    ::javax::accessibility::AccessibleRelationSet* getAccessibleRelationSet() override;
    ::javax::accessibility::AccessibleRole* getAccessibleRole() override;
    ::javax::accessibility::AccessibleSelection* getAccessibleSelection() override;
    ::javax::accessibility::AccessibleStateSet* getAccessibleStateSet() override;
    ::javax::accessibility::AccessibleTable* getAccessibleTable() override;
    ::javax::accessibility::AccessibleText* getAccessibleText() override;
    ::javax::accessibility::AccessibleValue* getAccessibleValue() override;
    ::java::util::Locale* getLocale() override;
    void removePropertyChangeListener(::java::beans::PropertyChangeListener* arg0) override;
    void setAccessibleDescription(::java::lang::String* arg0) override;
    void setAccessibleName(::java::lang::String* arg0) override;
    void setAccessibleParent(::javax::accessibility::Accessible* arg0) override;

    // Generated

public: /* package */
    JComboBox_AccessibleJComboBox_EditorAccessibleContext(JComboBox_AccessibleJComboBox *JComboBox_AccessibleJComboBox_this, ::javax::accessibility::Accessible* a0);
protected:
    JComboBox_AccessibleJComboBox_EditorAccessibleContext(JComboBox_AccessibleJComboBox *JComboBox_AccessibleJComboBox_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JComboBox_AccessibleJComboBox *JComboBox_AccessibleJComboBox_this;

private:
    virtual ::java::lang::Class* getClass0();
};
