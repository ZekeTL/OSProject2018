// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/beans/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/ActionPropertyChangeListener.hpp>

struct default_init_tag;

class javax::swing::JComboBox_ComboBoxActionPropertyChangeListener
    : public ActionPropertyChangeListener
{

public:
    typedef ActionPropertyChangeListener super;

protected:
    void ctor(JComboBox* arg0, Action* arg1);

public: /* protected */
    virtual void actionPropertyChanged(JComboBox* arg0, Action* arg1, ::java::beans::PropertyChangeEvent* arg2);

    // Generated

public: /* package */
    JComboBox_ComboBoxActionPropertyChangeListener(JComboBox* arg0, Action* arg1);
protected:
    JComboBox_ComboBoxActionPropertyChangeListener(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

public: /* protected */
    virtual void actionPropertyChanged(JComponent* arg0, Action* arg1, ::java::beans::PropertyChangeEvent* arg2) override;

private:
    virtual ::java::lang::Class* getClass0();
};
