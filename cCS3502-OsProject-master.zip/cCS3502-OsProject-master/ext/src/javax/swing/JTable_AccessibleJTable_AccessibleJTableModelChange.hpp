// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <javax/accessibility/AccessibleTableModelChange.hpp>

struct default_init_tag;

class javax::swing::JTable_AccessibleJTable_AccessibleJTableModelChange
    : public virtual ::java::lang::Object
    , public virtual ::javax::accessibility::AccessibleTableModelChange
{

public:
    typedef ::java::lang::Object super;

public: /* protected */
    int32_t firstColumn {  };
    int32_t firstRow {  };
    int32_t lastColumn {  };
    int32_t lastRow {  };

public: /* package */
    JTable_AccessibleJTable* this$1 {  };

public: /* protected */
    int32_t type {  };

protected:
    void ctor(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3, int32_t arg4);

public:
    int32_t getFirstColumn() override;
    int32_t getFirstRow() override;
    int32_t getLastColumn() override;
    int32_t getLastRow() override;
    int32_t getType() override;

    // Generated

public: /* protected */
    JTable_AccessibleJTable_AccessibleJTableModelChange(JTable_AccessibleJTable *JTable_AccessibleJTable_this, int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3, int32_t arg4);
protected:
    JTable_AccessibleJTable_AccessibleJTableModelChange(JTable_AccessibleJTable *JTable_AccessibleJTable_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JTable_AccessibleJTable *JTable_AccessibleJTable_this;

private:
    virtual ::java::lang::Class* getClass0();
};
