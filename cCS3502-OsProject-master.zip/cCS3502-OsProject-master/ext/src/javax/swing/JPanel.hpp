// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/plaf/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/JComponent.hpp>
#include <javax/accessibility/Accessible.hpp>

struct default_init_tag;

class javax::swing::JPanel
    : public JComponent
    , public virtual ::javax::accessibility::Accessible
{

public:
    typedef JComponent super;

private:
    static ::java::lang::String* uiClassID_;

protected:
    void ctor();
    void ctor(::java::awt::LayoutManager* arg0);
    void ctor(bool arg0);
    void ctor(::java::awt::LayoutManager* arg0, bool arg1);

public:
    ::javax::accessibility::AccessibleContext* getAccessibleContext() override;
    virtual ::javax::swing::plaf::PanelUI* getUI();
    ::java::lang::String* getUIClassID() override;

public: /* protected */
    ::java::lang::String* paramString() override;

public:
    virtual void setUI(::javax::swing::plaf::PanelUI* arg0);
    void updateUI() override;
    /*void writeObject(::java::io::ObjectOutputStream* arg0); (private) */

    // Generated
    JPanel();
    JPanel(::java::awt::LayoutManager* arg0);
    JPanel(bool arg0);
    JPanel(::java::awt::LayoutManager* arg0, bool arg1);
protected:
    JPanel(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

public: /* protected */
    virtual void setUI(::javax::swing::plaf::ComponentUI* newUI);

private:
    static ::java::lang::String*& uiClassID();
    virtual ::java::lang::Class* getClass0();
};
