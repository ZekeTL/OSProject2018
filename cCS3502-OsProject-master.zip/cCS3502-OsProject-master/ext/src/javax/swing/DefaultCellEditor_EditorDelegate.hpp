// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/awt/event/ActionListener.hpp>
#include <java/awt/event/ItemListener.hpp>
#include <java/io/Serializable.hpp>

struct default_init_tag;

class javax::swing::DefaultCellEditor_EditorDelegate
    : public virtual ::java::lang::Object
    , public virtual ::java::awt::event::ActionListener
    , public virtual ::java::awt::event::ItemListener
    , public virtual ::java::io::Serializable
{

public:
    typedef ::java::lang::Object super;

public: /* package */
    DefaultCellEditor* this$0 {  };

public: /* protected */
    ::java::lang::Object* value {  };

protected:
    void ctor();

public:
    void actionPerformed(::java::awt::event::ActionEvent* arg0) override;
    virtual void cancelCellEditing();
    virtual ::java::lang::Object* getCellEditorValue();
    virtual bool isCellEditable(::java::util::EventObject* arg0);
    void itemStateChanged(::java::awt::event::ItemEvent* arg0) override;
    virtual void setValue(::java::lang::Object* arg0);
    virtual bool shouldSelectCell(::java::util::EventObject* arg0);
    virtual bool startCellEditing(::java::util::EventObject* arg0);
    virtual bool stopCellEditing();

    // Generated

public: /* protected */
    DefaultCellEditor_EditorDelegate(DefaultCellEditor *DefaultCellEditor_this);
protected:
    DefaultCellEditor_EditorDelegate(DefaultCellEditor *DefaultCellEditor_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    DefaultCellEditor *DefaultCellEditor_this;

private:
    virtual ::java::lang::Class* getClass0();
};
