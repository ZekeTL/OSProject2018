// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct javax::swing::JTable_Resizable2
    : public virtual ::java::lang::Object
{

    virtual int32_t getElementCount() = 0;
    virtual int32_t getLowerBoundAt(int32_t arg0) = 0;
    virtual int32_t getUpperBoundAt(int32_t arg0) = 0;
    virtual void setSizeAt(int32_t arg0, int32_t arg1) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
