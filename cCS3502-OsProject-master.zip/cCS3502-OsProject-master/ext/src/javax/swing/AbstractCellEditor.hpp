// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <javax/swing/CellEditor.hpp>
#include <java/io/Serializable.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace util
    {
typedef ::SubArray< ::java::util::EventListener, ::java::lang::ObjectArray > EventListenerArray;
    } // util
} // java

namespace javax
{
    namespace swing
    {
        namespace event
        {
typedef ::SubArray< ::javax::swing::event::CellEditorListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > CellEditorListenerArray;
        } // event
    } // swing
} // javax

struct default_init_tag;

class javax::swing::AbstractCellEditor
    : public virtual ::java::lang::Object
    , public virtual CellEditor
    , public virtual ::java::io::Serializable
{

public:
    typedef ::java::lang::Object super;

public: /* protected */
    ::javax::swing::event::ChangeEvent* changeEvent {  };
    ::javax::swing::event::EventListenerList* listenerList {  };

protected:
    void ctor();

public:
    void addCellEditorListener(::javax::swing::event::CellEditorListener* arg0) override;
    void cancelCellEditing() override;

public: /* protected */
    virtual void fireEditingCanceled();
    virtual void fireEditingStopped();

public:
    virtual ::javax::swing::event::CellEditorListenerArray* getCellEditorListeners();
    bool isCellEditable(::java::util::EventObject* arg0) override;
    void removeCellEditorListener(::javax::swing::event::CellEditorListener* arg0) override;
    bool shouldSelectCell(::java::util::EventObject* arg0) override;
    bool stopCellEditing() override;

    // Generated
    AbstractCellEditor();
protected:
    AbstractCellEditor(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
