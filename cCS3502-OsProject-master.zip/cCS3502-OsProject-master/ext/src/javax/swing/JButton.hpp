// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/AbstractButton.hpp>
#include <javax/accessibility/Accessible.hpp>

struct default_init_tag;

class javax::swing::JButton
    : public AbstractButton
    , public virtual ::javax::accessibility::Accessible
{

public:
    typedef AbstractButton super;

private:
    static ::java::lang::String* uiClassID_;

protected:
    void ctor();
    void ctor(Icon* arg0);
    void ctor(::java::lang::String* arg0);
    void ctor(Action* arg0);
    void ctor(::java::lang::String* arg0, Icon* arg1);

public:
    ::javax::accessibility::AccessibleContext* getAccessibleContext() override;
    ::java::lang::String* getUIClassID() override;
    virtual bool isDefaultButton();
    virtual bool isDefaultCapable();

public: /* protected */
    ::java::lang::String* paramString() override;

public:
    void removeNotify() override;
    virtual void setDefaultCapable(bool arg0);
    void updateUI() override;
    /*void writeObject(::java::io::ObjectOutputStream* arg0); (private) */

    // Generated
    JButton();
    JButton(Icon* arg0);
    JButton(::java::lang::String* arg0);
    JButton(Action* arg0);
    JButton(::java::lang::String* arg0, Icon* arg1);
protected:
    JButton(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    static ::java::lang::String*& uiClassID();
    virtual ::java::lang::Class* getClass0();
};
