// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/Dialog_AccessibleAWTDialog.hpp>

struct default_init_tag;

class javax::swing::JDialog_AccessibleJDialog
    : public ::java::awt::Dialog_AccessibleAWTDialog
{

public:
    typedef ::java::awt::Dialog_AccessibleAWTDialog super;

public: /* package */
    JDialog* this$0 {  };

protected:
    void ctor();

public:
    ::java::lang::String* getAccessibleName() override;
    ::javax::accessibility::AccessibleStateSet* getAccessibleStateSet() override;

    // Generated

public: /* protected */
    JDialog_AccessibleJDialog(JDialog *JDialog_this);
protected:
    JDialog_AccessibleJDialog(JDialog *JDialog_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JDialog *JDialog_this;

private:
    virtual ::java::lang::Class* getClass0();
};
