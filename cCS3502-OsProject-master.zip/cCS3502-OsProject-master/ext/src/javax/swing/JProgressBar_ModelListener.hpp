// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <javax/swing/event/ChangeListener.hpp>
#include <java/io/Serializable.hpp>

struct default_init_tag;

class javax::swing::JProgressBar_ModelListener
    : public virtual ::java::lang::Object
    , public virtual ::javax::swing::event::ChangeListener
    , public virtual ::java::io::Serializable
{

public:
    typedef ::java::lang::Object super;

public: /* package */
    JProgressBar* this$0 {  };

    /*void ctor(); (private) */

public:
    void stateChanged(::javax::swing::event::ChangeEvent* arg0) override;

    // Generated
    JProgressBar_ModelListener(JProgressBar *JProgressBar_this);
protected:
    JProgressBar_ModelListener(JProgressBar *JProgressBar_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JProgressBar *JProgressBar_this;

private:
    virtual ::java::lang::Class* getClass0();
};
