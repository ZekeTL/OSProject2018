// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/text/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/plaf/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/JComponent.hpp>
#include <javax/swing/SwingConstants.hpp>
#include <javax/accessibility/Accessible.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace util
    {
typedef ::SubArray< ::java::util::EventListener, ::java::lang::ObjectArray > EventListenerArray;
    } // util
} // java

namespace javax
{
    namespace swing
    {
        namespace event
        {
typedef ::SubArray< ::javax::swing::event::ChangeListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > ChangeListenerArray;
        } // event
    } // swing
} // javax

struct default_init_tag;

class javax::swing::JProgressBar
    : public JComponent
    , public virtual SwingConstants
    , public virtual ::javax::accessibility::Accessible
{

public:
    typedef JComponent super;

public: /* protected */
    ::javax::swing::event::ChangeEvent* changeEvent {  };
    ::javax::swing::event::ChangeListener* changeListener {  };

private:
    static constexpr int32_t defaultMaximum { int32_t(100) };
    static constexpr int32_t defaultMinimum { int32_t(0) };
    static constexpr int32_t defaultOrientation { int32_t(0) };
    ::java::text::Format* format {  };
    bool indeterminate {  };

public: /* protected */
    BoundedRangeModel* model {  };
    int32_t orientation {  };
    bool paintBorder_ {  };
    bool paintString {  };
    ::java::lang::String* progressString {  };

private:
    static ::java::lang::String* uiClassID_;

protected:
    void ctor();
    void ctor(int32_t arg0);
    void ctor(BoundedRangeModel* arg0);
    void ctor(int32_t arg0, int32_t arg1);
    void ctor(int32_t arg0, int32_t arg1, int32_t arg2);

public:
    virtual void addChangeListener(::javax::swing::event::ChangeListener* arg0);

public: /* protected */
    virtual ::javax::swing::event::ChangeListener* createChangeListener();
    virtual void fireStateChanged();

public:
    ::javax::accessibility::AccessibleContext* getAccessibleContext() override;
    virtual ::javax::swing::event::ChangeListenerArray* getChangeListeners();
    virtual int32_t getMaximum();
    virtual int32_t getMinimum();
    virtual BoundedRangeModel* getModel();
    virtual int32_t getOrientation();
    virtual double getPercentComplete();
    virtual ::java::lang::String* getString();
    virtual ::javax::swing::plaf::ProgressBarUI* getUI();
    ::java::lang::String* getUIClassID() override;
    virtual int32_t getValue();
    virtual bool isBorderPainted();
    virtual bool isIndeterminate();
    virtual bool isStringPainted();

public: /* protected */
    void paintBorder(::java::awt::Graphics* arg0) override;
    ::java::lang::String* paramString() override;

public:
    virtual void removeChangeListener(::javax::swing::event::ChangeListener* arg0);
    virtual void setBorderPainted(bool arg0);
    virtual void setIndeterminate(bool arg0);
    virtual void setMaximum(int32_t arg0);
    virtual void setMinimum(int32_t arg0);
    virtual void setModel(BoundedRangeModel* arg0);
    virtual void setOrientation(int32_t arg0);
    virtual void setString(::java::lang::String* arg0);
    virtual void setStringPainted(bool arg0);
    virtual void setUI(::javax::swing::plaf::ProgressBarUI* arg0);
    virtual void setValue(int32_t arg0);
    void updateUI() override;
    /*void writeObject(::java::io::ObjectOutputStream* arg0); (private) */

    // Generated
    JProgressBar();
    JProgressBar(int32_t arg0);
    JProgressBar(BoundedRangeModel* arg0);
    JProgressBar(int32_t arg0, int32_t arg1);
    JProgressBar(int32_t arg0, int32_t arg1, int32_t arg2);
protected:
    JProgressBar(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

public: /* protected */
    virtual void setUI(::javax::swing::plaf::ComponentUI* newUI);

private:
    static ::java::lang::String*& uiClassID();
    virtual ::java::lang::Class* getClass0();
};
