// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/geom/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <javax/swing/SwingConstants.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace awt
    {
typedef ::SubArray< ::java::awt::Shape, ::java::lang::ObjectArray > ShapeArray;
    } // awt

    namespace lang
    {
typedef ::SubArray< ::java::lang::Cloneable, ObjectArray > CloneableArray;
    } // lang

    namespace awt
    {
        namespace geom
        {
typedef ::SubArray< ::java::awt::geom::RectangularShape, ::java::lang::ObjectArray, ::java::awt::ShapeArray, ::java::lang::CloneableArray > RectangularShapeArray;
typedef ::SubArray< ::java::awt::geom::Rectangle2D, RectangularShapeArray > Rectangle2DArray;
        } // geom
    } // awt

    namespace io
    {
typedef ::SubArray< ::java::io::Serializable, ::java::lang::ObjectArray > SerializableArray;
    } // io

    namespace awt
    {
typedef ::SubArray< ::java::awt::Rectangle, ::java::awt::geom::Rectangle2DArray, ShapeArray, ::java::io::SerializableArray > RectangleArray;
    } // awt
} // java

struct default_init_tag;

class javax::swing::SwingUtilities
    : public virtual ::java::lang::Object
    , public virtual SwingConstants
{

public:
    typedef ::java::lang::Object super;

private:
    static bool canAccessEventQueue_;
    static bool checkedSuppressDropSupport_;
    static bool eventQueueTested_;
    static ::java::lang::Object* sharedOwnerFrameKey_;
    static bool suppressDropSupport_;

    /*void ctor(); (private) */

public: /* package */
    static ::java::lang::Object* appContextGet(::java::lang::Object* arg0);
    static void appContextPut(::java::lang::Object* arg0, ::java::lang::Object* arg1);
    static void appContextRemove(::java::lang::Object* arg0);

public:
    static ::java::awt::Rectangle* calculateInnerArea(JComponent* arg0, ::java::awt::Rectangle* arg1);
    static ::java::awt::RectangleArray* computeDifference(::java::awt::Rectangle* arg0, ::java::awt::Rectangle* arg1);
    static ::java::awt::Rectangle* computeIntersection(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3, ::java::awt::Rectangle* arg4);
    static int32_t computeStringWidth(::java::awt::FontMetrics* arg0, ::java::lang::String* arg1);
    static ::java::awt::Rectangle* computeUnion(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3, ::java::awt::Rectangle* arg4);
    static ::java::awt::event::MouseEvent* convertMouseEvent(::java::awt::Component* arg0, ::java::awt::event::MouseEvent* arg1, ::java::awt::Component* arg2);
    static ::java::awt::Point* convertPoint(::java::awt::Component* arg0, ::java::awt::Point* arg1, ::java::awt::Component* arg2);
    static ::java::awt::Point* convertPoint(::java::awt::Component* arg0, int32_t arg1, int32_t arg2, ::java::awt::Component* arg3);
    static void convertPointFromScreen(::java::awt::Point* arg0, ::java::awt::Component* arg1);
    static void convertPointToScreen(::java::awt::Point* arg0, ::java::awt::Component* arg1);
    static ::java::awt::Rectangle* convertRectangle(::java::awt::Component* arg0, ::java::awt::Rectangle* arg1, ::java::awt::Component* arg2);

public: /* package */
    static ::java::awt::Point* convertScreenLocationToParent(::java::awt::Container* arg0, int32_t arg1, int32_t arg2);
    static bool doesIconReferenceImage(Icon* arg0, ::java::awt::Image* arg1);
    static int32_t findDisplayedMnemonicIndex(::java::lang::String* arg0, int32_t arg1);

public:
    static ::java::awt::Component* findFocusOwner(::java::awt::Component* arg0);
    static ::javax::accessibility::Accessible* getAccessibleAt(::java::awt::Component* arg0, ::java::awt::Point* arg1);
    static ::javax::accessibility::Accessible* getAccessibleChild(::java::awt::Component* arg0, int32_t arg1);
    static int32_t getAccessibleChildrenCount(::java::awt::Component* arg0);
    static int32_t getAccessibleIndexInParent(::java::awt::Component* arg0);
    static ::javax::accessibility::AccessibleStateSet* getAccessibleStateSet(::java::awt::Component* arg0);
    static ::java::awt::Container* getAncestorNamed(::java::lang::String* arg0, ::java::awt::Component* arg1);
    static ::java::awt::Container* getAncestorOfClass(::java::lang::Class* arg0, ::java::awt::Component* arg1);
    /*static CellRendererPane* getCellRendererPane(::java::awt::Component* arg0, ::java::awt::Container* arg1); (private) */
    static ::java::awt::Component* getDeepestComponentAt(::java::awt::Component* arg0, int32_t arg1, int32_t arg2);
    static ::java::awt::Rectangle* getLocalBounds(::java::awt::Component* arg0);

public: /* package */
    static JComponent* getPaintingOrigin(JComponent* arg0);

public:
    static ::java::awt::Component* getRoot(::java::awt::Component* arg0);
    static JRootPane* getRootPane(::java::awt::Component* arg0);

public: /* package */
    static ::java::awt::Frame* getSharedOwnerFrame();
    static ::java::awt::event::WindowListener* getSharedOwnerFrameShutdownListener();
    /*static bool getSuppressDropTarget(); (private) */

public:
    static ActionMap* getUIActionMap(JComponent* arg0);
    static InputMap* getUIInputMap(JComponent* arg0, int32_t arg1);
    static ::java::awt::Container* getUnwrappedParent(::java::awt::Component* arg0);
    static ::java::awt::Component* getUnwrappedView(JViewport* arg0);

public: /* package */
    static ::java::awt::Container* getValidateRoot(::java::awt::Container* arg0, bool arg1);

public:
    static ::java::awt::Window* getWindowAncestor(::java::awt::Component* arg0);

public: /* package */
    static void installSwingDropTargetAsNecessary(::java::awt::Component* arg0, TransferHandler* arg1);

public:
    static void invokeAndWait(::java::lang::Runnable* arg0);
    static void invokeLater(::java::lang::Runnable* arg0);
    static bool isDescendingFrom(::java::awt::Component* arg0, ::java::awt::Component* arg1);
    static bool isEventDispatchThread();
    static bool isLeftMouseButton(::java::awt::event::MouseEvent* arg0);

public: /* package */
    static bool isLeftToRight(::java::awt::Component* arg0);

public:
    static bool isMiddleMouseButton(::java::awt::event::MouseEvent* arg0);
    static bool isRectangleContainingRectangle(::java::awt::Rectangle* arg0, ::java::awt::Rectangle* arg1);
    static bool isRightMouseButton(::java::awt::event::MouseEvent* arg0);

public: /* package */
    static bool isValidKeyEventForKeyBindings(::java::awt::event::KeyEvent* arg0);

public:
    static ::java::lang::String* layoutCompoundLabel(::java::awt::FontMetrics* arg0, ::java::lang::String* arg1, Icon* arg2, int32_t arg3, int32_t arg4, int32_t arg5, int32_t arg6, ::java::awt::Rectangle* arg7, ::java::awt::Rectangle* arg8, ::java::awt::Rectangle* arg9, int32_t arg10);
    static ::java::lang::String* layoutCompoundLabel(JComponent* arg0, ::java::awt::FontMetrics* arg1, ::java::lang::String* arg2, Icon* arg3, int32_t arg4, int32_t arg5, int32_t arg6, int32_t arg7, ::java::awt::Rectangle* arg8, ::java::awt::Rectangle* arg9, ::java::awt::Rectangle* arg10, int32_t arg11);
    /*static ::java::lang::String* layoutCompoundLabelImpl(JComponent* arg0, ::java::awt::FontMetrics* arg1, ::java::lang::String* arg2, Icon* arg3, int32_t arg4, int32_t arg5, int32_t arg6, int32_t arg7, ::java::awt::Rectangle* arg8, ::java::awt::Rectangle* arg9, ::java::awt::Rectangle* arg10, int32_t arg11); (private) */

public: /* package */
    static ::java::lang::Class* loadSystemClass(::java::lang::String* arg0);

public:
    static bool notifyAction(Action* arg0, KeyStroke* arg1, ::java::awt::event::KeyEvent* arg2, ::java::lang::Object* arg3, int32_t arg4);
    static void paintComponent(::java::awt::Graphics* arg0, ::java::awt::Component* arg1, ::java::awt::Container* arg2, ::java::awt::Rectangle* arg3);
    static void paintComponent(::java::awt::Graphics* arg0, ::java::awt::Component* arg1, ::java::awt::Container* arg2, int32_t arg3, int32_t arg4, int32_t arg5, int32_t arg6);
    static bool processKeyBindings(::java::awt::event::KeyEvent* arg0);
    static void replaceUIActionMap(JComponent* arg0, ActionMap* arg1);
    static void replaceUIInputMap(JComponent* arg0, int32_t arg1, InputMap* arg2);
    static void updateComponentTreeUI(::java::awt::Component* arg0);
    /*static void updateComponentTreeUI0(::java::awt::Component* arg0); (private) */

public: /* package */
    static void updateRendererOrEditorUI(::java::lang::Object* arg0);

public:
    static ::java::awt::Window* windowForComponent(::java::awt::Component* arg0);

    // Generated
    SwingUtilities();
protected:
    SwingUtilities(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    static bool& canAccessEventQueue();
    static bool& checkedSuppressDropSupport();
    static bool& eventQueueTested();
    static ::java::lang::Object*& sharedOwnerFrameKey();
    static bool& suppressDropSupport();
    virtual ::java::lang::Class* getClass0();
};
