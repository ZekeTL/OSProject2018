// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/dnd/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/awt/dnd/DragGestureListener.hpp>
#include <java/awt/dnd/DragSourceListener.hpp>

struct default_init_tag;

class javax::swing::TransferHandler_DragHandler
    : public virtual ::java::lang::Object
    , public virtual ::java::awt::dnd::DragGestureListener
    , public virtual ::java::awt::dnd::DragSourceListener
{

public:
    typedef ::java::lang::Object super;

private:
    bool scrolls {  };

    /*void ctor(); (private) */

public:
    void dragDropEnd(::java::awt::dnd::DragSourceDropEvent* arg0) override;
    void dragEnter(::java::awt::dnd::DragSourceDragEvent* arg0) override;
    void dragExit(::java::awt::dnd::DragSourceEvent* arg0) override;
    void dragGestureRecognized(::java::awt::dnd::DragGestureEvent* arg0) override;
    void dragOver(::java::awt::dnd::DragSourceDragEvent* arg0) override;
    void dropActionChanged(::java::awt::dnd::DragSourceDragEvent* arg0) override;

    // Generated
    TransferHandler_DragHandler();
protected:
    TransferHandler_DragHandler(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
