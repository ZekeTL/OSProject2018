// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <javax/swing/event/ChangeListener.hpp>
#include <java/io/Serializable.hpp>

struct default_init_tag;

class javax::swing::JTextField_ScrollRepainter
    : public virtual ::java::lang::Object
    , public virtual ::javax::swing::event::ChangeListener
    , public virtual ::java::io::Serializable
{

public:
    typedef ::java::lang::Object super;

public: /* package */
    JTextField* this$0 {  };

protected:
    void ctor();

public:
    void stateChanged(::javax::swing::event::ChangeEvent* arg0) override;

    // Generated

public: /* package */
    JTextField_ScrollRepainter(JTextField *JTextField_this);
protected:
    JTextField_ScrollRepainter(JTextField *JTextField_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JTextField *JTextField_this;

private:
    virtual ::java::lang::Class* getClass0();
};
