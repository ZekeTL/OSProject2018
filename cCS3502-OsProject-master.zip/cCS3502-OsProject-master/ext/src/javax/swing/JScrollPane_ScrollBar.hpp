// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/JScrollBar.hpp>
#include <javax/swing/plaf/UIResource.hpp>

struct default_init_tag;

class javax::swing::JScrollPane_ScrollBar
    : public JScrollBar
    , public virtual ::javax::swing::plaf::UIResource
{

public:
    typedef JScrollBar super;

private:
    bool blockIncrementSet {  };

public: /* package */
    JScrollPane* this$0 {  };

private:
    bool unitIncrementSet {  };

protected:
    void ctor(int32_t arg0);

public:
    int32_t getBlockIncrement(int32_t arg0) override;
    int32_t getUnitIncrement(int32_t arg0) override;
    void setBlockIncrement(int32_t arg0) override;
    void setUnitIncrement(int32_t arg0) override;

    // Generated
    JScrollPane_ScrollBar(JScrollPane *JScrollPane_this, int32_t arg0);
protected:
    JScrollPane_ScrollBar(JScrollPane *JScrollPane_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    int32_t getBlockIncrement();
    int32_t getUnitIncrement();
    JScrollPane *JScrollPane_this;

private:
    virtual ::java::lang::Class* getClass0();
};
