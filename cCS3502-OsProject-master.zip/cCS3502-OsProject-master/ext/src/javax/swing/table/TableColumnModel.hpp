// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/table/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct javax::swing::table::TableColumnModel
    : public virtual ::java::lang::Object
{

    virtual void addColumn(TableColumn* arg0) = 0;
    virtual void addColumnModelListener(::javax::swing::event::TableColumnModelListener* arg0) = 0;
    virtual TableColumn* getColumn(int32_t arg0) = 0;
    virtual int32_t getColumnCount() = 0;
    virtual int32_t getColumnIndex(::java::lang::Object* arg0) = 0;
    virtual int32_t getColumnIndexAtX(int32_t arg0) = 0;
    virtual int32_t getColumnMargin() = 0;
    virtual bool getColumnSelectionAllowed() = 0;
    virtual ::java::util::Enumeration* getColumns() = 0;
    virtual int32_t getSelectedColumnCount() = 0;
    virtual ::int32_tArray* getSelectedColumns() = 0;
    virtual ::javax::swing::ListSelectionModel* getSelectionModel() = 0;
    virtual int32_t getTotalColumnWidth() = 0;
    virtual void moveColumn(int32_t arg0, int32_t arg1) = 0;
    virtual void removeColumn(TableColumn* arg0) = 0;
    virtual void removeColumnModelListener(::javax::swing::event::TableColumnModelListener* arg0) = 0;
    virtual void setColumnMargin(int32_t arg0) = 0;
    virtual void setColumnSelectionAllowed(bool arg0) = 0;
    virtual void setSelectionModel(::javax::swing::ListSelectionModel* arg0) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
