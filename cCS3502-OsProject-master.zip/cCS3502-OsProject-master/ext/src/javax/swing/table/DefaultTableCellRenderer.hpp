// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/border/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/table/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/JLabel.hpp>
#include <javax/swing/table/TableCellRenderer.hpp>
#include <java/io/Serializable.hpp>

struct default_init_tag;

class javax::swing::table::DefaultTableCellRenderer
    : public ::javax::swing::JLabel
    , public virtual TableCellRenderer
    , public virtual ::java::io::Serializable
{

public:
    typedef ::javax::swing::JLabel super;

private:
    static ::javax::swing::border::Border* DEFAULT_NO_FOCUS_BORDER_;
    static ::javax::swing::border::Border* SAFE_NO_FOCUS_BORDER_;
    static ::javax::swing::border::Border* noFocusBorder_;
    ::java::awt::Color* unselectedBackground {  };
    ::java::awt::Color* unselectedForeground {  };

protected:
    void ctor();

public: /* protected */
    void firePropertyChange(::java::lang::String* arg0, ::java::lang::Object* arg1, ::java::lang::Object* arg2) override;

public:
    void firePropertyChange(::java::lang::String* arg0, bool arg1, bool arg2) override;
    /*::javax::swing::border::Border* getNoFocusBorder(); (private) */
    ::java::awt::Component* getTableCellRendererComponent(::javax::swing::JTable* arg0, ::java::lang::Object* arg1, bool arg2, bool arg3, int32_t arg4, int32_t arg5) override;
    void invalidate() override;
    bool isOpaque() override;
    void repaint() override;
    void repaint(::java::awt::Rectangle* arg0) override;
    void repaint(int64_t arg0, int32_t arg1, int32_t arg2, int32_t arg3, int32_t arg4) override;
    void revalidate() override;
    void setBackground(::java::awt::Color* arg0) override;
    void setForeground(::java::awt::Color* arg0) override;

public: /* protected */
    virtual void setValue(::java::lang::Object* arg0);

public:
    void updateUI() override;
    void validate() override;

    // Generated
    DefaultTableCellRenderer();
protected:
    DefaultTableCellRenderer(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    void firePropertyChange(::java::lang::String* arg0, int32_t arg1, int32_t arg2);
    void firePropertyChange(::java::lang::String* arg0, char16_t arg1, char16_t arg2);
    virtual void firePropertyChange(::java::lang::String* arg0, int8_t arg1, int8_t arg2);
    virtual void firePropertyChange(::java::lang::String* arg0, int16_t arg1, int16_t arg2);
    virtual void firePropertyChange(::java::lang::String* arg0, int64_t arg1, int64_t arg2);
    virtual void firePropertyChange(::java::lang::String* arg0, float arg1, float arg2);
    virtual void firePropertyChange(::java::lang::String* arg0, double arg1, double arg2);
    virtual void repaint(int64_t arg0);
    virtual void repaint(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3);

private:
    static ::javax::swing::border::Border*& DEFAULT_NO_FOCUS_BORDER();
    static ::javax::swing::border::Border*& SAFE_NO_FOCUS_BORDER();

public: /* protected */
    static ::javax::swing::border::Border*& noFocusBorder();

private:
    virtual ::java::lang::Class* getClass0();
};
