// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/table/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct javax::swing::table::TableModel
    : public virtual ::java::lang::Object
{

    virtual void addTableModelListener(::javax::swing::event::TableModelListener* arg0) = 0;
    virtual ::java::lang::Class* getColumnClass(int32_t arg0) = 0;
    virtual int32_t getColumnCount() = 0;
    virtual ::java::lang::String* getColumnName(int32_t arg0) = 0;
    virtual int32_t getRowCount() = 0;
    virtual ::java::lang::Object* getValueAt(int32_t arg0, int32_t arg1) = 0;
    virtual bool isCellEditable(int32_t arg0, int32_t arg1) = 0;
    virtual void removeTableModelListener(::javax::swing::event::TableModelListener* arg0) = 0;
    virtual void setValueAt(::java::lang::Object* arg0, int32_t arg1, int32_t arg2) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
