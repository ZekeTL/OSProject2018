// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <javax/swing/table/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/table/DefaultTableCellRenderer.hpp>
#include <javax/swing/plaf/UIResource.hpp>

struct default_init_tag;

class javax::swing::table::DefaultTableCellRenderer_UIResource
    : public DefaultTableCellRenderer
    , public virtual ::javax::swing::plaf::UIResource
{

public:
    typedef DefaultTableCellRenderer super;

protected:
    void ctor();

    // Generated

public:
    DefaultTableCellRenderer_UIResource();
protected:
    DefaultTableCellRenderer_UIResource(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
