// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/table/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/table/AbstractTableModel.hpp>
#include <java/io/Serializable.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace io
    {
typedef ::SubArray< ::java::io::Serializable, ::java::lang::ObjectArray > SerializableArray;
    } // io

    namespace lang
    {
typedef ::SubArray< ::java::lang::Cloneable, ObjectArray > CloneableArray;
typedef ::SubArray< ::java::lang::ObjectArray, CloneableArray, ::java::io::SerializableArray > ObjectArrayArray;
    } // lang
} // java

struct default_init_tag;

class javax::swing::table::DefaultTableModel
    : public AbstractTableModel
    , public virtual ::java::io::Serializable
{

public:
    typedef AbstractTableModel super;

public: /* protected */
    ::java::util::Vector* columnIdentifiers {  };
    ::java::util::Vector* dataVector {  };

protected:
    void ctor();
    void ctor(int32_t arg0, int32_t arg1);
    void ctor(::java::util::Vector* arg0, int32_t arg1);
    void ctor(::java::lang::ObjectArray* arg0, int32_t arg1);
    void ctor(::java::util::Vector* arg0, ::java::util::Vector* arg1);
    void ctor(::java::lang::ObjectArrayArray* arg0, ::java::lang::ObjectArray* arg1);

public:
    virtual void addColumn(::java::lang::Object* arg0);
    virtual void addColumn(::java::lang::Object* arg0, ::java::util::Vector* arg1);
    virtual void addColumn(::java::lang::Object* arg0, ::java::lang::ObjectArray* arg1);
    virtual void addRow(::java::util::Vector* arg0);
    virtual void addRow(::java::lang::ObjectArray* arg0);

public: /* protected */
    static ::java::util::Vector* convertToVector(::java::lang::ObjectArray* arg0);
    static ::java::util::Vector* convertToVector(::java::lang::ObjectArrayArray* arg0);
    /*static int32_t gcd(int32_t arg0, int32_t arg1); (private) */

public:
    int32_t getColumnCount() override;
    ::java::lang::String* getColumnName(int32_t arg0) override;
    virtual ::java::util::Vector* getDataVector();
    int32_t getRowCount() override;
    ::java::lang::Object* getValueAt(int32_t arg0, int32_t arg1) override;
    virtual void insertRow(int32_t arg0, ::java::util::Vector* arg1);
    virtual void insertRow(int32_t arg0, ::java::lang::ObjectArray* arg1);
    bool isCellEditable(int32_t arg0, int32_t arg1) override;
    /*void justifyRows(int32_t arg0, int32_t arg1); (private) */
    virtual void moveRow(int32_t arg0, int32_t arg1, int32_t arg2);
    virtual void newDataAvailable(::javax::swing::event::TableModelEvent* arg0);
    virtual void newRowsAdded(::javax::swing::event::TableModelEvent* arg0);
    /*static ::java::util::Vector* newVector(int32_t arg0); (private) */
    /*static ::java::util::Vector* nonNullVector(::java::util::Vector* arg0); (private) */
    virtual void removeRow(int32_t arg0);
    /*static void rotate(::java::util::Vector* arg0, int32_t arg1, int32_t arg2, int32_t arg3); (private) */
    virtual void rowsRemoved(::javax::swing::event::TableModelEvent* arg0);
    virtual void setColumnCount(int32_t arg0);
    virtual void setColumnIdentifiers(::java::util::Vector* arg0);
    virtual void setColumnIdentifiers(::java::lang::ObjectArray* arg0);
    virtual void setDataVector(::java::util::Vector* arg0, ::java::util::Vector* arg1);
    virtual void setDataVector(::java::lang::ObjectArrayArray* arg0, ::java::lang::ObjectArray* arg1);
    virtual void setNumRows(int32_t arg0);
    virtual void setRowCount(int32_t arg0);
    void setValueAt(::java::lang::Object* arg0, int32_t arg1, int32_t arg2) override;

    // Generated
    DefaultTableModel();
    DefaultTableModel(int32_t arg0, int32_t arg1);
    DefaultTableModel(::java::util::Vector* arg0, int32_t arg1);
    DefaultTableModel(::java::lang::ObjectArray* arg0, int32_t arg1);
    DefaultTableModel(::java::util::Vector* arg0, ::java::util::Vector* arg1);
    DefaultTableModel(::java::lang::ObjectArrayArray* arg0, ::java::lang::ObjectArray* arg1);
protected:
    DefaultTableModel(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
