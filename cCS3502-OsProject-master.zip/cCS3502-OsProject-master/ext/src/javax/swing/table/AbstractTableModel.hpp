// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/table/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <javax/swing/table/TableModel.hpp>
#include <java/io/Serializable.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace util
    {
typedef ::SubArray< ::java::util::EventListener, ::java::lang::ObjectArray > EventListenerArray;
    } // util
} // java

namespace javax
{
    namespace swing
    {
        namespace event
        {
typedef ::SubArray< ::javax::swing::event::TableModelListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > TableModelListenerArray;
        } // event
    } // swing
} // javax

struct default_init_tag;

class javax::swing::table::AbstractTableModel
    : public virtual ::java::lang::Object
    , public virtual TableModel
    , public virtual ::java::io::Serializable
{

public:
    typedef ::java::lang::Object super;

public: /* protected */
    ::javax::swing::event::EventListenerList* listenerList {  };

protected:
    void ctor();

public:
    void addTableModelListener(::javax::swing::event::TableModelListener* arg0) override;
    virtual int32_t findColumn(::java::lang::String* arg0);
    virtual void fireTableCellUpdated(int32_t arg0, int32_t arg1);
    virtual void fireTableChanged(::javax::swing::event::TableModelEvent* arg0);
    virtual void fireTableDataChanged();
    virtual void fireTableRowsDeleted(int32_t arg0, int32_t arg1);
    virtual void fireTableRowsInserted(int32_t arg0, int32_t arg1);
    virtual void fireTableRowsUpdated(int32_t arg0, int32_t arg1);
    virtual void fireTableStructureChanged();
    ::java::lang::Class* getColumnClass(int32_t arg0) override;
    ::java::lang::String* getColumnName(int32_t arg0) override;
    virtual ::java::util::EventListenerArray* getListeners(::java::lang::Class* arg0);
    virtual ::javax::swing::event::TableModelListenerArray* getTableModelListeners();
    bool isCellEditable(int32_t arg0, int32_t arg1) override;
    void removeTableModelListener(::javax::swing::event::TableModelListener* arg0) override;
    void setValueAt(::java::lang::Object* arg0, int32_t arg1, int32_t arg2) override;

    // Generated
    AbstractTableModel();
protected:
    AbstractTableModel(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
