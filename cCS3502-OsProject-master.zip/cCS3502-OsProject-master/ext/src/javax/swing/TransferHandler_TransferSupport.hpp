// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/datatransfer/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/dnd/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace io
    {
typedef ::SubArray< ::java::io::Serializable, ::java::lang::ObjectArray > SerializableArray;
typedef ::SubArray< ::java::io::Externalizable, ::java::lang::ObjectArray, SerializableArray > ExternalizableArray;
    } // io

    namespace lang
    {
typedef ::SubArray< ::java::lang::Cloneable, ObjectArray > CloneableArray;
    } // lang

    namespace awt
    {
        namespace datatransfer
        {
typedef ::SubArray< ::java::awt::datatransfer::DataFlavor, ::java::lang::ObjectArray, ::java::io::ExternalizableArray, ::java::lang::CloneableArray > DataFlavorArray;
        } // datatransfer
    } // awt
} // java

struct default_init_tag;

class javax::swing::TransferHandler_TransferSupport final
    : public ::java::lang::Object
{

public:
    typedef ::java::lang::Object super;

private:
    static bool $assertionsDisabled_;
    ::java::awt::Component* component {  };
    int32_t dropAction {  };
    TransferHandler_DropLocation* dropLocation {  };
    bool isDrop_ {  };
    bool showDropLocation {  };
    bool showDropLocationIsSet {  };
    ::java::lang::Object* source {  };

    /*void ctor(::java::awt::Component* arg0, ::java::awt::dnd::DropTargetEvent* arg1); (private) */
protected:
    void ctor(::java::awt::Component* arg0, ::java::awt::datatransfer::Transferable* arg1);
    /*void assureIsDrop(); (private) */

public:
    ::java::awt::Component* getComponent();
    ::java::awt::datatransfer::DataFlavorArray* getDataFlavors();
    int32_t getDropAction();
    TransferHandler_DropLocation* getDropLocation();
    int32_t getSourceDropActions();
    ::java::awt::datatransfer::Transferable* getTransferable();
    int32_t getUserDropAction();
    bool isDataFlavorSupported(::java::awt::datatransfer::DataFlavor* arg0);
    bool isDrop();
    /*void setDNDVariables(::java::awt::Component* arg0, ::java::awt::dnd::DropTargetEvent* arg1); (private) */
    void setDropAction(int32_t arg0);
    void setShowDropLocation(bool arg0);

    // Generated
    TransferHandler_TransferSupport(::java::awt::Component* arg0, ::java::awt::datatransfer::Transferable* arg1);
protected:
    TransferHandler_TransferSupport(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

public: /* package */
    static bool& $assertionsDisabled();

private:
    virtual ::java::lang::Class* getClass0();
};
