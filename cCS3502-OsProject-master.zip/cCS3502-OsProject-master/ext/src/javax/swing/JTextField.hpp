// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/beans/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/JTextComponent.hpp>
#include <javax/swing/SwingConstants.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace util
    {
typedef ::SubArray< ::java::util::EventListener, ::java::lang::ObjectArray > EventListenerArray;
    } // util

    namespace awt
    {
        namespace event
        {
typedef ::SubArray< ::java::awt::event::ActionListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > ActionListenerArray;
        } // event
    } // awt
} // java

namespace javax
{
    namespace swing
    {
typedef ::SubArray< ::javax::swing::Action, ::java::lang::ObjectArray, ::java::awt::event::ActionListenerArray > ActionArray;
    } // swing
} // javax

struct default_init_tag;

class javax::swing::JTextField
    : public ::javax::swing::text::JTextComponent
    , public virtual SwingConstants
{

public:
    typedef ::javax::swing::text::JTextComponent super;

private:
    Action* action_ {  };
    ::java::beans::PropertyChangeListener* actionPropertyChangeListener {  };
    int32_t columnWidth {  };
    int32_t columns {  };
    ::java::lang::String* command {  };
    static ActionArray* defaultActions_;
    int32_t horizontalAlignment {  };
    static ::java::lang::String* notifyAction_;
    static ::java::lang::String* uiClassID_;
    BoundedRangeModel* visibility {  };

protected:
    void ctor();
    void ctor(::java::lang::String* arg0);
    void ctor(int32_t arg0);
    void ctor(::java::lang::String* arg0, int32_t arg1);
    void ctor(::javax::swing::text::Document* arg0, ::java::lang::String* arg1, int32_t arg2);

public: /* protected */
    virtual void actionPropertyChanged(Action* arg0, ::java::lang::String* arg1);

public:
    virtual void addActionListener(::java::awt::event::ActionListener* arg0);

public: /* protected */
    virtual void configurePropertiesFromAction(Action* arg0);
    virtual ::java::beans::PropertyChangeListener* createActionPropertyChangeListener(Action* arg0);
    virtual ::javax::swing::text::Document* createDefaultModel();
    virtual void fireActionPerformed();

public:
    ::javax::accessibility::AccessibleContext* getAccessibleContext() override;
    virtual Action* getAction();
    virtual ::java::awt::event::ActionListenerArray* getActionListeners();
    ActionArray* getActions() override;

public: /* protected */
    virtual int32_t getColumnWidth();

public:
    virtual int32_t getColumns();
    virtual int32_t getHorizontalAlignment();
    virtual BoundedRangeModel* getHorizontalVisibility();
    ::java::awt::Dimension* getPreferredSize() override;
    virtual int32_t getScrollOffset();
    ::java::lang::String* getUIClassID() override;

public: /* package */
    virtual bool hasActionListener();
    /*bool isListener(::java::lang::Class* arg0, ::java::awt::event::ActionListener* arg1); (private) */

public:
    bool isValidateRoot() override;

public: /* protected */
    ::java::lang::String* paramString() override;

public:
    virtual void postActionEvent();
    virtual void removeActionListener(::java::awt::event::ActionListener* arg0);
    void scrollRectToVisible(::java::awt::Rectangle* arg0) override;
    virtual void setAction(Action* arg0);
    virtual void setActionCommand(::java::lang::String* arg0);
    /*void setActionCommandFromAction(Action* arg0); (private) */
    virtual void setColumns(int32_t arg0);
    void setDocument(::javax::swing::text::Document* arg0) override;
    void setFont(::java::awt::Font* arg0) override;
    virtual void setHorizontalAlignment(int32_t arg0);
    virtual void setScrollOffset(int32_t arg0);
    /*void writeObject(::java::io::ObjectOutputStream* arg0); (private) */

    // Generated
    JTextField();
    JTextField(::java::lang::String* arg0);
    JTextField(int32_t arg0);
    JTextField(::java::lang::String* arg0, int32_t arg1);
    JTextField(::javax::swing::text::Document* arg0, ::java::lang::String* arg1, int32_t arg2);
protected:
    JTextField(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    static ActionArray*& defaultActions();

public:
    static ::java::lang::String*& notifyAction();

private:
    static ::java::lang::String*& uiClassID();
    virtual ::java::lang::Class* getClass0();
};
