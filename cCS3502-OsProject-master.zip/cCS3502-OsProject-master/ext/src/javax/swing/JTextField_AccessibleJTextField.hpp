// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/JTextComponent_AccessibleJTextComponent.hpp>

struct default_init_tag;

class javax::swing::JTextField_AccessibleJTextField
    : public ::javax::swing::text::JTextComponent_AccessibleJTextComponent
{

public:
    typedef ::javax::swing::text::JTextComponent_AccessibleJTextComponent super;

public: /* package */
    JTextField* this$0 {  };

protected:
    void ctor();

public:
    ::javax::accessibility::AccessibleStateSet* getAccessibleStateSet() override;

    // Generated

public: /* protected */
    JTextField_AccessibleJTextField(JTextField *JTextField_this);
protected:
    JTextField_AccessibleJTextField(JTextField *JTextField_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JTextField *JTextField_this;

private:
    virtual ::java::lang::Class* getClass0();
};
