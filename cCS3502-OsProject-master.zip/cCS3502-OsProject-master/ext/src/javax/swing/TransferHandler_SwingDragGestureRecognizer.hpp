// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/dnd/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/dnd/DragGestureRecognizer.hpp>

struct default_init_tag;

class javax::swing::TransferHandler_SwingDragGestureRecognizer
    : public ::java::awt::dnd::DragGestureRecognizer
{

public:
    typedef ::java::awt::dnd::DragGestureRecognizer super;

protected:
    void ctor(::java::awt::dnd::DragGestureListener* arg0);

public: /* package */
    virtual void gestured(JComponent* arg0, ::java::awt::event::MouseEvent* arg1, int32_t arg2, int32_t arg3);

public: /* protected */
    void registerListeners() override;
    void unregisterListeners() override;

    // Generated

public: /* package */
    TransferHandler_SwingDragGestureRecognizer(::java::awt::dnd::DragGestureListener* arg0);
protected:
    TransferHandler_SwingDragGestureRecognizer(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
