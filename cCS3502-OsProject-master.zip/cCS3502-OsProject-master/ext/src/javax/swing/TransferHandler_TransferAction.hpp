// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/datatransfer/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <sun/misc/fwd-CS3502-OsProject-master.hpp>
#include <sun/swing/UIAction.hpp>
#include <javax/swing/plaf/UIResource.hpp>

struct default_init_tag;

class javax::swing::TransferHandler_TransferAction
    : public ::sun::swing::UIAction
    , public virtual ::javax::swing::plaf::UIResource
{

public:
    typedef ::sun::swing::UIAction super;

private:
    static ::java::lang::Object* SandboxClipboardKey_;
    static ::sun::misc::JavaSecurityAccess* javaSecurityAccess_;

protected:
    void ctor(::java::lang::String* arg0);

public:
    void actionPerformed(::java::awt::event::ActionEvent* arg0) override;
    /*void actionPerformedImpl(::java::awt::event::ActionEvent* arg0); (private) */
    /*::java::awt::datatransfer::Clipboard* getClipboard(JComponent* arg0); (private) */
    bool isEnabled(::java::lang::Object* arg0) override;

    // Generated

public: /* package */
    TransferHandler_TransferAction(::java::lang::String* arg0);
protected:
    TransferHandler_TransferAction(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    bool isEnabled();

private:
    static ::java::lang::Object*& SandboxClipboardKey();
    static ::sun::misc::JavaSecurityAccess*& javaSecurityAccess();
    virtual ::java::lang::Class* getClass0();
};
