// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Enum.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace io
    {
typedef ::SubArray< ::java::io::Serializable, ::java::lang::ObjectArray > SerializableArray;
    } // io

    namespace lang
    {
typedef ::SubArray< ::java::lang::Comparable, ObjectArray > ComparableArray;
typedef ::SubArray< ::java::lang::Enum, ObjectArray, ComparableArray, ::java::io::SerializableArray > EnumArray;
    } // lang
} // java

namespace javax
{
    namespace swing
    {
typedef ::SubArray< ::javax::swing::JTable_PrintMode, ::java::lang::EnumArray > JTable_PrintModeArray;
    } // swing
} // javax

struct default_init_tag;

class javax::swing::JTable_PrintMode final
    : public ::java::lang::Enum
{

public:
    typedef ::java::lang::Enum super;

private:
    static JTable_PrintModeArray* $VALUES_;

public:
    static JTable_PrintMode* FIT_WIDTH;
    static JTable_PrintMode* NORMAL;

    /*void ctor(::java::lang::String* name, int ordinal); (private) */
    static JTable_PrintMode* valueOf(::java::lang::String* arg0);
    static JTable_PrintModeArray* values();

    // Generated
    JTable_PrintMode(::java::lang::String* name, int ordinal);
protected:
    JTable_PrintMode(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    static ::java::lang::Enum* valueOf(::java::lang::Class* arg0, ::java::lang::String* name);

private:
    static JTable_PrintModeArray*& $VALUES();
    virtual ::java::lang::Class* getClass0();
};
