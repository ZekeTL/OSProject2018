// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct javax::swing::RootPaneContainer
    : public virtual ::java::lang::Object
{

    virtual ::java::awt::Container* getContentPane() = 0;
    virtual ::java::awt::Component* getGlassPane() = 0;
    virtual JLayeredPane* getLayeredPane() = 0;
    virtual JRootPane* getRootPane() = 0;
    virtual void setContentPane(::java::awt::Container* arg0) = 0;
    virtual void setGlassPane(::java::awt::Component* arg0) = 0;
    virtual void setLayeredPane(JLayeredPane* arg0) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
