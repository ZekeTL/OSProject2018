// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/JTextComponent_AccessibleJTextComponent.hpp>

struct default_init_tag;

class javax::swing::JTextArea_AccessibleJTextArea
    : public ::javax::swing::text::JTextComponent_AccessibleJTextComponent
{

public:
    typedef ::javax::swing::text::JTextComponent_AccessibleJTextComponent super;

public: /* package */
    JTextArea* this$0 {  };

protected:
    void ctor();

public:
    ::javax::accessibility::AccessibleStateSet* getAccessibleStateSet() override;

    // Generated

public: /* protected */
    JTextArea_AccessibleJTextArea(JTextArea *JTextArea_this);
protected:
    JTextArea_AccessibleJTextArea(JTextArea *JTextArea_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JTextArea *JTextArea_this;

private:
    virtual ::java::lang::Class* getClass0();
};
