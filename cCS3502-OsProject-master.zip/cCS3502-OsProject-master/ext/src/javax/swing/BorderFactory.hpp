// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/border/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct default_init_tag;

class javax::swing::BorderFactory
    : public virtual ::java::lang::Object
{

public:
    typedef ::java::lang::Object super;

private:
    static ::javax::swing::border::Border* emptyBorder_;
    static ::javax::swing::border::Border* sharedDashedBorder_;
    static ::javax::swing::border::Border* sharedEtchedBorder_;
    static ::javax::swing::border::Border* sharedLoweredBevel_;
    static ::javax::swing::border::Border* sharedRaisedBevel_;
    static ::javax::swing::border::Border* sharedRaisedEtchedBorder_;
    static ::javax::swing::border::Border* sharedSoftLoweredBevel_;
    static ::javax::swing::border::Border* sharedSoftRaisedBevel_;

    /*void ctor(); (private) */

public:
    static ::javax::swing::border::Border* createBevelBorder(int32_t arg0);
    static ::javax::swing::border::Border* createBevelBorder(int32_t arg0, ::java::awt::Color* arg1, ::java::awt::Color* arg2);
    static ::javax::swing::border::Border* createBevelBorder(int32_t arg0, ::java::awt::Color* arg1, ::java::awt::Color* arg2, ::java::awt::Color* arg3, ::java::awt::Color* arg4);
    static ::javax::swing::border::CompoundBorder* createCompoundBorder();
    static ::javax::swing::border::CompoundBorder* createCompoundBorder(::javax::swing::border::Border* arg0, ::javax::swing::border::Border* arg1);
    static ::javax::swing::border::Border* createDashedBorder(::java::awt::Paint* arg0);
    static ::javax::swing::border::Border* createDashedBorder(::java::awt::Paint* arg0, float arg1, float arg2);
    static ::javax::swing::border::Border* createDashedBorder(::java::awt::Paint* arg0, float arg1, float arg2, float arg3, bool arg4);
    static ::javax::swing::border::Border* createEmptyBorder();
    static ::javax::swing::border::Border* createEmptyBorder(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3);
    static ::javax::swing::border::Border* createEtchedBorder();
    static ::javax::swing::border::Border* createEtchedBorder(int32_t arg0);
    static ::javax::swing::border::Border* createEtchedBorder(::java::awt::Color* arg0, ::java::awt::Color* arg1);
    static ::javax::swing::border::Border* createEtchedBorder(int32_t arg0, ::java::awt::Color* arg1, ::java::awt::Color* arg2);
    static ::javax::swing::border::Border* createLineBorder(::java::awt::Color* arg0);
    static ::javax::swing::border::Border* createLineBorder(::java::awt::Color* arg0, int32_t arg1);
    static ::javax::swing::border::Border* createLineBorder(::java::awt::Color* arg0, int32_t arg1, bool arg2);
    static ::javax::swing::border::Border* createLoweredBevelBorder();
    static ::javax::swing::border::Border* createLoweredSoftBevelBorder();
    static ::javax::swing::border::MatteBorder* createMatteBorder(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3, ::java::awt::Color* arg4);
    static ::javax::swing::border::MatteBorder* createMatteBorder(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3, Icon* arg4);
    static ::javax::swing::border::Border* createRaisedBevelBorder();
    static ::javax::swing::border::Border* createRaisedSoftBevelBorder();

public: /* package */
    static ::javax::swing::border::Border* createSharedBevel(int32_t arg0);

public:
    static ::javax::swing::border::Border* createSoftBevelBorder(int32_t arg0);
    static ::javax::swing::border::Border* createSoftBevelBorder(int32_t arg0, ::java::awt::Color* arg1, ::java::awt::Color* arg2);
    static ::javax::swing::border::Border* createSoftBevelBorder(int32_t arg0, ::java::awt::Color* arg1, ::java::awt::Color* arg2, ::java::awt::Color* arg3, ::java::awt::Color* arg4);
    static ::javax::swing::border::Border* createStrokeBorder(::java::awt::BasicStroke* arg0);
    static ::javax::swing::border::Border* createStrokeBorder(::java::awt::BasicStroke* arg0, ::java::awt::Paint* arg1);
    static ::javax::swing::border::TitledBorder* createTitledBorder(::java::lang::String* arg0);
    static ::javax::swing::border::TitledBorder* createTitledBorder(::javax::swing::border::Border* arg0);
    static ::javax::swing::border::TitledBorder* createTitledBorder(::javax::swing::border::Border* arg0, ::java::lang::String* arg1);
    static ::javax::swing::border::TitledBorder* createTitledBorder(::javax::swing::border::Border* arg0, ::java::lang::String* arg1, int32_t arg2, int32_t arg3);
    static ::javax::swing::border::TitledBorder* createTitledBorder(::javax::swing::border::Border* arg0, ::java::lang::String* arg1, int32_t arg2, int32_t arg3, ::java::awt::Font* arg4);
    static ::javax::swing::border::TitledBorder* createTitledBorder(::javax::swing::border::Border* arg0, ::java::lang::String* arg1, int32_t arg2, int32_t arg3, ::java::awt::Font* arg4, ::java::awt::Color* arg5);

    // Generated
    BorderFactory();
protected:
    BorderFactory(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

public: /* package */
    static ::javax::swing::border::Border*& emptyBorder();

private:
    static ::javax::swing::border::Border*& sharedDashedBorder();

public: /* package */
    static ::javax::swing::border::Border*& sharedEtchedBorder();
    static ::javax::swing::border::Border*& sharedLoweredBevel();
    static ::javax::swing::border::Border*& sharedRaisedBevel();

private:
    static ::javax::swing::border::Border*& sharedRaisedEtchedBorder();
    static ::javax::swing::border::Border*& sharedSoftLoweredBevel();
    static ::javax::swing::border::Border*& sharedSoftRaisedBevel();
    virtual ::java::lang::Class* getClass0();
};
