// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/dnd/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/awt/dnd/DropTargetListener.hpp>
#include <java/io/Serializable.hpp>
#include <java/awt/event/ActionListener.hpp>

struct default_init_tag;

class javax::swing::TransferHandler_DropHandler
    : public virtual ::java::lang::Object
    , public virtual ::java::awt::dnd::DropTargetListener
    , public virtual ::java::io::Serializable
    , public virtual ::java::awt::event::ActionListener
{

public:
    typedef ::java::lang::Object super;

private:
    static constexpr int32_t AUTOSCROLL_INSET { int32_t(10) };
    ::java::awt::Component* component {  };
    int32_t hysteresis {  };
    ::java::awt::Rectangle* inner {  };
    ::java::awt::Point* lastPosition {  };
    ::java::awt::Rectangle* outer {  };
    ::java::lang::Object* state {  };
    TransferHandler_TransferSupport* support {  };
    Timer* timer {  };

    /*void ctor(); (private) */

public:
    void actionPerformed(::java::awt::event::ActionEvent* arg0) override;
    /*void autoscroll(JComponent* arg0, ::java::awt::Point* arg1); (private) */
    /*void cleanup(bool arg0); (private) */
    void dragEnter(::java::awt::dnd::DropTargetDragEvent* arg0) override;
    void dragExit(::java::awt::dnd::DropTargetEvent* arg0) override;
    void dragOver(::java::awt::dnd::DropTargetDragEvent* arg0) override;
    void drop(::java::awt::dnd::DropTargetDropEvent* arg0) override;
    void dropActionChanged(::java::awt::dnd::DropTargetDragEvent* arg0) override;
    /*void handleDrag(::java::awt::dnd::DropTargetDragEvent* arg0); (private) */
    /*void initPropertiesIfNecessary(); (private) */
    /*void setComponentDropLocation(TransferHandler_TransferSupport* arg0, bool arg1); (private) */
    /*void updateAutoscrollRegion(JComponent* arg0); (private) */

    // Generated
    TransferHandler_DropHandler();
protected:
    TransferHandler_DropHandler(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
