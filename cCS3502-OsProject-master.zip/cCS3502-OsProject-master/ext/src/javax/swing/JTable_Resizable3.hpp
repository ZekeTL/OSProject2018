// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/JTable_Resizable2.hpp>

struct javax::swing::JTable_Resizable3
    : public virtual JTable_Resizable2
{

    virtual int32_t getMidPointAt(int32_t arg0) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
