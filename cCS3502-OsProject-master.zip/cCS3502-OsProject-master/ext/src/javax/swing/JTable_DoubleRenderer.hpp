// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/text/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/JTable_NumberRenderer.hpp>

struct default_init_tag;

class javax::swing::JTable_DoubleRenderer
    : public JTable_NumberRenderer
{

public:
    typedef JTable_NumberRenderer super;

public: /* package */
    ::java::text::NumberFormat* formatter {  };

protected:
    void ctor();

public:
    void setValue(::java::lang::Object* arg0) override;

    // Generated
    JTable_DoubleRenderer();
protected:
    JTable_DoubleRenderer(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
