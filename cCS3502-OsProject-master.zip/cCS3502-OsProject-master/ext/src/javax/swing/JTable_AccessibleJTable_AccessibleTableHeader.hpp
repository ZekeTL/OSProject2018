// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/table/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <javax/accessibility/AccessibleTable.hpp>

struct default_init_tag;

class javax::swing::JTable_AccessibleJTable_AccessibleTableHeader
    : public virtual ::java::lang::Object
    , public virtual ::javax::accessibility::AccessibleTable
{

public:
    typedef ::java::lang::Object super;

private:
    ::javax::swing::table::JTableHeader* header {  };
    ::javax::swing::table::TableColumnModel* headerModel {  };

public: /* package */
    JTable_AccessibleJTable* this$1 {  };

protected:
    void ctor(::javax::swing::table::JTableHeader* arg0);

public:
    ::javax::accessibility::Accessible* getAccessibleAt(int32_t arg0, int32_t arg1) override;
    ::javax::accessibility::Accessible* getAccessibleCaption() override;
    int32_t getAccessibleColumnCount() override;
    ::javax::accessibility::Accessible* getAccessibleColumnDescription(int32_t arg0) override;
    int32_t getAccessibleColumnExtentAt(int32_t arg0, int32_t arg1) override;
    ::javax::accessibility::AccessibleTable* getAccessibleColumnHeader() override;
    int32_t getAccessibleRowCount() override;
    ::javax::accessibility::Accessible* getAccessibleRowDescription(int32_t arg0) override;
    int32_t getAccessibleRowExtentAt(int32_t arg0, int32_t arg1) override;
    ::javax::accessibility::AccessibleTable* getAccessibleRowHeader() override;
    ::javax::accessibility::Accessible* getAccessibleSummary() override;
    ::int32_tArray* getSelectedAccessibleColumns() override;
    ::int32_tArray* getSelectedAccessibleRows() override;
    bool isAccessibleColumnSelected(int32_t arg0) override;
    bool isAccessibleRowSelected(int32_t arg0) override;
    bool isAccessibleSelected(int32_t arg0, int32_t arg1) override;
    void setAccessibleCaption(::javax::accessibility::Accessible* arg0) override;
    void setAccessibleColumnDescription(int32_t arg0, ::javax::accessibility::Accessible* arg1) override;
    void setAccessibleColumnHeader(::javax::accessibility::AccessibleTable* arg0) override;
    void setAccessibleRowDescription(int32_t arg0, ::javax::accessibility::Accessible* arg1) override;
    void setAccessibleRowHeader(::javax::accessibility::AccessibleTable* arg0) override;
    void setAccessibleSummary(::javax::accessibility::Accessible* arg0) override;

    // Generated

public: /* package */
    JTable_AccessibleJTable_AccessibleTableHeader(JTable_AccessibleJTable *JTable_AccessibleJTable_this, ::javax::swing::table::JTableHeader* arg0);
protected:
    JTable_AccessibleJTable_AccessibleTableHeader(JTable_AccessibleJTable *JTable_AccessibleJTable_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JTable_AccessibleJTable *JTable_AccessibleJTable_this;

private:
    virtual ::java::lang::Class* getClass0();
};
