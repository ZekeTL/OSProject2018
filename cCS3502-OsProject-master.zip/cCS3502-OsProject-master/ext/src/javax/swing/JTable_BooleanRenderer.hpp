// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/border/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/JCheckBox.hpp>
#include <javax/swing/table/TableCellRenderer.hpp>
#include <javax/swing/plaf/UIResource.hpp>

struct default_init_tag;

class javax::swing::JTable_BooleanRenderer
    : public JCheckBox
    , public virtual ::javax::swing::table::TableCellRenderer
    , public virtual ::javax::swing::plaf::UIResource
{

public:
    typedef JCheckBox super;

private:
    static ::javax::swing::border::Border* noFocusBorder_;

protected:
    void ctor();

public:
    ::java::awt::Component* getTableCellRendererComponent(JTable* arg0, ::java::lang::Object* arg1, bool arg2, bool arg3, int32_t arg4, int32_t arg5) override;

    // Generated
    JTable_BooleanRenderer();
protected:
    JTable_BooleanRenderer(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    static ::javax::swing::border::Border*& noFocusBorder();
    virtual ::java::lang::Class* getClass0();
};
