// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/beans/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/beans/PropertyChangeListener.hpp>

struct default_init_tag;

class javax::swing::JTable_CellEditorRemover
    : public virtual ::java::lang::Object
    , public virtual ::java::beans::PropertyChangeListener
{

public:
    typedef ::java::lang::Object super;

public: /* package */
    ::java::awt::KeyboardFocusManager* focusManager {  };
    JTable* this$0 {  };

protected:
    void ctor(::java::awt::KeyboardFocusManager* arg0);

public:
    void propertyChange(::java::beans::PropertyChangeEvent* arg0) override;

    // Generated
    JTable_CellEditorRemover(JTable *JTable_this, ::java::awt::KeyboardFocusManager* arg0);
protected:
    JTable_CellEditorRemover(JTable *JTable_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JTable *JTable_this;

private:
    virtual ::java::lang::Class* getClass0();
};
