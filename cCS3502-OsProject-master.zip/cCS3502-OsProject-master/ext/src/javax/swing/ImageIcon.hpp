// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/image/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/net/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <javax/swing/Icon.hpp>
#include <java/io/Serializable.hpp>
#include <javax/accessibility/Accessible.hpp>

struct default_init_tag;

class javax::swing::ImageIcon
    : public virtual ::java::lang::Object
    , public virtual Icon
    , public virtual ::java::io::Serializable
    , public virtual ::javax::accessibility::Accessible
{

public:
    typedef ::java::lang::Object super;

private:
    static ::java::lang::Object* TRACKER_KEY_;
    ImageIcon_AccessibleImageIcon* accessibleContext {  };
    static ::java::awt::Component* component_;

public: /* package */
    ::java::lang::String* description {  };

private:
    ::java::lang::String* filename {  };

public: /* package */
    int32_t height {  };
    ::java::awt::Image* image {  };
    ::java::awt::image::ImageObserver* imageObserver {  };
    int32_t loadStatus {  };

private:
    ::java::net::URL* location {  };
    static int32_t mediaTrackerID_;
    static ::java::awt::MediaTracker* tracker_;

public: /* package */
    int32_t width {  };

protected:
    void ctor();
    void ctor(::java::lang::String* arg0);
    void ctor(::java::net::URL* arg0);
    void ctor(::java::awt::Image* arg0);
    void ctor(::int8_tArray* arg0);
    void ctor(::java::lang::String* arg0, ::java::lang::String* arg1);
    void ctor(::java::net::URL* arg0, ::java::lang::String* arg1);
    void ctor(::java::awt::Image* arg0, ::java::lang::String* arg1);
    void ctor(::int8_tArray* arg0, ::java::lang::String* arg1);
    /*static ::java::awt::Component* createNoPermsComponent(); (private) */

public:
    ::javax::accessibility::AccessibleContext* getAccessibleContext() override;
    virtual ::java::lang::String* getDescription();
    int32_t getIconHeight() override;
    int32_t getIconWidth() override;
    virtual ::java::awt::Image* getImage();
    virtual int32_t getImageLoadStatus();
    virtual ::java::awt::image::ImageObserver* getImageObserver();
    /*int32_t getNextID(); (private) */
    /*::java::awt::MediaTracker* getTracker(); (private) */

public: /* protected */
    virtual void loadImage(::java::awt::Image* arg0);

public:
    void paintIcon(::java::awt::Component* arg0, ::java::awt::Graphics* arg1, int32_t arg2, int32_t arg3) override;
    /*void readObject(::java::io::ObjectInputStream* arg0); (private) */
    virtual void setDescription(::java::lang::String* arg0);
    virtual void setImage(::java::awt::Image* arg0);
    virtual void setImageObserver(::java::awt::image::ImageObserver* arg0);
    ::java::lang::String* toString() override;
    /*void writeObject(::java::io::ObjectOutputStream* arg0); (private) */

    // Generated
    ImageIcon();
    ImageIcon(::java::lang::String* arg0);
    ImageIcon(::java::net::URL* arg0);
    ImageIcon(::java::awt::Image* arg0);
    ImageIcon(::int8_tArray* arg0);
    ImageIcon(::java::lang::String* arg0, ::java::lang::String* arg1);
    ImageIcon(::java::net::URL* arg0, ::java::lang::String* arg1);
    ImageIcon(::java::awt::Image* arg0, ::java::lang::String* arg1);
    ImageIcon(::int8_tArray* arg0, ::java::lang::String* arg1);
protected:
    ImageIcon(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    static ::java::lang::Object*& TRACKER_KEY();

public: /* protected */
    static ::java::awt::Component*& component();

private:
    static int32_t& mediaTrackerID();

public: /* protected */
    static ::java::awt::MediaTracker*& tracker();

private:
    virtual ::java::lang::Class* getClass0();
};
