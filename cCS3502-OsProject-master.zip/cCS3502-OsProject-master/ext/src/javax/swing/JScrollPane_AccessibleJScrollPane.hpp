// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/beans/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/JComponent_AccessibleJComponent.hpp>
#include <javax/swing/event/ChangeListener.hpp>
#include <java/beans/PropertyChangeListener.hpp>

struct default_init_tag;

class javax::swing::JScrollPane_AccessibleJScrollPane
    : public JComponent_AccessibleJComponent
    , public virtual ::javax::swing::event::ChangeListener
    , public virtual ::java::beans::PropertyChangeListener
{

public:
    typedef JComponent_AccessibleJComponent super;

public: /* package */
    JScrollPane* this$0 {  };

public: /* protected */
    JViewport* viewPort {  };

protected:
    void ctor();

public:
    ::javax::accessibility::AccessibleRole* getAccessibleRole() override;
    void propertyChange(::java::beans::PropertyChangeEvent* arg0) override;
    virtual void resetViewPort();

public: /* package */
    virtual void setScrollBarRelations(JScrollBar* arg0);

public:
    void stateChanged(::javax::swing::event::ChangeEvent* arg0) override;

    // Generated
    JScrollPane_AccessibleJScrollPane(JScrollPane *JScrollPane_this);
protected:
    JScrollPane_AccessibleJScrollPane(JScrollPane *JScrollPane_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JScrollPane *JScrollPane_this;

private:
    virtual ::java::lang::Class* getClass0();
};
