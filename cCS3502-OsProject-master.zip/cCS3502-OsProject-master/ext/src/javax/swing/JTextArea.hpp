// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/text/JTextComponent.hpp>

struct default_init_tag;

class javax::swing::JTextArea
    : public ::javax::swing::text::JTextComponent
{

public:
    typedef ::javax::swing::text::JTextComponent super;

private:
    int32_t columnWidth {  };
    int32_t columns {  };
    int32_t rowHeight {  };
    int32_t rows {  };
    static ::java::lang::String* uiClassID_;
    bool word {  };
    bool wrap {  };

protected:
    void ctor();
    void ctor(::java::lang::String* arg0);
    void ctor(::javax::swing::text::Document* arg0);
    void ctor(int32_t arg0, int32_t arg1);
    void ctor(::java::lang::String* arg0, int32_t arg1, int32_t arg2);
    void ctor(::javax::swing::text::Document* arg0, ::java::lang::String* arg1, int32_t arg2, int32_t arg3);

public:
    virtual void append(::java::lang::String* arg0);

public: /* protected */
    virtual ::javax::swing::text::Document* createDefaultModel();

public:
    ::javax::accessibility::AccessibleContext* getAccessibleContext() override;

public: /* protected */
    virtual int32_t getColumnWidth();

public:
    virtual int32_t getColumns();
    virtual int32_t getLineCount();
    virtual int32_t getLineEndOffset(int32_t arg0);
    virtual int32_t getLineOfOffset(int32_t arg0);
    virtual int32_t getLineStartOffset(int32_t arg0);
    virtual bool getLineWrap();
    ::java::awt::Dimension* getPreferredScrollableViewportSize() override;
    ::java::awt::Dimension* getPreferredSize() override;

public: /* protected */
    virtual int32_t getRowHeight();

public:
    virtual int32_t getRows();
    bool getScrollableTracksViewportWidth() override;
    int32_t getScrollableUnitIncrement(::java::awt::Rectangle* arg0, int32_t arg1, int32_t arg2) override;
    virtual int32_t getTabSize();
    ::java::lang::String* getUIClassID() override;
    virtual bool getWrapStyleWord();
    virtual void insert(::java::lang::String* arg0, int32_t arg1);

public: /* protected */
    ::java::lang::String* paramString() override;

public:
    virtual void replaceRange(::java::lang::String* arg0, int32_t arg1, int32_t arg2);
    virtual void setColumns(int32_t arg0);
    void setFont(::java::awt::Font* arg0) override;
    virtual void setLineWrap(bool arg0);
    virtual void setRows(int32_t arg0);
    virtual void setTabSize(int32_t arg0);
    virtual void setWrapStyleWord(bool arg0);
    /*void writeObject(::java::io::ObjectOutputStream* arg0); (private) */

    // Generated
    JTextArea();
    JTextArea(::java::lang::String* arg0);
    JTextArea(::javax::swing::text::Document* arg0);
    JTextArea(int32_t arg0, int32_t arg1);
    JTextArea(::java::lang::String* arg0, int32_t arg1, int32_t arg2);
    JTextArea(::javax::swing::text::Document* arg0, ::java::lang::String* arg1, int32_t arg2, int32_t arg3);
protected:
    JTextArea(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    static ::java::lang::String*& uiClassID();
    virtual ::java::lang::Class* getClass0();
};
