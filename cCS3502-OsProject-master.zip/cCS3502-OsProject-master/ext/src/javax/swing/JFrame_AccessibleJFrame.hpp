// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/Frame_AccessibleAWTFrame.hpp>

struct default_init_tag;

class javax::swing::JFrame_AccessibleJFrame
    : public ::java::awt::Frame_AccessibleAWTFrame
{

public:
    typedef ::java::awt::Frame_AccessibleAWTFrame super;

public: /* package */
    JFrame* this$0 {  };

protected:
    void ctor();

public:
    ::java::lang::String* getAccessibleName() override;
    ::javax::accessibility::AccessibleStateSet* getAccessibleStateSet() override;

    // Generated

public: /* protected */
    JFrame_AccessibleJFrame(JFrame *JFrame_this);
protected:
    JFrame_AccessibleJFrame(JFrame *JFrame_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JFrame *JFrame_this;

private:
    virtual ::java::lang::Class* getClass0();
};
