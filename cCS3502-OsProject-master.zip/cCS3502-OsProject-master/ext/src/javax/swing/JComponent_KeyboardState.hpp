// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/io/Serializable.hpp>

struct default_init_tag;

class javax::swing::JComponent_KeyboardState
    : public virtual ::java::lang::Object
    , public virtual ::java::io::Serializable
{

public:
    typedef ::java::lang::Object super;

private:
    static ::java::lang::Object* keyCodesKey_;

protected:
    void ctor();

public: /* package */
    static JComponent_IntVector* getKeyCodeArray_();
    static bool keyIsPressed(int32_t arg0);
    static void registerKeyPressed(int32_t arg0);
    static void registerKeyReleased(int32_t arg0);
    static bool shouldProcess(::java::awt::event::KeyEvent* arg0);

    // Generated
    JComponent_KeyboardState();
protected:
    JComponent_KeyboardState(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    static ::java::lang::Object*& keyCodesKey();
    virtual ::java::lang::Class* getClass0();
};
