// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <java/util/EventListener.hpp>

struct javax::swing::event::RowSorterListener
    : public virtual ::java::util::EventListener
{

    virtual void sorterChanged(RowSorterEvent* arg0) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
