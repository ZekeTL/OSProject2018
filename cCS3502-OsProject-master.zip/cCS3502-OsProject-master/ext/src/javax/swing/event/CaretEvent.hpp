// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <java/util/EventObject.hpp>

struct default_init_tag;

class javax::swing::event::CaretEvent
    : public ::java::util::EventObject
{

public:
    typedef ::java::util::EventObject super;

protected:
    void ctor(::java::lang::Object* arg0);

public:
    virtual int32_t getDot() = 0;
    virtual int32_t getMark() = 0;

    // Generated
    CaretEvent(::java::lang::Object* arg0);
protected:
    CaretEvent(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
