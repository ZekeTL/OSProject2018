// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/lang/ref/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/ref/WeakReference.hpp>

struct default_init_tag;

class javax::swing::ActionPropertyChangeListener_OwnedWeakReference
    : public ::java::lang::ref::WeakReference
{

public:
    typedef ::java::lang::ref::WeakReference super;

private:
    ActionPropertyChangeListener* owner {  };

protected:
    void ctor(JComponent* arg0, ::java::lang::ref::ReferenceQueue* arg1, ActionPropertyChangeListener* arg2);

public:
    virtual ActionPropertyChangeListener* getOwner();

    // Generated

public: /* package */
    ActionPropertyChangeListener_OwnedWeakReference(JComponent* arg0, ::java::lang::ref::ReferenceQueue* arg1, ActionPropertyChangeListener* arg2);
protected:
    ActionPropertyChangeListener_OwnedWeakReference(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
