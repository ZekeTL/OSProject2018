// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/beans/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/plaf/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/JComponent.hpp>
#include <java/awt/ItemSelectable.hpp>
#include <javax/swing/SwingConstants.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace util
    {
typedef ::SubArray< ::java::util::EventListener, ::java::lang::ObjectArray > EventListenerArray;
    } // util

    namespace awt
    {
        namespace event
        {
typedef ::SubArray< ::java::awt::event::ActionListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > ActionListenerArray;
typedef ::SubArray< ::java::awt::event::ItemListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > ItemListenerArray;
        } // event
    } // awt
} // java

namespace javax
{
    namespace swing
    {
        namespace event
        {
typedef ::SubArray< ::javax::swing::event::ChangeListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > ChangeListenerArray;
        } // event
    } // swing
} // javax

struct default_init_tag;

class javax::swing::AbstractButton
    : public JComponent
    , public virtual ::java::awt::ItemSelectable
    , public virtual SwingConstants
{

public:
    typedef JComponent super;

private:
    static ::java::lang::String* BORDER_PAINTED_CHANGED_PROPERTY_;
    static ::java::lang::String* CONTENT_AREA_FILLED_CHANGED_PROPERTY_;
    static ::java::lang::String* DISABLED_ICON_CHANGED_PROPERTY_;
    static ::java::lang::String* DISABLED_SELECTED_ICON_CHANGED_PROPERTY_;
    static ::java::lang::String* FOCUS_PAINTED_CHANGED_PROPERTY_;
    static ::java::lang::String* HORIZONTAL_ALIGNMENT_CHANGED_PROPERTY_;
    static ::java::lang::String* HORIZONTAL_TEXT_POSITION_CHANGED_PROPERTY_;
    static ::java::lang::String* ICON_CHANGED_PROPERTY_;
    static ::java::lang::String* MARGIN_CHANGED_PROPERTY_;
    static ::java::lang::String* MNEMONIC_CHANGED_PROPERTY_;
    static ::java::lang::String* MODEL_CHANGED_PROPERTY_;
    static ::java::lang::String* PRESSED_ICON_CHANGED_PROPERTY_;
    static ::java::lang::String* ROLLOVER_ENABLED_CHANGED_PROPERTY_;
    static ::java::lang::String* ROLLOVER_ICON_CHANGED_PROPERTY_;
    static ::java::lang::String* ROLLOVER_SELECTED_ICON_CHANGED_PROPERTY_;
    static ::java::lang::String* SELECTED_ICON_CHANGED_PROPERTY_;
    static ::java::lang::String* TEXT_CHANGED_PROPERTY_;
    static ::java::lang::String* VERTICAL_ALIGNMENT_CHANGED_PROPERTY_;
    static ::java::lang::String* VERTICAL_TEXT_POSITION_CHANGED_PROPERTY_;
    Action* action_ {  };

public: /* protected */
    ::java::awt::event::ActionListener* actionListener {  };

private:
    ::java::beans::PropertyChangeListener* actionPropertyChangeListener {  };
    bool borderPaintedSet {  };

public: /* protected */
    ::javax::swing::event::ChangeEvent* changeEvent {  };
    ::javax::swing::event::ChangeListener* changeListener {  };

private:
    bool contentAreaFilled {  };
    bool contentAreaFilledSet {  };

public: /* package */
    bool defaultCapable {  };

private:
    Icon* defaultIcon {  };
    ::java::awt::Insets* defaultMargin {  };
    Icon* disabledIcon {  };
    Icon* disabledSelectedIcon {  };
    AbstractButton_Handler* handler {  };
    bool hideActionText {  };
    int32_t horizontalAlignment {  };
    int32_t horizontalTextPosition {  };
    int32_t iconTextGap {  };
    bool iconTextGapSet {  };

public: /* protected */
    ::java::awt::event::ItemListener* itemListener {  };

private:
    ::java::awt::Insets* margin {  };
    int32_t mnemonic {  };
    int32_t mnemonicIndex {  };

public: /* protected */
    ButtonModel* model {  };

private:
    int64_t multiClickThreshhold {  };
    bool paintBorder_ {  };
    bool paintFocus {  };
    Icon* pressedIcon {  };
    bool rolloverEnabled {  };
    bool rolloverEnabledSet {  };
    Icon* rolloverIcon {  };
    Icon* rolloverSelectedIcon {  };
    Icon* selectedIcon {  };
    bool setLayout_ {  };
    ::java::lang::String* text {  };
    int32_t verticalAlignment {  };
    int32_t verticalTextPosition {  };

protected:
    void ctor();

public: /* protected */
    virtual void actionPropertyChanged(Action* arg0, ::java::lang::String* arg1);

public:
    virtual void addActionListener(::java::awt::event::ActionListener* arg0);
    virtual void addChangeListener(::javax::swing::event::ChangeListener* arg0);

public: /* protected */
    void addImpl(::java::awt::Component* arg0, ::java::lang::Object* arg1, int32_t arg2) override;

public:
    void addItemListener(::java::awt::event::ItemListener* arg0) override;

public: /* protected */
    virtual int32_t checkHorizontalKey(int32_t arg0, ::java::lang::String* arg1);
    virtual int32_t checkVerticalKey(int32_t arg0, ::java::lang::String* arg1);

public: /* package */
    void clientPropertyChanged(::java::lang::Object* arg0, ::java::lang::Object* arg1, ::java::lang::Object* arg2) override;

public: /* protected */
    virtual void configurePropertiesFromAction(Action* arg0);
    virtual ::java::awt::event::ActionListener* createActionListener();
    virtual ::java::beans::PropertyChangeListener* createActionPropertyChangeListener(Action* arg0);

public: /* package */
    virtual ::java::beans::PropertyChangeListener* createActionPropertyChangeListener0(Action* arg0);

public: /* protected */
    virtual ::javax::swing::event::ChangeListener* createChangeListener();
    virtual ::java::awt::event::ItemListener* createItemListener();

public:
    virtual void doClick();
    virtual void doClick(int32_t arg0);

public: /* protected */
    virtual void fireActionPerformed(::java::awt::event::ActionEvent* arg0);
    virtual void fireItemStateChanged(::java::awt::event::ItemEvent* arg0);
    virtual void fireStateChanged();

public:
    virtual Action* getAction();
    virtual ::java::lang::String* getActionCommand();
    virtual ::java::awt::event::ActionListenerArray* getActionListeners();
    virtual ::javax::swing::event::ChangeListenerArray* getChangeListeners();
    virtual Icon* getDisabledIcon();
    virtual Icon* getDisabledSelectedIcon();
    virtual int32_t getDisplayedMnemonicIndex();
    /*AbstractButton_Handler* getHandler(); (private) */
    virtual bool getHideActionText();
    virtual int32_t getHorizontalAlignment();
    virtual int32_t getHorizontalTextPosition();
    virtual Icon* getIcon();
    virtual int32_t getIconTextGap();
    virtual ::java::awt::event::ItemListenerArray* getItemListeners();
    virtual ::java::lang::String* getLabel();
    virtual ::java::awt::Insets* getMargin();
    virtual int32_t getMnemonic();
    virtual ButtonModel* getModel();
    virtual int64_t getMultiClickThreshhold();
    virtual Icon* getPressedIcon();
    virtual Icon* getRolloverIcon();
    virtual Icon* getRolloverSelectedIcon();
    virtual Icon* getSelectedIcon();
    ::java::lang::ObjectArray* getSelectedObjects() override;
    virtual ::java::lang::String* getText();
    virtual ::javax::swing::plaf::ButtonUI* getUI();
    virtual int32_t getVerticalAlignment();
    virtual int32_t getVerticalTextPosition();
    bool imageUpdate(::java::awt::Image* arg0, int32_t arg1, int32_t arg2, int32_t arg3, int32_t arg4, int32_t arg5) override;

public: /* protected */
    virtual void init_(::java::lang::String* arg0, Icon* arg1);

public:
    virtual bool isBorderPainted();
    virtual bool isContentAreaFilled();
    virtual bool isFocusPainted();
    /*bool isListener(::java::lang::Class* arg0, ::java::awt::event::ActionListener* arg1); (private) */
    virtual bool isRolloverEnabled();
    virtual bool isSelected();

public: /* package */
    virtual void largeIconChanged(Action* arg0);

public: /* protected */
    void paintBorder(::java::awt::Graphics* arg0) override;
    ::java::lang::String* paramString() override;

public:
    virtual void removeActionListener(::java::awt::event::ActionListener* arg0);
    virtual void removeChangeListener(::javax::swing::event::ChangeListener* arg0);
    void removeItemListener(::java::awt::event::ItemListener* arg0) override;
    void removeNotify() override;
    virtual void setAction(Action* arg0);
    virtual void setActionCommand(::java::lang::String* arg0);
    /*void setActionCommandFromAction(Action* arg0); (private) */
    virtual void setBorderPainted(bool arg0);
    virtual void setContentAreaFilled(bool arg0);
    virtual void setDisabledIcon(Icon* arg0);
    virtual void setDisabledSelectedIcon(Icon* arg0);
    virtual void setDisplayedMnemonicIndex(int32_t arg0);
    /*void setDisplayedMnemonicIndexFromAction(Action* arg0, bool arg1); (private) */
    void setEnabled(bool arg0) override;
    virtual void setFocusPainted(bool arg0);
    virtual void setHideActionText(bool arg0);
    virtual void setHorizontalAlignment(int32_t arg0);
    virtual void setHorizontalTextPosition(int32_t arg0);
    virtual void setIcon(Icon* arg0);

public: /* package */
    virtual void setIconFromAction(Action* arg0);

public:
    virtual void setIconTextGap(int32_t arg0);
    virtual void setLabel(::java::lang::String* arg0);
    void setLayout(::java::awt::LayoutManager* arg0) override;
    virtual void setMargin(::java::awt::Insets* arg0);
    virtual void setMnemonic(int32_t arg0);
    virtual void setMnemonic(char16_t arg0);
    /*void setMnemonicFromAction(Action* arg0); (private) */
    virtual void setModel(ButtonModel* arg0);
    virtual void setMultiClickThreshhold(int64_t arg0);
    virtual void setPressedIcon(Icon* arg0);
    virtual void setRolloverEnabled(bool arg0);
    virtual void setRolloverIcon(Icon* arg0);
    virtual void setRolloverSelectedIcon(Icon* arg0);
    virtual void setSelected(bool arg0);
    /*void setSelectedFromAction(Action* arg0); (private) */
    virtual void setSelectedIcon(Icon* arg0);
    virtual void setText(::java::lang::String* arg0);
    /*void setTextFromAction(Action* arg0, bool arg1); (private) */
    virtual void setUI(::javax::swing::plaf::ButtonUI* arg0);

public: /* package */
    void setUIProperty(::java::lang::String* arg0, ::java::lang::Object* arg1) override;

public:
    virtual void setVerticalAlignment(int32_t arg0);
    virtual void setVerticalTextPosition(int32_t arg0);

public: /* package */
    virtual bool shouldUpdateSelectedStateFromAction();
    virtual void smallIconChanged(Action* arg0);
    /*void updateDisplayedMnemonicIndex(::java::lang::String* arg0, int32_t arg1); (private) */
    /*void updateMnemonicProperties(); (private) */

public:
    void updateUI() override;

    // Generated
    AbstractButton();
protected:
    AbstractButton(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

public: /* protected */
    virtual void setUI(::javax::swing::plaf::ComponentUI* arg0);

public:
    static ::java::lang::String*& BORDER_PAINTED_CHANGED_PROPERTY();
    static ::java::lang::String*& CONTENT_AREA_FILLED_CHANGED_PROPERTY();
    static ::java::lang::String*& DISABLED_ICON_CHANGED_PROPERTY();
    static ::java::lang::String*& DISABLED_SELECTED_ICON_CHANGED_PROPERTY();
    static ::java::lang::String*& FOCUS_PAINTED_CHANGED_PROPERTY();
    static ::java::lang::String*& HORIZONTAL_ALIGNMENT_CHANGED_PROPERTY();
    static ::java::lang::String*& HORIZONTAL_TEXT_POSITION_CHANGED_PROPERTY();
    static ::java::lang::String*& ICON_CHANGED_PROPERTY();
    static ::java::lang::String*& MARGIN_CHANGED_PROPERTY();
    static ::java::lang::String*& MNEMONIC_CHANGED_PROPERTY();
    static ::java::lang::String*& MODEL_CHANGED_PROPERTY();
    static ::java::lang::String*& PRESSED_ICON_CHANGED_PROPERTY();
    static ::java::lang::String*& ROLLOVER_ENABLED_CHANGED_PROPERTY();
    static ::java::lang::String*& ROLLOVER_ICON_CHANGED_PROPERTY();
    static ::java::lang::String*& ROLLOVER_SELECTED_ICON_CHANGED_PROPERTY();
    static ::java::lang::String*& SELECTED_ICON_CHANGED_PROPERTY();
    static ::java::lang::String*& TEXT_CHANGED_PROPERTY();
    static ::java::lang::String*& VERTICAL_ALIGNMENT_CHANGED_PROPERTY();
    static ::java::lang::String*& VERTICAL_TEXT_POSITION_CHANGED_PROPERTY();

private:
    virtual ::java::lang::Class* getClass0();
};
