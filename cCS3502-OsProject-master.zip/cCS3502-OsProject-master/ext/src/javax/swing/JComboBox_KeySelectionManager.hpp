// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct javax::swing::JComboBox_KeySelectionManager
    : public virtual ::java::lang::Object
{

    virtual int32_t selectionForKey(char16_t aKey, ComboBoxModel* aModel) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
