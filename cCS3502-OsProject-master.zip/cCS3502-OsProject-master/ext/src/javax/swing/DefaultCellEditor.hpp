// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/event/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/AbstractCellEditor.hpp>
#include <javax/swing/table/TableCellEditor.hpp>
#include <javax/swing/tree/TreeCellEditor.hpp>

struct default_init_tag;

class javax::swing::DefaultCellEditor
    : public AbstractCellEditor
    , public virtual ::javax::swing::table::TableCellEditor
    , public virtual ::javax::swing::tree::TreeCellEditor
{

public:
    typedef AbstractCellEditor super;

public: /* protected */
    int32_t clickCountToStart {  };
    DefaultCellEditor_EditorDelegate* delegate {  };
    JComponent* editorComponent {  };

protected:
    void ctor(JTextField* arg0);
    void ctor(JCheckBox* arg0);
    void ctor(JComboBox* arg0);

public:
    void cancelCellEditing() override;
    ::java::lang::Object* getCellEditorValue() override;
    virtual int32_t getClickCountToStart();
    virtual ::java::awt::Component* getComponent();
    ::java::awt::Component* getTableCellEditorComponent(JTable* arg0, ::java::lang::Object* arg1, bool arg2, int32_t arg3, int32_t arg4) override;
    ::java::awt::Component* getTreeCellEditorComponent(JTree* arg0, ::java::lang::Object* arg1, bool arg2, bool arg3, bool arg4, int32_t arg5) override;
    bool isCellEditable(::java::util::EventObject* arg0) override;
    virtual void setClickCountToStart(int32_t arg0);
    bool shouldSelectCell(::java::util::EventObject* arg0) override;
    bool stopCellEditing() override;

    // Generated
    DefaultCellEditor(JTextField* arg0);
    DefaultCellEditor(JCheckBox* arg0);
    DefaultCellEditor(JComboBox* arg0);
protected:
    DefaultCellEditor(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    virtual void addCellEditorListener(::javax::swing::event::CellEditorListener* arg0);
    virtual void removeCellEditorListener(::javax::swing::event::CellEditorListener* arg0);

private:
    virtual ::java::lang::Class* getClass0();
};
