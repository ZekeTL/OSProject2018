// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/io/ObjectInputValidation.hpp>

struct default_init_tag;

class javax::swing::JComponent_ReadObjectCallback
    : public virtual ::java::lang::Object
    , public virtual ::java::io::ObjectInputValidation
{

public:
    typedef ::java::lang::Object super;

private:
    ::java::io::ObjectInputStream* inputStream {  };
    ::java::util::Vector* roots {  };

public: /* package */
    JComponent* this$0 {  };

protected:
    void ctor(::java::io::ObjectInputStream* arg0);
    /*void registerComponent(JComponent* arg0); (private) */

public:
    void validateObject() override;

    // Generated

public: /* package */
    JComponent_ReadObjectCallback(JComponent *JComponent_this, ::java::io::ObjectInputStream* arg0);
protected:
    JComponent_ReadObjectCallback(JComponent *JComponent_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JComponent *JComponent_this;

private:
    virtual ::java::lang::Class* getClass0();
};
