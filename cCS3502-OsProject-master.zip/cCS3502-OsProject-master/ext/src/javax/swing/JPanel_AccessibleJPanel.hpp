// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/JComponent_AccessibleJComponent.hpp>

struct default_init_tag;

class javax::swing::JPanel_AccessibleJPanel
    : public JComponent_AccessibleJComponent
{

public:
    typedef JComponent_AccessibleJComponent super;

public: /* package */
    JPanel* this$0 {  };

protected:
    void ctor();

public:
    ::javax::accessibility::AccessibleRole* getAccessibleRole() override;

    // Generated

public: /* protected */
    JPanel_AccessibleJPanel(JPanel *JPanel_this);
protected:
    JPanel_AccessibleJPanel(JPanel *JPanel_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    JPanel *JPanel_this;

private:
    virtual ::java::lang::Class* getClass0();
};
