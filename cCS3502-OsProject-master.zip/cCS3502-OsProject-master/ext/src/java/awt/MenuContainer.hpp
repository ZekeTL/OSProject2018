// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct java::awt::MenuContainer
    : public virtual ::java::lang::Object
{

    virtual Font* getFont() = 0;
    virtual bool postEvent(Event* evt) = 0;
    virtual void remove(MenuComponent* comp) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
