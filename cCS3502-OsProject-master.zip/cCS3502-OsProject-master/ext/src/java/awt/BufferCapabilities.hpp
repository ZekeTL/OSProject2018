// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/lang/Cloneable.hpp>

struct default_init_tag;

class java::awt::BufferCapabilities
    : public virtual ::java::lang::Object
    , public virtual ::java::lang::Cloneable
{

public:
    typedef ::java::lang::Object super;

private:
    ImageCapabilities* backCaps {  };
    BufferCapabilities_FlipContents* flipContents {  };
    ImageCapabilities* frontCaps {  };

protected:
    void ctor(ImageCapabilities* arg0, ImageCapabilities* arg1, BufferCapabilities_FlipContents* arg2);

public:
    ::java::lang::Object* clone() override;
    virtual ImageCapabilities* getBackBufferCapabilities();
    virtual BufferCapabilities_FlipContents* getFlipContents();
    virtual ImageCapabilities* getFrontBufferCapabilities();
    virtual bool isFullScreenRequired();
    virtual bool isMultiBufferAvailable();
    virtual bool isPageFlipping();

    // Generated
    BufferCapabilities(ImageCapabilities* arg0, ImageCapabilities* arg1, BufferCapabilities_FlipContents* arg2);
protected:
    BufferCapabilities(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
