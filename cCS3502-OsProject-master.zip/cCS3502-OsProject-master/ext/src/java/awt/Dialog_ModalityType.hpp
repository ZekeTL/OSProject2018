// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Enum.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace lang
    {
typedef ::SubArray< ::java::lang::Comparable, ObjectArray > ComparableArray;
    } // lang

    namespace io
    {
typedef ::SubArray< ::java::io::Serializable, ::java::lang::ObjectArray > SerializableArray;
    } // io

    namespace lang
    {
typedef ::SubArray< ::java::lang::Enum, ObjectArray, ComparableArray, ::java::io::SerializableArray > EnumArray;
    } // lang

    namespace awt
    {
typedef ::SubArray< ::java::awt::Dialog_ModalityType, ::java::lang::EnumArray > Dialog_ModalityTypeArray;
    } // awt
} // java

struct default_init_tag;

class java::awt::Dialog_ModalityType final
    : public ::java::lang::Enum
{

public:
    typedef ::java::lang::Enum super;

private:
    static Dialog_ModalityTypeArray* $VALUES_;

public:
    static Dialog_ModalityType* APPLICATION_MODAL;
    static Dialog_ModalityType* DOCUMENT_MODAL;
    static Dialog_ModalityType* MODELESS;
    static Dialog_ModalityType* TOOLKIT_MODAL;

    /*void ctor(::java::lang::String* name, int ordinal); (private) */
    static Dialog_ModalityType* valueOf(::java::lang::String* arg0);
    static Dialog_ModalityTypeArray* values();

    // Generated
    Dialog_ModalityType(::java::lang::String* name, int ordinal);
protected:
    Dialog_ModalityType(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    static ::java::lang::Enum* valueOf(::java::lang::Class* enumType, ::java::lang::String* name);

private:
    static Dialog_ModalityTypeArray*& $VALUES();
    virtual ::java::lang::Class* getClass0();
};
