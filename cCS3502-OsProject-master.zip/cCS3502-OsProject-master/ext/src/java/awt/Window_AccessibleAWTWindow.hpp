// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/Container_AccessibleAWTContainer.hpp>

struct default_init_tag;

class java::awt::Window_AccessibleAWTWindow
    : public Container_AccessibleAWTContainer
{

public:
    typedef Container_AccessibleAWTContainer super;

private:
    static constexpr int64_t serialVersionUID { int64_t(4215068635060671780LL) };

public: /* package */
    Window* this$0 {  };

protected:
    void ctor();

public:
    ::javax::accessibility::AccessibleRole* getAccessibleRole() override;
    ::javax::accessibility::AccessibleStateSet* getAccessibleStateSet() override;

    // Generated

public: /* protected */
    Window_AccessibleAWTWindow(Window *Window_this);
protected:
    Window_AccessibleAWTWindow(Window *Window_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    Window *Window_this;

private:
    virtual ::java::lang::Class* getClass0();
};
