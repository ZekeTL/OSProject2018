// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/Window_AccessibleAWTWindow.hpp>

struct default_init_tag;

class java::awt::Dialog_AccessibleAWTDialog
    : public Window_AccessibleAWTWindow
{

public:
    typedef Window_AccessibleAWTWindow super;

private:
    static constexpr int64_t serialVersionUID { int64_t(4837230331833941201LL) };

public: /* package */
    Dialog* this$0 {  };

protected:
    void ctor();

public:
    ::javax::accessibility::AccessibleRole* getAccessibleRole() override;
    ::javax::accessibility::AccessibleStateSet* getAccessibleStateSet() override;

    // Generated

public: /* protected */
    Dialog_AccessibleAWTDialog(Dialog *Dialog_this);
protected:
    Dialog_AccessibleAWTDialog(Dialog *Dialog_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    Dialog *Dialog_this;

private:
    virtual ::java::lang::Class* getClass0();
};
