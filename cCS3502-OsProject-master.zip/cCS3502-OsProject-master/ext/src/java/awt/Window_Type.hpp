// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Enum.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace lang
    {
typedef ::SubArray< ::java::lang::Comparable, ObjectArray > ComparableArray;
    } // lang

    namespace io
    {
typedef ::SubArray< ::java::io::Serializable, ::java::lang::ObjectArray > SerializableArray;
    } // io

    namespace lang
    {
typedef ::SubArray< ::java::lang::Enum, ObjectArray, ComparableArray, ::java::io::SerializableArray > EnumArray;
    } // lang

    namespace awt
    {
typedef ::SubArray< ::java::awt::Window_Type, ::java::lang::EnumArray > Window_TypeArray;
    } // awt
} // java

struct default_init_tag;

class java::awt::Window_Type final
    : public ::java::lang::Enum
{

public:
    typedef ::java::lang::Enum super;

private:
    static Window_TypeArray* $VALUES_;

public:
    static Window_Type* NORMAL;
    static Window_Type* POPUP;
    static Window_Type* UTILITY;

    /*void ctor(::java::lang::String* name, int ordinal); (private) */
    static Window_Type* valueOf(::java::lang::String* arg0);
    static Window_TypeArray* values();

    // Generated
    Window_Type(::java::lang::String* name, int ordinal);
protected:
    Window_Type(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    static ::java::lang::Enum* valueOf(::java::lang::Class* enumType, ::java::lang::String* name);

private:
    static Window_TypeArray*& $VALUES();
    virtual ::java::lang::Class* getClass0();
};
