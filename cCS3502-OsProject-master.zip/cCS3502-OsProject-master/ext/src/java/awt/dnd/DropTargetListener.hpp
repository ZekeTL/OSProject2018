// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/awt/dnd/fwd-CS3502-OsProject-master.hpp>
#include <java/util/EventListener.hpp>

struct java::awt::dnd::DropTargetListener
    : public virtual ::java::util::EventListener
{

    virtual void dragEnter(DropTargetDragEvent* arg0) = 0;
    virtual void dragExit(DropTargetEvent* arg0) = 0;
    virtual void dragOver(DropTargetDragEvent* arg0) = 0;
    virtual void drop(DropTargetDropEvent* arg0) = 0;
    virtual void dropActionChanged(DropTargetDragEvent* arg0) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
