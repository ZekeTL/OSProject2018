// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/dnd/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/io/Serializable.hpp>

struct default_init_tag;

class java::awt::dnd::DragGestureRecognizer
    : public virtual ::java::lang::Object
    , public virtual ::java::io::Serializable
{

public:
    typedef ::java::lang::Object super;

public: /* protected */
    ::java::awt::Component* component {  };
    DragGestureListener* dragGestureListener {  };
    DragSource* dragSource {  };
    ::java::util::ArrayList* events {  };

private:
    static constexpr int64_t serialVersionUID { int64_t(8996673345831063337LL) };

public: /* protected */
    int32_t sourceActions {  };

protected:
    void ctor(DragSource* arg0);
    void ctor(DragSource* arg0, ::java::awt::Component* arg1);
    void ctor(DragSource* arg0, ::java::awt::Component* arg1, int32_t arg2);
    void ctor(DragSource* arg0, ::java::awt::Component* arg1, int32_t arg2, DragGestureListener* arg3);

public:
    virtual void addDragGestureListener(DragGestureListener* arg0);

public: /* protected */
    virtual void appendEvent(::java::awt::event::InputEvent* arg0);
    virtual void fireDragGestureRecognized(int32_t arg0, ::java::awt::Point* arg1);

public:
    virtual ::java::awt::Component* getComponent();
    virtual DragSource* getDragSource();
    virtual int32_t getSourceActions();
    virtual ::java::awt::event::InputEvent* getTriggerEvent();
    /*void readObject(::java::io::ObjectInputStream* arg0); (private) */

public: /* protected */
    virtual void registerListeners() = 0;

public:
    virtual void removeDragGestureListener(DragGestureListener* arg0);
    virtual void resetRecognizer();
    virtual void setComponent(::java::awt::Component* arg0);
    virtual void setSourceActions(int32_t arg0);

public: /* protected */
    virtual void unregisterListeners() = 0;
    /*void writeObject(::java::io::ObjectOutputStream* arg0); (private) */

    // Generated
    DragGestureRecognizer(DragSource* arg0);
    DragGestureRecognizer(DragSource* arg0, ::java::awt::Component* arg1);
    DragGestureRecognizer(DragSource* arg0, ::java::awt::Component* arg1, int32_t arg2);
    DragGestureRecognizer(DragSource* arg0, ::java::awt::Component* arg1, int32_t arg2, DragGestureListener* arg3);
protected:
    DragGestureRecognizer(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
