// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/datatransfer/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/dnd/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/peer/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/awt/dnd/DropTargetListener.hpp>
#include <java/io/Serializable.hpp>

struct default_init_tag;

class java::awt::dnd::DropTarget
    : public virtual ::java::lang::Object
    , public virtual DropTargetListener
    , public virtual ::java::io::Serializable
{

public:
    typedef ::java::lang::Object super;

public: /* package */
    int32_t actions {  };
    bool active {  };

private:
    DropTarget_DropTargetAutoScroller* autoScroller {  };
    ::java::awt::Component* component {  };
    ::java::awt::peer::ComponentPeer* componentPeer {  };
    DropTargetContext* dropTargetContext {  };
    DropTargetListener* dtListener {  };
    ::java::awt::datatransfer::FlavorMap* flavorMap {  };
    bool isDraggingInside {  };
    ::java::awt::peer::ComponentPeer* nativePeer {  };
    static constexpr int64_t serialVersionUID { int64_t(-6283860791671019047LL) };

protected:
    void ctor();
    void ctor(::java::awt::Component* arg0, DropTargetListener* arg1);
    void ctor(::java::awt::Component* arg0, int32_t arg1, DropTargetListener* arg2);
    void ctor(::java::awt::Component* arg0, int32_t arg1, DropTargetListener* arg2, bool arg3);
    void ctor(::java::awt::Component* arg0, int32_t arg1, DropTargetListener* arg2, bool arg3, ::java::awt::datatransfer::FlavorMap* arg4);

public:
    virtual void addDropTargetListener(DropTargetListener* arg0);
    virtual void addNotify(::java::awt::peer::ComponentPeer* arg0);

public: /* protected */
    virtual void clearAutoscroll();
    virtual DropTarget_DropTargetAutoScroller* createDropTargetAutoScroller(::java::awt::Component* arg0, ::java::awt::Point* arg1);
    virtual DropTargetContext* createDropTargetContext();

public: /* package */
    virtual void doSetDefaultActions(int32_t arg0);

public:
    void dragEnter(DropTargetDragEvent* arg0) override;
    void dragExit(DropTargetEvent* arg0) override;
    void dragOver(DropTargetDragEvent* arg0) override;
    void drop(DropTargetDropEvent* arg0) override;
    void dropActionChanged(DropTargetDragEvent* arg0) override;
    virtual ::java::awt::Component* getComponent();
    virtual int32_t getDefaultActions();
    virtual DropTargetContext* getDropTargetContext();
    virtual ::java::awt::datatransfer::FlavorMap* getFlavorMap();

public: /* protected */
    virtual void initializeAutoscrolling(::java::awt::Point* arg0);

public:
    virtual bool isActive();
    /*void readObject(::java::io::ObjectInputStream* arg0); (private) */
    virtual void removeDropTargetListener(DropTargetListener* arg0);
    virtual void removeNotify(::java::awt::peer::ComponentPeer* arg0);
    virtual void setActive(bool arg0);
    virtual void setComponent(::java::awt::Component* arg0);
    virtual void setDefaultActions(int32_t arg0);
    virtual void setFlavorMap(::java::awt::datatransfer::FlavorMap* arg0);

public: /* protected */
    virtual void updateAutoscroll(::java::awt::Point* arg0);
    /*void writeObject(::java::io::ObjectOutputStream* arg0); (private) */

    // Generated

public:
    DropTarget();
    DropTarget(::java::awt::Component* arg0, DropTargetListener* arg1);
    DropTarget(::java::awt::Component* arg0, int32_t arg1, DropTargetListener* arg2);
    DropTarget(::java::awt::Component* arg0, int32_t arg1, DropTargetListener* arg2, bool arg3);
    DropTarget(::java::awt::Component* arg0, int32_t arg1, DropTargetListener* arg2, bool arg3, ::java::awt::datatransfer::FlavorMap* arg4);
protected:
    DropTarget(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
