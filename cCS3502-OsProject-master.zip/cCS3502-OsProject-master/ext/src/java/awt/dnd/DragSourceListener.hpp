// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/awt/dnd/fwd-CS3502-OsProject-master.hpp>
#include <java/util/EventListener.hpp>

struct java::awt::dnd::DragSourceListener
    : public virtual ::java::util::EventListener
{

    virtual void dragDropEnd(DragSourceDropEvent* arg0) = 0;
    virtual void dragEnter(DragSourceDragEvent* arg0) = 0;
    virtual void dragExit(DragSourceEvent* arg0) = 0;
    virtual void dragOver(DragSourceDragEvent* arg0) = 0;
    virtual void dropActionChanged(DragSourceDragEvent* arg0) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
