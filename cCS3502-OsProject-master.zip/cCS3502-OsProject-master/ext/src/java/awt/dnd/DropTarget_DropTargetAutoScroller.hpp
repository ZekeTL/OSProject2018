// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/dnd/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <javax/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/awt/event/ActionListener.hpp>

struct default_init_tag;

class java::awt::dnd::DropTarget_DropTargetAutoScroller
    : public virtual ::java::lang::Object
    , public virtual ::java::awt::event::ActionListener
{

public:
    typedef ::java::lang::Object super;

private:
    Autoscroll* autoScroll {  };
    ::java::awt::Component* component {  };
    int32_t hysteresis {  };
    ::java::awt::Rectangle* inner {  };
    ::java::awt::Point* locn {  };
    ::java::awt::Rectangle* outer {  };
    ::java::awt::Point* prev {  };
    ::javax::swing::Timer* timer {  };

protected:
    void ctor(::java::awt::Component* arg0, ::java::awt::Point* arg1);

public:
    void actionPerformed(::java::awt::event::ActionEvent* arg0) override;

public: /* protected */
    virtual void stop();
    virtual void updateLocation(::java::awt::Point* arg0);
    /*void updateRegion(); (private) */

    // Generated
    DropTarget_DropTargetAutoScroller(::java::awt::Component* arg0, ::java::awt::Point* arg1);
protected:
    DropTarget_DropTargetAutoScroller(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
