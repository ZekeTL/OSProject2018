// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <atomic>
#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <java/util/concurrent/atomic/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <sun/awt/util/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/Window.hpp>

struct default_init_tag;

class java::awt::Dialog
    : public Window
{

public:
    typedef Window super;

private:
    static Dialog_ModalityType* DEFAULT_MODALITY_TYPE_;
    static ::java::lang::String* base_;

public: /* package */
    ::sun::awt::util::IdentityArrayList* blockedWindows {  };

private:
    bool initialized {  };

public: /* package */
    std::atomic< bool > isInDispose {  };
    std::atomic< bool > isInHide {  };
    bool modal {  };

private:
    static ::sun::awt::util::IdentityArrayList* modalDialogs_;
    ModalEventFilter* modalFilter {  };

public: /* package */
    Dialog_ModalityType* modalityType {  };

private:
    static int32_t nameCounter_;

public: /* package */
    bool resizable {  };

private:
    std::atomic< SecondaryLoop* > secondaryLoop {  };
    static constexpr int64_t serialVersionUID { int64_t(5920926903803293709LL) };

public: /* package */
    ::java::lang::String* title {  };
    bool undecorated {  };

protected:
    void ctor(Frame* arg0);
    void ctor(Dialog* arg0);
    void ctor(Window* arg0);
    void ctor(Frame* arg0, bool arg1);
    void ctor(Frame* arg0, ::java::lang::String* arg1);
    void ctor(Dialog* arg0, ::java::lang::String* arg1);
    void ctor(Window* arg0, ::java::lang::String* arg1);
    void ctor(Window* arg0, Dialog_ModalityType* arg1);
    void ctor(Frame* arg0, ::java::lang::String* arg1, bool arg2);
    void ctor(Dialog* arg0, ::java::lang::String* arg1, bool arg2);
    void ctor(Window* arg0, ::java::lang::String* arg1, Dialog_ModalityType* arg2);
    void ctor(Frame* arg0, ::java::lang::String* arg1, bool arg2, GraphicsConfiguration* arg3);
    void ctor(Dialog* arg0, ::java::lang::String* arg1, bool arg2, GraphicsConfiguration* arg3);
    void ctor(Window* arg0, ::java::lang::String* arg1, Dialog_ModalityType* arg2, GraphicsConfiguration* arg3);

public:
    void addNotify() override;

public: /* package */
    virtual void blockWindow(Window* arg0);
    virtual void blockWindows(::java::util::List* arg0);
    /*void checkModalityPermission(Dialog_ModalityType* arg0); (private) */
    static void checkShouldBeBlocked(Window* arg0);
    /*bool conditionalShow(Component* arg0, ::java::util::concurrent::atomic::AtomicLong* arg1); (private) */
    ::java::lang::String* constructComponentName() override;
    void doDispose() override;

public:
    ::javax::accessibility::AccessibleContext* getAccessibleContext() override;
    virtual Dialog_ModalityType* getModalityType();
    virtual ::java::lang::String* getTitle();
    void hide() override;
    /*void hideAndDisposeHandler(); (private) */
    /*void hideAndDisposePreHandler(); (private) */
    /*static void initIDs(); (private) */

public: /* package */
    virtual void interruptBlocking();

public:
    virtual bool isModal();

public: /* package */
    bool isModal_NoClientCode();

public:
    virtual bool isResizable();
    virtual bool isUndecorated();

public: /* package */
    virtual void modalHide();
    virtual void modalShow();
    void modalityPopped();
    void modalityPushed();

public: /* protected */
    ::java::lang::String* paramString() override;
    /*void readObject(::java::io::ObjectInputStream* arg0); (private) */

public:
    void setBackground(Color* arg0) override;
    virtual void setModal(bool arg0);
    virtual void setModalityType(Dialog_ModalityType* arg0);
    void setOpacity(float arg0) override;
    virtual void setResizable(bool arg0);
    void setShape(Shape* arg0) override;
    virtual void setTitle(::java::lang::String* arg0);
    virtual void setUndecorated(bool arg0);
    void setVisible(bool arg0) override;

public: /* package */
    virtual bool shouldBlock(Window* arg0);

public:
    void show() override;
    void toBack() override;

public: /* package */
    virtual void unblockWindow(Window* arg0);

    // Generated

public:
    Dialog(Frame* arg0);
    Dialog(Dialog* arg0);
    Dialog(Window* arg0);
    Dialog(Frame* arg0, bool arg1);
    Dialog(Frame* arg0, ::java::lang::String* arg1);
    Dialog(Dialog* arg0, ::java::lang::String* arg1);
    Dialog(Window* arg0, ::java::lang::String* arg1);
    Dialog(Window* arg0, Dialog_ModalityType* arg1);
    Dialog(Frame* arg0, ::java::lang::String* arg1, bool arg2);
    Dialog(Dialog* arg0, ::java::lang::String* arg1, bool arg2);
    Dialog(Window* arg0, ::java::lang::String* arg1, Dialog_ModalityType* arg2);
    Dialog(Frame* arg0, ::java::lang::String* arg1, bool arg2, GraphicsConfiguration* arg3);
    Dialog(Dialog* arg0, ::java::lang::String* arg1, bool arg2, GraphicsConfiguration* arg3);
    Dialog(Window* arg0, ::java::lang::String* arg1, Dialog_ModalityType* arg2, GraphicsConfiguration* arg3);
protected:
    Dialog(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    virtual void show(bool arg0);
    static Dialog_ModalityType*& DEFAULT_MODALITY_TYPE();

private:
    static ::java::lang::String*& base();

public: /* package */
    static ::sun::awt::util::IdentityArrayList*& modalDialogs();

private:
    static int32_t& nameCounter();
    virtual ::java::lang::Class* getClass0();
};
