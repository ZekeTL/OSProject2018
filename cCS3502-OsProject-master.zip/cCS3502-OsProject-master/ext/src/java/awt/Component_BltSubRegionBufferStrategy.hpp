// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/Component_BltBufferStrategy.hpp>
#include <sun/awt/SubRegionShowable.hpp>

struct default_init_tag;

class java::awt::Component_BltSubRegionBufferStrategy
    : public Component_BltBufferStrategy
    , public virtual ::sun::awt::SubRegionShowable
{

public:
    typedef Component_BltBufferStrategy super;

public: /* package */
    Component* this$0 {  };

protected:
    void ctor(int32_t arg0, BufferCapabilities* arg1);

public:
    void show(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3) override;
    bool showIfNotLost(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3) override;

    // Generated

public: /* protected */
    Component_BltSubRegionBufferStrategy(Component *Component_this, int32_t arg0, BufferCapabilities* arg1);
protected:
    Component_BltSubRegionBufferStrategy(Component *Component_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    void show();

private:
    virtual ::java::lang::Class* getClass0();
};
