// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/geom/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/geom/Point2D.hpp>
#include <java/io/Serializable.hpp>

struct default_init_tag;

class java::awt::Point
    : public ::java::awt::geom::Point2D
    , public virtual ::java::io::Serializable
{

public:
    typedef ::java::awt::geom::Point2D super;

private:
    static constexpr int64_t serialVersionUID { int64_t(-5276940640259749850LL) };

public:
    int32_t x {  };
    int32_t y {  };

protected:
    void ctor();
    void ctor(Point* arg0);
    void ctor(int32_t arg0, int32_t arg1);

public:
    bool equals(::java::lang::Object* arg0) override;
    virtual Point* getLocation();
    double getX() override;
    double getY() override;
    virtual void move(int32_t arg0, int32_t arg1);
    virtual void setLocation(Point* arg0);
    virtual void setLocation(int32_t arg0, int32_t arg1);
    void setLocation(double arg0, double arg1) override;
    ::java::lang::String* toString() override;
    virtual void translate(int32_t arg0, int32_t arg1);

    // Generated
    Point();
    Point(Point* arg0);
    Point(int32_t arg0, int32_t arg1);
protected:
    Point(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    virtual void setLocation(::java::awt::geom::Point2D* arg0);

private:
    virtual ::java::lang::Class* getClass0();
};
