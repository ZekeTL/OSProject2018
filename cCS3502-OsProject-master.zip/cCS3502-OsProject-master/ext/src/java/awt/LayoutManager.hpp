// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct java::awt::LayoutManager
    : public virtual ::java::lang::Object
{

    virtual void addLayoutComponent(::java::lang::String* arg0, Component* arg1) = 0;
    virtual void layoutContainer(Container* arg0) = 0;
    virtual Dimension* minimumLayoutSize(Container* arg0) = 0;
    virtual Dimension* preferredLayoutSize(Container* arg0) = 0;
    virtual void removeLayoutComponent(Component* arg0) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
