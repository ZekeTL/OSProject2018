// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/geom/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/image/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/Transparency.hpp>

struct java::awt::Paint
    : public virtual Transparency
{

    virtual PaintContext* createContext(::java::awt::image::ColorModel* arg0, Rectangle* arg1, ::java::awt::geom::Rectangle2D* arg2, ::java::awt::geom::AffineTransform* arg3, RenderingHints* arg4) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
