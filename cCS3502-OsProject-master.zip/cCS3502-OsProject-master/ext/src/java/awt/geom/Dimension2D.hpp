// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/geom/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/lang/Cloneable.hpp>

struct default_init_tag;

class java::awt::geom::Dimension2D
    : public virtual ::java::lang::Object
    , public virtual ::java::lang::Cloneable
{

public:
    typedef ::java::lang::Object super;

protected:
    void ctor();

public:
    ::java::lang::Object* clone() override;
    virtual double getHeight() = 0;
    virtual double getWidth() = 0;
    virtual void setSize(Dimension2D* arg0);
    virtual void setSize(double arg0, double arg1) = 0;

    // Generated

public: /* protected */
    Dimension2D();
protected:
    Dimension2D(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
