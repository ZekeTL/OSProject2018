// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/geom/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/geom/Rectangle2D.hpp>
#include <java/io/Serializable.hpp>

struct default_init_tag;

class java::awt::geom::Rectangle2D_Float
    : public Rectangle2D
    , public virtual ::java::io::Serializable
{

public:
    typedef Rectangle2D super;
    float height {  };

private:
    static constexpr int64_t serialVersionUID { int64_t(3798716824173675777LL) };

public:
    float width {  };
    float x {  };
    float y {  };

protected:
    void ctor();
    void ctor(float arg0, float arg1, float arg2, float arg3);

public:
    Rectangle2D* createIntersection(Rectangle2D* arg0) override;
    Rectangle2D* createUnion(Rectangle2D* arg0) override;
    Rectangle2D* getBounds2D() override;
    double getHeight() override;
    double getWidth() override;
    double getX() override;
    double getY() override;
    bool isEmpty() override;
    int32_t outcode(double arg0, double arg1) override;
    void setRect(Rectangle2D* arg0) override;
    virtual void setRect(float arg0, float arg1, float arg2, float arg3);
    void setRect(double arg0, double arg1, double arg2, double arg3) override;
    ::java::lang::String* toString() override;

    // Generated
    Rectangle2D_Float();
    Rectangle2D_Float(float arg0, float arg1, float arg2, float arg3);
protected:
    Rectangle2D_Float(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    virtual int32_t outcode(Point2D* p);

private:
    virtual ::java::lang::Class* getClass0();
};
