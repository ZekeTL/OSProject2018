// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/geom/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/geom/Point2D.hpp>
#include <java/io/Serializable.hpp>

struct default_init_tag;

class java::awt::geom::Point2D_Double
    : public Point2D
    , public virtual ::java::io::Serializable
{

public:
    typedef Point2D super;

private:
    static constexpr int64_t serialVersionUID { int64_t(6150783262733311327LL) };

public:
    double x {  };
    double y {  };

protected:
    void ctor();
    void ctor(double arg0, double arg1);

public:
    double getX() override;
    double getY() override;
    void setLocation(double arg0, double arg1) override;
    ::java::lang::String* toString() override;

    // Generated
    Point2D_Double();
    Point2D_Double(double arg0, double arg1);
protected:
    Point2D_Double(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    virtual void setLocation(Point2D* arg0);

private:
    virtual ::java::lang::Class* getClass0();
};
