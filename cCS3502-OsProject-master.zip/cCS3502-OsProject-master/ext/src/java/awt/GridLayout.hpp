// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/awt/LayoutManager.hpp>
#include <java/io/Serializable.hpp>

struct default_init_tag;

class java::awt::GridLayout
    : public virtual ::java::lang::Object
    , public virtual LayoutManager
    , public virtual ::java::io::Serializable
{

public:
    typedef ::java::lang::Object super;

public: /* package */
    int32_t cols {  };
    int32_t hgap {  };
    int32_t rows {  };

private:
    static constexpr int64_t serialVersionUID { int64_t(-7411804673224730901LL) };

public: /* package */
    int32_t vgap {  };

protected:
    void ctor();
    void ctor(int32_t arg0, int32_t arg1);
    void ctor(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3);

public:
    void addLayoutComponent(::java::lang::String* arg0, Component* arg1) override;
    virtual int32_t getColumns();
    virtual int32_t getHgap();
    virtual int32_t getRows();
    virtual int32_t getVgap();
    void layoutContainer(Container* arg0) override;
    Dimension* minimumLayoutSize(Container* arg0) override;
    Dimension* preferredLayoutSize(Container* arg0) override;
    void removeLayoutComponent(Component* arg0) override;
    virtual void setColumns(int32_t arg0);
    virtual void setHgap(int32_t arg0);
    virtual void setRows(int32_t arg0);
    virtual void setVgap(int32_t arg0);
    ::java::lang::String* toString() override;

    // Generated
    GridLayout();
    GridLayout(int32_t arg0, int32_t arg1);
    GridLayout(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3);
protected:
    GridLayout(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
