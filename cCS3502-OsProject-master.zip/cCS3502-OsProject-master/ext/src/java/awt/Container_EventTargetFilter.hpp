// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct java::awt::Container_EventTargetFilter
    : public virtual ::java::lang::Object
{

    virtual bool accept(Component* arg0) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
