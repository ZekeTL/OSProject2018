// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/awt/LayoutManager.hpp>
#include <java/io/Serializable.hpp>

struct default_init_tag;

class java::awt::FlowLayout
    : public virtual ::java::lang::Object
    , public virtual LayoutManager
    , public virtual ::java::io::Serializable
{

public:
    typedef ::java::lang::Object super;
    static constexpr int32_t CENTER { int32_t(1) };
    static constexpr int32_t LEADING { int32_t(3) };
    static constexpr int32_t LEFT { int32_t(0) };
    static constexpr int32_t RIGHT { int32_t(2) };
    static constexpr int32_t TRAILING { int32_t(4) };

public: /* package */
    int32_t align {  };

private:
    bool alignOnBaseline {  };
    static constexpr int32_t currentSerialVersion { int32_t(1) };

public: /* package */
    int32_t hgap {  };
    int32_t newAlign {  };

private:
    int32_t serialVersionOnStream {  };
    static constexpr int64_t serialVersionUID { int64_t(-7262534875583282631LL) };

public: /* package */
    int32_t vgap {  };

protected:
    void ctor();
    void ctor(int32_t arg0);
    void ctor(int32_t arg0, int32_t arg1, int32_t arg2);

public:
    void addLayoutComponent(::java::lang::String* arg0, Component* arg1) override;
    virtual bool getAlignOnBaseline();
    virtual int32_t getAlignment();
    virtual int32_t getHgap();
    virtual int32_t getVgap();
    void layoutContainer(Container* arg0) override;
    Dimension* minimumLayoutSize(Container* arg0) override;
    /*int32_t moveComponents(Container* arg0, int32_t arg1, int32_t arg2, int32_t arg3, int32_t arg4, int32_t arg5, int32_t arg6, bool arg7, bool arg8, ::int32_tArray* arg9, ::int32_tArray* arg10); (private) */
    Dimension* preferredLayoutSize(Container* arg0) override;
    /*void readObject(::java::io::ObjectInputStream* arg0); (private) */
    void removeLayoutComponent(Component* arg0) override;
    virtual void setAlignOnBaseline(bool arg0);
    virtual void setAlignment(int32_t arg0);
    virtual void setHgap(int32_t arg0);
    virtual void setVgap(int32_t arg0);
    ::java::lang::String* toString() override;

    // Generated
    FlowLayout();
    FlowLayout(int32_t arg0);
    FlowLayout(int32_t arg0, int32_t arg1, int32_t arg2);
protected:
    FlowLayout(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
