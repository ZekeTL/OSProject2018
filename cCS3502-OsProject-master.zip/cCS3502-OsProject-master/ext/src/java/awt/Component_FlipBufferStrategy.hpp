// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/image/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/image/BufferStrategy.hpp>

struct default_init_tag;

class java::awt::Component_FlipBufferStrategy
    : public ::java::awt::image::BufferStrategy
{

public:
    typedef ::java::awt::image::BufferStrategy super;

public: /* protected */
    BufferCapabilities* caps {  };
    Image* drawBuffer {  };
    ::java::awt::image::VolatileImage* drawVBuffer {  };

public: /* package */
    int32_t height {  };

public: /* protected */
    int32_t numBuffers {  };

public: /* package */
    Component* this$0 {  };

public: /* protected */
    bool validatedContents {  };

public: /* package */
    int32_t width {  };

protected:
    void ctor(int32_t arg0, BufferCapabilities* arg1);

public:
    bool contentsLost() override;
    bool contentsRestored() override;

public: /* protected */
    virtual void createBuffers(int32_t numBuffers, BufferCapabilities* caps);
    virtual void destroyBuffers();

public:
    void dispose() override;

public: /* protected */
    virtual void flip(BufferCapabilities_FlipContents* flipAction);

public: /* package */
    virtual void flipSubRegion(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3, BufferCapabilities_FlipContents* arg4);

public: /* protected */
    virtual Image* getBackBuffer();

public:
    BufferCapabilities* getCapabilities() override;
    Graphics* getDrawGraphics() override;

public: /* protected */
    virtual void revalidate();

public: /* package */
    virtual void revalidate(bool arg0);

public:
    void show() override;

public: /* package */
    virtual void showSubRegion(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3);
    /*void updateInternalBuffers(); (private) */

    // Generated

public: /* protected */
    Component_FlipBufferStrategy(Component *Component_this, int32_t arg0, BufferCapabilities* arg1);
protected:
    Component_FlipBufferStrategy(Component *Component_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    Component *Component_this;

private:
    virtual ::java::lang::Class* getClass0();
};
