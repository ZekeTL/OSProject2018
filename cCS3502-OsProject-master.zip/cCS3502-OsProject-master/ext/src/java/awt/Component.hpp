// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <atomic>
#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/dnd/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/im/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/image/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/peer/fwd-CS3502-OsProject-master.hpp>
#include <java/beans/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/reflect/fwd-CS3502-OsProject-master.hpp>
#include <java/security/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <sun/awt/fwd-CS3502-OsProject-master.hpp>
#include <sun/java2d/pipe/fwd-CS3502-OsProject-master.hpp>
#include <sun/util/logging/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/awt/image/ImageObserver.hpp>
#include <java/awt/MenuContainer.hpp>
#include <java/io/Serializable.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace util
    {
typedef ::SubArray< ::java::util::EventListener, ::java::lang::ObjectArray > EventListenerArray;
    } // util

    namespace awt
    {
        namespace event
        {
typedef ::SubArray< ::java::awt::event::ComponentListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > ComponentListenerArray;
typedef ::SubArray< ::java::awt::event::FocusListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > FocusListenerArray;
typedef ::SubArray< ::java::awt::event::HierarchyBoundsListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > HierarchyBoundsListenerArray;
typedef ::SubArray< ::java::awt::event::HierarchyListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > HierarchyListenerArray;
typedef ::SubArray< ::java::awt::event::InputMethodListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > InputMethodListenerArray;
typedef ::SubArray< ::java::awt::event::KeyListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > KeyListenerArray;
typedef ::SubArray< ::java::awt::event::MouseListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > MouseListenerArray;
typedef ::SubArray< ::java::awt::event::MouseMotionListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > MouseMotionListenerArray;
typedef ::SubArray< ::java::awt::event::MouseWheelListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > MouseWheelListenerArray;
        } // event
    } // awt

    namespace beans
    {
typedef ::SubArray< ::java::beans::PropertyChangeListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > PropertyChangeListenerArray;
    } // beans

    namespace io
    {
typedef ::SubArray< ::java::io::Serializable, ::java::lang::ObjectArray > SerializableArray;
    } // io

    namespace lang
    {
typedef ::SubArray< ::java::lang::CharSequence, ObjectArray > CharSequenceArray;

        namespace reflect
        {
typedef ::SubArray< ::java::lang::reflect::AnnotatedElement, ::java::lang::ObjectArray > AnnotatedElementArray;
typedef ::SubArray< ::java::lang::reflect::GenericDeclaration, ::java::lang::ObjectArray, AnnotatedElementArray > GenericDeclarationArray;
typedef ::SubArray< ::java::lang::reflect::Type, ::java::lang::ObjectArray > TypeArray;
        } // reflect
typedef ::SubArray< ::java::lang::Class, ObjectArray, ::java::io::SerializableArray, ::java::lang::reflect::GenericDeclarationArray, ::java::lang::reflect::TypeArray, ::java::lang::reflect::AnnotatedElementArray > ClassArray;
typedef ::SubArray< ::java::lang::Comparable, ObjectArray > ComparableArray;
typedef ::SubArray< ::java::lang::Iterable, ObjectArray > IterableArray;
typedef ::SubArray< ::java::lang::String, ObjectArray, ::java::io::SerializableArray, ComparableArray, CharSequenceArray > StringArray;
    } // lang

    namespace util
    {
typedef ::SubArray< ::java::util::Collection, ::java::lang::ObjectArray, ::java::lang::IterableArray > CollectionArray;
typedef ::SubArray< ::java::util::Set, ::java::lang::ObjectArray, CollectionArray > SetArray;
    } // util
} // java

namespace sun
{
    namespace awt
    {
typedef ::SubArray< ::sun::awt::EventQueueItem, ::java::lang::ObjectArray > EventQueueItemArray;
    } // awt
} // sun

struct default_init_tag;

class java::awt::Component
    : public virtual ::java::lang::Object
    , public virtual ::java::awt::image::ImageObserver
    , public virtual MenuContainer
    , public virtual ::java::io::Serializable
{

public:
    typedef ::java::lang::Object super;

private:
    static bool $assertionsDisabled_;

public:
    static constexpr float BOTTOM_ALIGNMENT { 1.0f };
    static constexpr float CENTER_ALIGNMENT { 0.5f };

private:
    static constexpr int32_t FOCUS_TRAVERSABLE_DEFAULT { int32_t(1) };
    static constexpr int32_t FOCUS_TRAVERSABLE_SET { int32_t(2) };
    static constexpr int32_t FOCUS_TRAVERSABLE_UNKNOWN { int32_t(0) };

public:
    static constexpr float LEFT_ALIGNMENT { 0.0f };

private:
    static ::java::lang::Object* LOCK_;

public:
    static constexpr float RIGHT_ALIGNMENT { 1.0f };
    static constexpr float TOP_ALIGNMENT { 0.0f };

private:
    std::atomic< ::java::security::AccessControlContext* > acc {  };

public: /* protected */
    ::javax::accessibility::AccessibleContext* accessibleContext {  };

private:
    static ::java::lang::String* actionListenerK_;
    static ::java::lang::String* adjustmentListenerK_;

public: /* package */
    ::sun::awt::AppContext* appContext {  };

private:
    bool autoFocusTransferOnDisposal {  };

public: /* package */
    Color* background {  };
    bool backgroundEraseDisabled {  };

private:
    int32_t boundsOp {  };

public: /* package */
    ::java::awt::image::BufferStrategy* bufferStrategy {  };

private:
    ::java::beans::PropertyChangeSupport* changeSupport {  };
    static ::java::lang::ClassArray* coalesceEventsParams_;
    static ::java::util::Map* coalesceMap_;
    bool coalescingEnabled {  };

public: /* package */
    ::java::awt::event::ComponentListener* componentListener {  };

private:
    static ::java::lang::String* componentListenerK_;

public: /* package */
    ComponentOrientation* componentOrientation {  };

private:
    int32_t componentSerializedDataVersion {  };
    ::sun::java2d::pipe::Region* compoundShape {  };
    static ::java::lang::String* containerListenerK_;

public: /* package */
    Cursor* cursor {  };
    ::java::awt::dnd::DropTarget* dropTarget {  };
    bool enabled {  };
    ::sun::awt::EventQueueItemArray* eventCache {  };

private:
    static ::sun::util::logging::PlatformLogger* eventLog_;

public: /* package */
    int64_t eventMask {  };
    ::java::awt::event::FocusListener* focusListener {  };

private:
    static ::java::lang::String* focusListenerK_;
    static ::sun::util::logging::PlatformLogger* focusLog_;
    static ::java::lang::StringArray* focusTraversalKeyPropertyNames_;

public: /* package */
    ::java::util::SetArray* focusTraversalKeys {  };

private:
    bool focusTraversalKeysEnabled {  };
    bool focusable {  };

public: /* package */
    std::atomic< Font* > font {  };
    Color* foreground {  };

private:
    std::atomic< GraphicsConfiguration* > graphicsConfig {  };

public: /* package */
    int32_t height {  };
    ::java::awt::event::HierarchyBoundsListener* hierarchyBoundsListener {  };

private:
    static ::java::lang::String* hierarchyBoundsListenerK_;

public: /* package */
    ::java::awt::event::HierarchyListener* hierarchyListener {  };

private:
    static ::java::lang::String* hierarchyListenerK_;

public: /* package */
    bool ignoreRepaint {  };

private:
    static int32_t incRate_;

public: /* package */
    ::java::awt::event::InputMethodListener* inputMethodListener {  };

private:
    static ::java::lang::String* inputMethodListenerK_;
    bool isAddNotifyComplete {  };
    int32_t isFocusTraversableOverridden_ {  };
    static bool isInc_;

public: /* package */
    bool isPacked {  };

private:
    static ::java::lang::String* itemListenerK_;

public: /* package */
    ::java::awt::event::KeyListener* keyListener {  };

private:
    static ::java::lang::String* keyListenerK_;

public: /* package */
    ::java::util::Locale* locale {  };

private:
    static ::sun::util::logging::PlatformLogger* log_;

public: /* package */
    Dimension* maxSize {  };
    bool maxSizeSet {  };
    Dimension* minSize {  };
    bool minSizeSet {  };

private:
    ::sun::java2d::pipe::Region* mixingCutoutRegion {  };
    static ::sun::util::logging::PlatformLogger* mixingLog_;

public: /* package */
    ::java::awt::event::MouseListener* mouseListener {  };

private:
    static ::java::lang::String* mouseListenerK_;

public: /* package */
    ::java::awt::event::MouseMotionListener* mouseMotionListener {  };

private:
    static ::java::lang::String* mouseMotionListenerK_;

public: /* package */
    ::java::awt::event::MouseWheelListener* mouseWheelListener {  };

private:
    static ::java::lang::String* mouseWheelListenerK_;
    ::java::lang::String* name {  };
    bool nameExplicitlySet {  };

public: /* package */
    bool newEventsOnly {  };

private:
    ::java::lang::Object* objectLock {  };
    static ::java::lang::String* ownedWindowK_;

public: /* package */
    Container* parent {  };
    ::java::awt::peer::ComponentPeer* peer {  };
    Font* peerFont {  };
    ::java::util::Vector* popups {  };
    Dimension* prefSize {  };
    bool prefSizeSet {  };

private:
    static ::sun::awt::RequestFocusController* requestFocusController_;
    static constexpr int64_t serialVersionUID { int64_t(-7644114512714619750LL) };
    static ::java::lang::String* textListenerK_;
    std::atomic< bool > valid {  };

public: /* package */
    bool visible {  };
    int32_t width {  };
    ::java::lang::RuntimeException* windowClosingException {  };

private:
    static ::java::lang::String* windowFocusListenerK_;
    static ::java::lang::String* windowListenerK_;
    static ::java::lang::String* windowStateListenerK_;

public: /* package */
    int32_t x {  };
    int32_t y {  };

protected:
    void ctor();

public:
    virtual bool action(Event* arg0, ::java::lang::Object* arg1);
    virtual void add(PopupMenu* arg0);
    virtual void addComponentListener(::java::awt::event::ComponentListener* arg0);
    virtual void addFocusListener(::java::awt::event::FocusListener* arg0);
    virtual void addHierarchyBoundsListener(::java::awt::event::HierarchyBoundsListener* arg0);
    virtual void addHierarchyListener(::java::awt::event::HierarchyListener* arg0);
    virtual void addInputMethodListener(::java::awt::event::InputMethodListener* arg0);
    virtual void addKeyListener(::java::awt::event::KeyListener* arg0);
    virtual void addMouseListener(::java::awt::event::MouseListener* arg0);
    virtual void addMouseMotionListener(::java::awt::event::MouseMotionListener* arg0);
    virtual void addMouseWheelListener(::java::awt::event::MouseWheelListener* arg0);
    virtual void addNotify();
    virtual void addPropertyChangeListener(::java::beans::PropertyChangeListener* arg0);
    virtual void addPropertyChangeListener(::java::lang::String* arg0, ::java::beans::PropertyChangeListener* arg1);

public: /* package */
    virtual void adjustListeningChildrenOnParent(int64_t arg0, int32_t arg1);

public:
    virtual void applyComponentOrientation(ComponentOrientation* arg0);

public: /* package */
    virtual void applyCompoundShape(::sun::java2d::pipe::Region* arg0);
    virtual void applyCurrentShape();
    /*void applyCurrentShapeBelowMe(); (private) */
    bool areBoundsValid();

public:
    virtual bool areFocusTraversalKeysSet(int32_t arg0);

public: /* package */
    virtual bool areInputMethodsEnabled();
    virtual void autoProcessMouseWheel(::java::awt::event::MouseWheelEvent* arg0);

public:
    virtual Rectangle* bounds();
    /*::sun::java2d::pipe::Region* calculateCurrentShape(); (private) */

public: /* package */
    bool canBeFocusOwner();
    bool canBeFocusOwnerRecursively();
    /*bool checkCoalescing(); (private) */
    virtual void checkGD(::java::lang::String* arg0);

public:
    virtual int32_t checkImage(Image* arg0, ::java::awt::image::ImageObserver* arg1);
    virtual int32_t checkImage(Image* arg0, int32_t arg1, int32_t arg2, ::java::awt::image::ImageObserver* arg3);

public: /* package */
    void checkTreeLock();
    virtual bool checkWindowClosingException();
    virtual void clearCurrentFocusCycleRootOnHide();
    virtual void clearMostRecentFocusOwnerOnHide();

public: /* protected */
    virtual AWTEvent* coalesceEvents(AWTEvent* arg0, AWTEvent* arg1);

public: /* package */
    virtual ::java::lang::String* constructComponentName();

public:
    virtual bool contains(Point* arg0);
    virtual bool contains(int32_t arg0, int32_t arg1);

public: /* package */
    virtual bool containsFocus();
    virtual int32_t countHierarchyMembers();
    virtual void createBufferStrategy(int32_t arg0);
    virtual void createBufferStrategy(int32_t arg0, BufferCapabilities* arg1);
    virtual int32_t createHierarchyEvents(int32_t arg0, Component* arg1, Container* arg2, int64_t arg3, bool arg4);

public:
    virtual Image* createImage(::java::awt::image::ImageProducer* arg0);
    virtual Image* createImage(int32_t arg0, int32_t arg1);
    virtual ::java::awt::image::VolatileImage* createVolatileImage(int32_t arg0, int32_t arg1);
    virtual ::java::awt::image::VolatileImage* createVolatileImage(int32_t arg0, int32_t arg1, ImageCapabilities* arg2);
    virtual void deliverEvent(Event* arg0);
    virtual void disable();

public: /* protected */
    void disableEvents(int64_t arg0);

public:
    void dispatchEvent(AWTEvent* arg0);

public: /* package */
    virtual void dispatchEventImpl(AWTEvent* arg0);
    virtual bool dispatchMouseWheelToAncestor(::java::awt::event::MouseWheelEvent* arg0);

public:
    virtual void doLayout();
    /*void doSwingSerialization(); (private) */
    virtual void enable();
    virtual void enable(bool arg0);

public: /* protected */
    void enableEvents(int64_t arg0);

public:
    virtual void enableInputMethods(bool arg0);

public: /* package */
    virtual bool eventEnabled(AWTEvent* arg0);
    virtual bool eventTypeEnabled(int32_t arg0);
    virtual Component* findUnderMouseInWindow(PointerInfo* arg0);

public: /* protected */
    virtual void firePropertyChange(::java::lang::String* arg0, ::java::lang::Object* arg1, ::java::lang::Object* arg2);
    virtual void firePropertyChange(::java::lang::String* arg0, bool arg1, bool arg2);
    virtual void firePropertyChange(::java::lang::String* arg0, int32_t arg1, int32_t arg2);

public:
    virtual void firePropertyChange(::java::lang::String* arg0, int8_t arg1, int8_t arg2);
    virtual void firePropertyChange(::java::lang::String* arg0, char16_t arg1, char16_t arg2);
    virtual void firePropertyChange(::java::lang::String* arg0, int16_t arg1, int16_t arg2);
    virtual void firePropertyChange(::java::lang::String* arg0, int64_t arg1, int64_t arg2);
    virtual void firePropertyChange(::java::lang::String* arg0, float arg1, float arg2);
    virtual void firePropertyChange(::java::lang::String* arg0, double arg1, double arg2);

public: /* package */
    ::java::security::AccessControlContext* getAccessControlContext();

public:
    virtual ::javax::accessibility::AccessibleContext* getAccessibleContext();

public: /* package */
    virtual int32_t getAccessibleIndexInParent();
    virtual ::javax::accessibility::AccessibleStateSet* getAccessibleStateSet();

public:
    virtual float getAlignmentX();
    virtual float getAlignmentY();
    /*::sun::java2d::pipe::Region* getAppliedShape(); (private) */

public: /* package */
    virtual Image* getBackBuffer();

public:
    virtual Color* getBackground();
    virtual int32_t getBaseline(int32_t arg0, int32_t arg1);
    virtual Component_BaselineResizeBehavior* getBaselineResizeBehavior();
    virtual Rectangle* getBounds();
    virtual Rectangle* getBounds(Rectangle* arg0);

public: /* package */
    virtual int32_t getBoundsOp();
    virtual ::java::awt::image::BufferStrategy* getBufferStrategy();

public:
    virtual ::java::awt::image::ColorModel* getColorModel();
    virtual Component* getComponentAt(Point* arg0);
    virtual Component* getComponentAt(int32_t arg0, int32_t arg1);
    virtual ::java::awt::event::ComponentListenerArray* getComponentListeners();
    virtual ComponentOrientation* getComponentOrientation();

public: /* package */
    virtual Container* getContainer();
    virtual Window* getContainingWindow();

public:
    virtual Cursor* getCursor();

public: /* package */
    Cursor* getCursor_NoClientCode();

public:
    virtual ::java::awt::dnd::DropTarget* getDropTarget();
    virtual Container* getFocusCycleRootAncestor();
    virtual ::java::awt::event::FocusListenerArray* getFocusListeners();
    virtual ::java::util::Set* getFocusTraversalKeys(int32_t arg0);
    virtual bool getFocusTraversalKeysEnabled();

public: /* package */
    ::java::util::Set* getFocusTraversalKeys_NoIDCheck(int32_t arg0);

public:
    Font* getFont() override;
    virtual FontMetrics* getFontMetrics(Font* arg0);

public: /* package */
    Font* getFont_NoClientCode();

public:
    virtual Color* getForeground();
    virtual Graphics* getGraphics();
    virtual GraphicsConfiguration* getGraphicsConfiguration();

public: /* package */
    GraphicsConfiguration* getGraphicsConfiguration_NoClientCode();
    Graphics* getGraphics_NoClientCode();
    ::java::awt::peer::ComponentPeer* getHWPeerAboveMe();

public:
    virtual int32_t getHeight();
    virtual ::java::awt::event::HierarchyBoundsListenerArray* getHierarchyBoundsListeners();
    virtual ::java::awt::event::HierarchyListenerArray* getHierarchyListeners();
    virtual bool getIgnoreRepaint();
    virtual ::java::awt::im::InputContext* getInputContext();
    virtual ::java::awt::event::InputMethodListenerArray* getInputMethodListeners();
    virtual ::java::awt::im::InputMethodRequests* getInputMethodRequests();
    /*Insets* getInsets_NoClientCode(); (private) */
    virtual ::java::awt::event::KeyListenerArray* getKeyListeners();
    virtual ::java::util::EventListenerArray* getListeners(::java::lang::Class* arg0);
    virtual ::java::util::Locale* getLocale();
    virtual Point* getLocation();
    virtual Point* getLocation(Point* arg0);
    virtual Point* getLocationOnScreen();

public: /* package */
    Point* getLocationOnScreen_NoTreeLock();
    virtual Point* getLocationOnWindow();

public:
    virtual Dimension* getMaximumSize();
    virtual Dimension* getMinimumSize();
    virtual ::java::awt::event::MouseListenerArray* getMouseListeners();
    virtual ::java::awt::event::MouseMotionListenerArray* getMouseMotionListeners();
    virtual Point* getMousePosition();
    virtual ::java::awt::event::MouseWheelListenerArray* getMouseWheelListeners();
    virtual ::java::lang::String* getName();

public: /* package */
    Container* getNativeContainer();
    Component* getNextFocusCandidate();
    ::sun::java2d::pipe::Region* getNormalShape();
    virtual ::java::lang::Object* getObjectLock();
    virtual ::sun::java2d::pipe::Region* getOpaqueShape();

public:
    virtual Container* getParent();

public: /* package */
    Container* getParent_NoClientCode();

public:
    virtual ::java::awt::peer::ComponentPeer* getPeer();
    virtual Dimension* getPreferredSize();
    virtual ::java::beans::PropertyChangeListenerArray* getPropertyChangeListeners();
    virtual ::java::beans::PropertyChangeListenerArray* getPropertyChangeListeners(::java::lang::String* arg0);
    /*Rectangle* getRecursivelyVisibleBounds(); (private) */

public: /* package */
    int32_t getSiblingIndexAbove();
    int32_t getSiblingIndexBelow();

public:
    virtual Dimension* getSize();
    virtual Dimension* getSize(Dimension* arg0);
    virtual Toolkit* getToolkit();

public: /* package */
    Toolkit* getToolkitImpl();
    virtual Container* getTraversalRoot();

public:
    ::java::lang::Object* getTreeLock();
    virtual int32_t getWidth();
    virtual int32_t getX();
    virtual int32_t getY();
    virtual bool gotFocus(Event* arg0, ::java::lang::Object* arg1);
    virtual bool handleEvent(Event* arg0);
    virtual bool hasFocus();
    virtual void hide();
    bool imageUpdate(Image* arg0, int32_t arg1, int32_t arg2, int32_t arg3, int32_t arg4, int32_t arg5) override;
    /*static void initIDs(); (private) */

public: /* package */
    virtual void initializeFocusTraversalKeys();

public:
    virtual bool inside(int32_t arg0, int32_t arg1);
    virtual void invalidate();

public: /* package */
    void invalidateIfValid();
    virtual void invalidateParent();
    virtual bool isAutoFocusTransferOnDisposal();

public:
    virtual bool isBackgroundSet();
    /*static bool isCoalesceEventsOverriden(::java::lang::Class* arg0); (private) */

public: /* package */
    bool isCoalescingEnabled();

public:
    virtual bool isCursorSet();
    virtual bool isDisplayable();
    virtual bool isDoubleBuffered();
    virtual bool isEnabled();

public: /* package */
    bool isEnabledImpl();

public:
    virtual bool isFocusCycleRoot(Container* arg0);
    virtual bool isFocusOwner();
    virtual bool isFocusTraversable();

public: /* package */
    bool isFocusTraversableOverridden();

public:
    virtual bool isFocusable();
    virtual bool isFontSet();
    virtual bool isForegroundSet();

public: /* package */
    static bool isInstanceOf(::java::lang::Object* arg0, ::java::lang::String* arg1);

public:
    virtual bool isLightweight();
    virtual bool isMaximumSizeSet();
    virtual bool isMinimumSizeSet();

public: /* package */
    bool isMixingNeeded();
    bool isNonOpaqueForMixing();

public:
    virtual bool isOpaque();
    virtual bool isPreferredSizeSet();

public: /* package */
    virtual bool isRecursivelyVisible();
    /*bool isRequestFocusAccepted(bool arg0, bool arg1, ::sun::awt::CausedFocusEvent_Cause* arg2); (private) */
    virtual bool isSameOrAncestorOf(Component* arg0, bool arg1);

public:
    virtual bool isShowing();
    virtual bool isValid();
    virtual bool isVisible();

public: /* package */
    bool isVisible_NoClientCode();

public:
    virtual bool keyDown(Event* arg0, int32_t arg1);
    virtual bool keyUp(Event* arg0, int32_t arg1);
    virtual void layout();

public: /* package */
    virtual void lightweightPaint(Graphics* arg0);
    virtual void lightweightPrint(Graphics* arg0);

public:
    virtual void list();
    virtual void list(::java::io::PrintStream* arg0);
    virtual void list(::java::io::PrintWriter* arg0);
    virtual void list(::java::io::PrintStream* arg0, int32_t arg1);
    virtual void list(::java::io::PrintWriter* arg0, int32_t arg1);
    virtual Component* locate(int32_t arg0, int32_t arg1);
    virtual Point* location();
    /*Point* location_NoClientCode(); (private) */
    virtual bool lostFocus(Event* arg0, ::java::lang::Object* arg1);
    virtual Dimension* minimumSize();

public: /* package */
    virtual void mixOnHiding(bool arg0);
    virtual void mixOnReshaping();
    virtual void mixOnShowing();
    virtual void mixOnValidating();
    virtual void mixOnZOrderChanging(int32_t arg0, int32_t arg1);

public:
    virtual bool mouseDown(Event* arg0, int32_t arg1, int32_t arg2);
    virtual bool mouseDrag(Event* arg0, int32_t arg1, int32_t arg2);
    virtual bool mouseEnter(Event* arg0, int32_t arg1, int32_t arg2);
    virtual bool mouseExit(Event* arg0, int32_t arg1, int32_t arg2);
    virtual bool mouseMove(Event* arg0, int32_t arg1, int32_t arg2);
    virtual bool mouseUp(Event* arg0, int32_t arg1, int32_t arg2);
    virtual void move(int32_t arg0, int32_t arg1);
    virtual void nextFocus();
    /*void notifyNewBounds(bool arg0, bool arg1); (private) */

public: /* package */
    virtual int32_t numListening(int64_t arg0);

public:
    virtual void paint(Graphics* arg0);
    virtual void paintAll(Graphics* arg0);

public: /* package */
    virtual void paintHeavyweightComponents(Graphics* arg0);

public: /* protected */
    virtual ::java::lang::String* paramString();

public: /* package */
    virtual Point* pointRelativeToComponent(Point* arg0);

public:
    bool postEvent(Event* arg0) override;

public: /* package */
    virtual bool postsOldMouseEvents();

public:
    virtual Dimension* preferredSize();
    virtual bool prepareImage(Image* arg0, ::java::awt::image::ImageObserver* arg1);
    virtual bool prepareImage(Image* arg0, int32_t arg1, int32_t arg2, ::java::awt::image::ImageObserver* arg3);
    virtual void print(Graphics* arg0);
    virtual void printAll(Graphics* arg0);

public: /* package */
    virtual void printHeavyweightComponents(Graphics* arg0);

public: /* protected */
    virtual void processComponentEvent(::java::awt::event::ComponentEvent* arg0);
    virtual void processEvent(AWTEvent* arg0);
    virtual void processFocusEvent(::java::awt::event::FocusEvent* arg0);
    virtual void processHierarchyBoundsEvent(::java::awt::event::HierarchyEvent* arg0);
    virtual void processHierarchyEvent(::java::awt::event::HierarchyEvent* arg0);
    virtual void processInputMethodEvent(::java::awt::event::InputMethodEvent* arg0);
    virtual void processKeyEvent(::java::awt::event::KeyEvent* arg0);
    virtual void processMouseEvent(::java::awt::event::MouseEvent* arg0);
    virtual void processMouseMotionEvent(::java::awt::event::MouseEvent* arg0);
    virtual void processMouseWheelEvent(::java::awt::event::MouseWheelEvent* arg0);
    /*void readObject(::java::io::ObjectInputStream* arg0); (private) */

public: /* package */
    void relocateComponent();

public:
    void remove(MenuComponent* arg0) override;
    virtual void removeComponentListener(::java::awt::event::ComponentListener* arg0);
    virtual void removeFocusListener(::java::awt::event::FocusListener* arg0);
    virtual void removeHierarchyBoundsListener(::java::awt::event::HierarchyBoundsListener* arg0);
    virtual void removeHierarchyListener(::java::awt::event::HierarchyListener* arg0);
    virtual void removeInputMethodListener(::java::awt::event::InputMethodListener* arg0);
    virtual void removeKeyListener(::java::awt::event::KeyListener* arg0);
    virtual void removeMouseListener(::java::awt::event::MouseListener* arg0);
    virtual void removeMouseMotionListener(::java::awt::event::MouseMotionListener* arg0);
    virtual void removeMouseWheelListener(::java::awt::event::MouseWheelListener* arg0);
    virtual void removeNotify();
    virtual void removePropertyChangeListener(::java::beans::PropertyChangeListener* arg0);
    virtual void removePropertyChangeListener(::java::lang::String* arg0, ::java::beans::PropertyChangeListener* arg1);
    virtual void repaint();
    virtual void repaint(int64_t arg0);
    virtual void repaint(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3);
    virtual void repaint(int64_t arg0, int32_t arg1, int32_t arg2, int32_t arg3, int32_t arg4);
    /*void repaintParentIfNeeded(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3); (private) */
    virtual void requestFocus();

public: /* package */
    virtual bool requestFocus(::sun::awt::CausedFocusEvent_Cause* arg0);

public: /* protected */
    virtual bool requestFocus(bool arg0);

public: /* package */
    virtual bool requestFocus(bool arg0, ::sun::awt::CausedFocusEvent_Cause* arg1);
    bool requestFocusHelper(bool arg0, bool arg1);
    bool requestFocusHelper(bool arg0, bool arg1, ::sun::awt::CausedFocusEvent_Cause* arg2);

public:
    virtual bool requestFocusInWindow();

public: /* package */
    virtual bool requestFocusInWindow(::sun::awt::CausedFocusEvent_Cause* arg0);

public: /* protected */
    virtual bool requestFocusInWindow(bool arg0);

public: /* package */
    virtual bool requestFocusInWindow(bool arg0, ::sun::awt::CausedFocusEvent_Cause* arg1);

public:
    virtual void reshape(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3);
    /*void reshapeNativePeer(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3, int32_t arg4); (private) */
    virtual void resize(Dimension* arg0);
    virtual void resize(int32_t arg0, int32_t arg1);
    virtual void revalidate();

public: /* package */
    void revalidateSynchronously();
    virtual void setAutoFocusTransferOnDisposal(bool arg0);

public:
    virtual void setBackground(Color* arg0);
    virtual void setBounds(Rectangle* arg0);
    virtual void setBounds(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3);

public: /* package */
    virtual void setBoundsOp(int32_t arg0);

public:
    virtual void setComponentOrientation(ComponentOrientation* arg0);
    virtual void setCursor(Cursor* arg0);
    virtual void setDropTarget(::java::awt::dnd::DropTarget* arg0);
    virtual void setEnabled(bool arg0);
    virtual void setFocusTraversalKeys(int32_t arg0, ::java::util::Set* arg1);
    virtual void setFocusTraversalKeysEnabled(bool arg0);

public: /* package */
    void setFocusTraversalKeys_NoIDCheck(int32_t arg0, ::java::util::Set* arg1);

public:
    virtual void setFocusable(bool arg0);
    virtual void setFont(Font* arg0);
    virtual void setForeground(Color* arg0);

public: /* package */
    virtual void setGraphicsConfiguration(GraphicsConfiguration* arg0);

public:
    virtual void setIgnoreRepaint(bool arg0);
    virtual void setLocale(::java::util::Locale* arg0);
    virtual void setLocation(Point* arg0);
    virtual void setLocation(int32_t arg0, int32_t arg1);
    virtual void setMaximumSize(Dimension* arg0);
    virtual void setMinimumSize(Dimension* arg0);
    virtual void setName(::java::lang::String* arg0);
    virtual void setPreferredSize(Dimension* arg0);

public: /* package */
    static void setRequestFocusController(::sun::awt::RequestFocusController* arg0);

public:
    virtual void setSize(Dimension* arg0);
    virtual void setSize(int32_t arg0, int32_t arg1);
    virtual void setVisible(bool arg0);
    virtual void show();
    virtual void show(bool arg0);
    virtual Dimension* size();

public: /* package */
    void subtractAndApplyShape(::sun::java2d::pipe::Region* arg0);
    void subtractAndApplyShapeBelowMe();

public:
    ::java::lang::String* toString() override;
    virtual void transferFocus();

public: /* package */
    virtual bool transferFocus(bool arg0);

public:
    virtual void transferFocusBackward();

public: /* package */
    virtual bool transferFocusBackward(bool arg0);

public:
    virtual void transferFocusUpCycle();
    virtual void update(Graphics* arg0);

public: /* package */
    void updateCursorImmediately();
    virtual bool updateGraphicsData(GraphicsConfiguration* arg0);
    virtual void updateZOrder();

public:
    virtual void validate();
    /*void writeObject(::java::io::ObjectOutputStream* arg0); (private) */

    // Generated

public: /* protected */
    Component();
protected:
    Component(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

public: /* package */
    static bool& $assertionsDisabled();
    static ::java::lang::Object*& LOCK();
    static ::java::lang::String*& actionListenerK();
    static ::java::lang::String*& adjustmentListenerK();

private:
    static ::java::lang::ClassArray*& coalesceEventsParams();
    static ::java::util::Map*& coalesceMap();

public: /* package */
    static ::java::lang::String*& componentListenerK();
    static ::java::lang::String*& containerListenerK();

private:
    static ::sun::util::logging::PlatformLogger*& eventLog();

public: /* package */
    static ::java::lang::String*& focusListenerK();

private:
    static ::sun::util::logging::PlatformLogger*& focusLog();
    static ::java::lang::StringArray*& focusTraversalKeyPropertyNames();

public: /* package */
    static ::java::lang::String*& hierarchyBoundsListenerK();
    static ::java::lang::String*& hierarchyListenerK();
    static int32_t& incRate();
    static ::java::lang::String*& inputMethodListenerK();
    static bool& isInc();
    static ::java::lang::String*& itemListenerK();
    static ::java::lang::String*& keyListenerK();

private:
    static ::sun::util::logging::PlatformLogger*& log();
    static ::sun::util::logging::PlatformLogger*& mixingLog();

public: /* package */
    static ::java::lang::String*& mouseListenerK();
    static ::java::lang::String*& mouseMotionListenerK();
    static ::java::lang::String*& mouseWheelListenerK();
    static ::java::lang::String*& ownedWindowK();

private:
    static ::sun::awt::RequestFocusController*& requestFocusController();

public: /* package */
    static ::java::lang::String*& textListenerK();
    static ::java::lang::String*& windowFocusListenerK();
    static ::java::lang::String*& windowListenerK();
    static ::java::lang::String*& windowStateListenerK();

private:
    virtual ::java::lang::Class* getClass0();
};
