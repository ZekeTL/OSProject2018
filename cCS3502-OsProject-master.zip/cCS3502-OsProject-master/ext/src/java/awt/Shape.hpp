// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/geom/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct java::awt::Shape
    : public virtual ::java::lang::Object
{

    virtual bool contains(::java::awt::geom::Point2D* arg0) = 0;
    virtual bool contains(::java::awt::geom::Rectangle2D* arg0) = 0;
    virtual bool contains(double arg0, double arg1) = 0;
    virtual bool contains(double arg0, double arg1, double arg2, double arg3) = 0;
    virtual Rectangle* getBounds() = 0;
    virtual ::java::awt::geom::Rectangle2D* getBounds2D() = 0;
    virtual ::java::awt::geom::PathIterator* getPathIterator(::java::awt::geom::AffineTransform* arg0) = 0;
    virtual ::java::awt::geom::PathIterator* getPathIterator(::java::awt::geom::AffineTransform* arg0, double arg1) = 0;
    virtual bool intersects(::java::awt::geom::Rectangle2D* arg0) = 0;
    virtual bool intersects(double arg0, double arg1, double arg2, double arg3) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
