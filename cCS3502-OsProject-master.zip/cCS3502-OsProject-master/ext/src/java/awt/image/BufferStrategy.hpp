// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/image/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct default_init_tag;

class java::awt::image::BufferStrategy
    : public virtual ::java::lang::Object
{

public:
    typedef ::java::lang::Object super;

protected:
    void ctor();

public:
    virtual bool contentsLost() = 0;
    virtual bool contentsRestored() = 0;
    virtual void dispose();
    virtual ::java::awt::BufferCapabilities* getCapabilities() = 0;
    virtual ::java::awt::Graphics* getDrawGraphics() = 0;
    virtual void show() = 0;

    // Generated
    BufferStrategy();
protected:
    BufferStrategy(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
