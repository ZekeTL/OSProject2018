// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/color/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/geom/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/image/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/awt/Paint.hpp>
#include <java/io/Serializable.hpp>

struct default_init_tag;

class java::awt::Color
    : public virtual ::java::lang::Object
    , public virtual Paint
    , public virtual ::java::io::Serializable
{

public:
    typedef ::java::lang::Object super;

private:
    static Color* BLACK_;
    static Color* BLUE_;
    static Color* CYAN_;
    static Color* DARK_GRAY_;
    static constexpr double FACTOR { 0.7 };
    static Color* GRAY_;
    static Color* GREEN_;
    static Color* LIGHT_GRAY_;
    static Color* MAGENTA_;
    static Color* ORANGE_;
    static Color* PINK_;
    static Color* RED_;
    static Color* WHITE_;
    static Color* YELLOW_;
    static Color* black_;
    static Color* blue_;
    ::java::awt::color::ColorSpace* cs {  };
    static Color* cyan_;
    static Color* darkGray_;
    float falpha {  };
    ::floatArray* frgbvalue {  };
    ::floatArray* fvalue {  };
    static Color* gray_;
    static Color* green_;
    static Color* lightGray_;
    static Color* magenta_;
    static Color* orange_;
    static Color* pink_;
    static Color* red_;
    static constexpr int64_t serialVersionUID { int64_t(118526816881161077LL) };

public: /* package */
    int32_t value {  };

private:
    static Color* white_;
    static Color* yellow_;

protected:
    void ctor(int32_t arg0);
    void ctor(int32_t arg0, bool arg1);
    void ctor(int32_t arg0, int32_t arg1, int32_t arg2);
    void ctor(float arg0, float arg1, float arg2);
    void ctor(::java::awt::color::ColorSpace* arg0, ::floatArray* arg1, float arg2);
    void ctor(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3);
    void ctor(float arg0, float arg1, float arg2, float arg3);

public:
    static int32_t HSBtoRGB(float arg0, float arg1, float arg2);
    static ::floatArray* RGBtoHSB(int32_t arg0, int32_t arg1, int32_t arg2, ::floatArray* arg3);
    virtual Color* brighter();
    PaintContext* createContext(::java::awt::image::ColorModel* arg0, Rectangle* arg1, ::java::awt::geom::Rectangle2D* arg2, ::java::awt::geom::AffineTransform* arg3, RenderingHints* arg4) override;
    virtual Color* darker();
    static Color* decode(::java::lang::String* arg0);
    bool equals(::java::lang::Object* arg0) override;
    virtual int32_t getAlpha();
    virtual int32_t getBlue();
    static Color* getColor(::java::lang::String* arg0);
    static Color* getColor(::java::lang::String* arg0, Color* arg1);
    static Color* getColor(::java::lang::String* arg0, int32_t arg1);
    virtual ::floatArray* getColorComponents(::floatArray* arg0);
    virtual ::floatArray* getColorComponents(::java::awt::color::ColorSpace* arg0, ::floatArray* arg1);
    virtual ::java::awt::color::ColorSpace* getColorSpace();
    virtual ::floatArray* getComponents(::floatArray* arg0);
    virtual ::floatArray* getComponents(::java::awt::color::ColorSpace* arg0, ::floatArray* arg1);
    virtual int32_t getGreen();
    static Color* getHSBColor(float arg0, float arg1, float arg2);
    virtual int32_t getRGB();
    virtual ::floatArray* getRGBColorComponents(::floatArray* arg0);
    virtual ::floatArray* getRGBComponents(::floatArray* arg0);
    virtual int32_t getRed();
    int32_t getTransparency() override;
    int32_t hashCode() override;
    /*static void initIDs(); (private) */
    /*static void testColorValueRange(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3); (private) */
    /*static void testColorValueRange(float arg0, float arg1, float arg2, float arg3); (private) */
    ::java::lang::String* toString() override;

    // Generated
    Color(int32_t arg0);
    Color(int32_t arg0, bool arg1);
    Color(int32_t arg0, int32_t arg1, int32_t arg2);
    Color(float arg0, float arg1, float arg2);
    Color(::java::awt::color::ColorSpace* arg0, ::floatArray* arg1, float arg2);
    Color(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3);
    Color(float arg0, float arg1, float arg2, float arg3);
protected:
    Color(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    static Color*& BLACK();
    static Color*& BLUE();
    static Color*& CYAN();
    static Color*& DARK_GRAY();
    static Color*& GRAY();
    static Color*& GREEN();
    static Color*& LIGHT_GRAY();
    static Color*& MAGENTA();
    static Color*& ORANGE();
    static Color*& PINK();
    static Color*& RED();
    static Color*& WHITE();
    static Color*& YELLOW();
    static Color*& black();
    static Color*& blue();
    static Color*& cyan();
    static Color*& darkGray();
    static Color*& gray();
    static Color*& green();
    static Color*& lightGray();
    static Color*& magenta();
    static Color*& orange();
    static Color*& pink();
    static Color*& red();
    static Color*& white();
    static Color*& yellow();

private:
    virtual ::java::lang::Class* getClass0();
};
