// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <sun/java2d/pipe/hw/ExtendedBufferCapabilities.hpp>

struct default_init_tag;

class java::awt::Component_ProxyCapabilities
    : public ::sun::java2d::pipe::hw::ExtendedBufferCapabilities
{

public:
    typedef ::sun::java2d::pipe::hw::ExtendedBufferCapabilities super;

private:
    BufferCapabilities* orig {  };

public: /* package */
    Component* this$0 {  };

    /*void ctor(BufferCapabilities* arg0); (private) */

    // Generated

public:
    Component_ProxyCapabilities(Component *Component_this);
protected:
    Component_ProxyCapabilities(Component *Component_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    Component *Component_this;

private:
    virtual ::java::lang::Class* getClass0();
};
