// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct java::awt::Adjustable
    : public virtual ::java::lang::Object
{
    static constexpr int32_t HORIZONTAL { int32_t(0) };
    static constexpr int32_t NO_ORIENTATION { int32_t(2) };
    static constexpr int32_t VERTICAL { int32_t(1) };

    virtual void addAdjustmentListener(::java::awt::event::AdjustmentListener* arg0) = 0;
    virtual int32_t getBlockIncrement() = 0;
    virtual int32_t getMaximum() = 0;
    virtual int32_t getMinimum() = 0;
    virtual int32_t getOrientation() = 0;
    virtual int32_t getUnitIncrement() = 0;
    virtual int32_t getValue() = 0;
    virtual int32_t getVisibleAmount() = 0;
    virtual void removeAdjustmentListener(::java::awt::event::AdjustmentListener* arg0) = 0;
    virtual void setBlockIncrement(int32_t arg0) = 0;
    virtual void setMaximum(int32_t arg0) = 0;
    virtual void setMinimum(int32_t arg0) = 0;
    virtual void setUnitIncrement(int32_t arg0) = 0;
    virtual void setValue(int32_t arg0) = 0;
    virtual void setVisibleAmount(int32_t arg0) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
