// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <atomic>
#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/geom/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/im/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/image/fwd-CS3502-OsProject-master.hpp>
#include <java/beans/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/ref/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <java/util/concurrent/atomic/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <sun/awt/fwd-CS3502-OsProject-master.hpp>
#include <sun/awt/util/fwd-CS3502-OsProject-master.hpp>
#include <sun/java2d/pipe/fwd-CS3502-OsProject-master.hpp>
#include <sun/util/logging/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/Container.hpp>
#include <javax/accessibility/Accessible.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace awt
    {
        namespace image
        {
typedef ::SubArray< ::java::awt::image::ImageObserver, ::java::lang::ObjectArray > ImageObserverArray;
        } // image
typedef ::SubArray< ::java::awt::MenuContainer, ::java::lang::ObjectArray > MenuContainerArray;
    } // awt

    namespace io
    {
typedef ::SubArray< ::java::io::Serializable, ::java::lang::ObjectArray > SerializableArray;
    } // io

    namespace awt
    {
typedef ::SubArray< ::java::awt::Component, ::java::lang::ObjectArray, ::java::awt::image::ImageObserverArray, MenuContainerArray, ::java::io::SerializableArray > ComponentArray;
typedef ::SubArray< ::java::awt::Container, ComponentArray > ContainerArray;
    } // awt
} // java

namespace javax
{
    namespace accessibility
    {
typedef ::SubArray< ::javax::accessibility::Accessible, ::java::lang::ObjectArray > AccessibleArray;
    } // accessibility
} // javax

namespace java
{
    namespace awt
    {
typedef ::SubArray< ::java::awt::Window, ContainerArray, ::javax::accessibility::AccessibleArray > WindowArray;
    } // awt

    namespace util
    {
typedef ::SubArray< ::java::util::EventListener, ::java::lang::ObjectArray > EventListenerArray;
    } // util

    namespace awt
    {
        namespace event
        {
typedef ::SubArray< ::java::awt::event::WindowFocusListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > WindowFocusListenerArray;
typedef ::SubArray< ::java::awt::event::WindowListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > WindowListenerArray;
typedef ::SubArray< ::java::awt::event::WindowStateListener, ::java::lang::ObjectArray, ::java::util::EventListenerArray > WindowStateListenerArray;
        } // event
    } // awt
} // java

struct default_init_tag;

class java::awt::Window
    : public Container
    , public virtual ::javax::accessibility::Accessible
{

public:
    typedef Container super;

public: /* package */
    static constexpr int32_t OPENED { int32_t(1) };

private:
    static ::sun::awt::util::IdentityArrayList* allWindows_;
    bool alwaysOnTop {  };

public: /* package */
    ::java::lang::Object* anchor {  };

private:
    std::atomic< bool > autoRequestFocus {  };
    static ::java::lang::String* base_;

public: /* package */
    bool beforeFirstShow {  };

private:
    static ::java::util::concurrent::atomic::AtomicBoolean* beforeFirstWindowShown_;

public: /* package */
    Window_WindowDisposerRecord* disposerRecord {  };

private:
    bool disposing {  };
    FocusManager* focusMgr {  };
    bool focusableWindowState {  };

public: /* package */
    ::java::util::List* icons {  };
    ::java::awt::im::InputContext* inputContext {  };

private:
    ::java::lang::Object* inputContextLock {  };

public: /* package */
    bool isInShow {  };
    bool isTrayIconWindow {  };

private:
    std::atomic< bool > locationByPlatform {  };
    static bool locationByPlatformProp_;
    static ::sun::util::logging::PlatformLogger* log_;

public: /* package */
    Dialog* modalBlocker {  };
    Dialog_ModalExclusionType* modalExclusionType {  };

private:
    static int32_t nameCounter_;
    std::atomic< float > opacity {  };

public: /* package */
    ::java::util::Vector* ownedWindowList {  };

private:
    float securityWarningAlignmentX {  };
    float securityWarningAlignmentY {  };
    std::atomic< int32_t > securityWarningHeight {  };
    double securityWarningPointX {  };
    double securityWarningPointY {  };
    std::atomic< int32_t > securityWarningWidth {  };
    static constexpr int64_t serialVersionUID { int64_t(4497834738069338734LL) };
    Shape* shape {  };

public: /* package */
    bool showWithParent {  };
    int32_t state {  };
    bool syncLWRequests {  };

private:
    static bool systemSyncLWRequests_;
    Component* temporaryLostComponent {  };
    Window_Type* type {  };

public: /* package */
    ::java::lang::String* warningString {  };

private:
    ::java::lang::ref::WeakReference* weakThis {  };

public: /* package */
    ::java::awt::event::WindowFocusListener* windowFocusListener {  };
    ::java::awt::event::WindowListener* windowListener {  };

private:
    int32_t windowSerializedDataVersion {  };

public: /* package */
    ::java::awt::event::WindowStateListener* windowStateListener {  };

protected:
    void ctor();
    void ctor(GraphicsConfiguration* arg0);
    void ctor(Frame* arg0);
    void ctor(Window* arg0);
    void ctor(Window* arg0, GraphicsConfiguration* arg1);

public:
    void addNotify() override;

public: /* package */
    virtual void addOwnedWindow(::java::lang::ref::WeakReference* arg0);

public:
    void addPropertyChangeListener(::java::beans::PropertyChangeListener* arg0) override;
    void addPropertyChangeListener(::java::lang::String* arg0, ::java::beans::PropertyChangeListener* arg1) override;
    /*void addToWindowList(); (private) */
    virtual void addWindowFocusListener(::java::awt::event::WindowFocusListener* arg0);
    virtual void addWindowListener(::java::awt::event::WindowListener* arg0);
    virtual void addWindowStateListener(::java::awt::event::WindowStateListener* arg0);

public: /* package */
    void adjustDecendantsOnParent(int32_t arg0) override;
    void adjustListeningChildrenOnParent(int64_t arg0, int32_t arg1) override;
    void applyCompoundShape(::sun::java2d::pipe::Region* arg0) override;
    void applyCurrentShape() override;

public:
    virtual void applyResourceBundle(::java::util::ResourceBundle* arg0);
    virtual void applyResourceBundle(::java::lang::String* arg0);
    /*::java::awt::geom::Point2D* calculateSecurityWarningPosition(double arg0, double arg1, double arg2, double arg3); (private) */

public: /* package */
    bool canContainFocusOwner(Component* arg0) override;
    void clearMostRecentFocusOwnerOnHide() override;
    void closeSplashScreen();
    virtual void connectOwnedWindow(Window* arg0);
    ::java::lang::String* constructComponentName() override;

public:
    void createBufferStrategy(int32_t arg0) override;
    void createBufferStrategy(int32_t arg0, BufferCapabilities* arg1) override;

public: /* package */
    virtual void deliverMouseWheelToAncestor(::java::awt::event::MouseWheelEvent* arg0);
    /*void deserializeResources(::java::io::ObjectInputStream* arg0); (private) */
    void dispatchEventImpl(AWTEvent* arg0) override;
    bool dispatchMouseWheelToAncestor(::java::awt::event::MouseWheelEvent* arg0) override;

public:
    virtual void dispose();

public: /* package */
    virtual void disposeImpl();
    virtual void doDispose();
    bool eventEnabled(AWTEvent* arg0) override;

public:
    ::javax::accessibility::AccessibleContext* getAccessibleContext() override;

public: /* package */
    static ::sun::awt::util::IdentityArrayList* getAllUnblockedWindows();
    static ::sun::awt::util::IdentityArrayList* getAllWindows();

public:
    Color* getBackground() override;
    ::java::awt::image::BufferStrategy* getBufferStrategy() override;

public: /* package */
    Container* getContainer() override;
    virtual Window* getDocumentRoot();

public:
    Container* getFocusCycleRootAncestor() override;
    virtual Component* getFocusOwner();
    ::java::util::Set* getFocusTraversalKeys(int32_t arg0) override;
    virtual bool getFocusableWindowState();
    virtual ::java::util::List* getIconImages();
    ::java::awt::im::InputContext* getInputContext() override;
    ::java::util::EventListenerArray* getListeners(::java::lang::Class* arg0) override;
    ::java::util::Locale* getLocale() override;

public: /* package */
    Point* getLocationOnWindow() override;
    virtual Dialog* getModalBlocker();

public:
    virtual Dialog_ModalExclusionType* getModalExclusionType();
    virtual Component* getMostRecentFocusOwner();
    virtual float getOpacity();
    virtual WindowArray* getOwnedWindows();

public: /* package */
    WindowArray* getOwnedWindows_NoClientCode();

public:
    virtual Window* getOwner();

public: /* package */
    Window* getOwner_NoClientCode();

public:
    static WindowArray* getOwnerlessWindows();
    virtual Shape* getShape();

public: /* package */
    virtual Component* getTemporaryLostComponent();

public:
    Toolkit* getToolkit() override;
    virtual Window_Type* getType();
    ::java::lang::String* getWarningString();
    virtual ::java::awt::event::WindowFocusListenerArray* getWindowFocusListeners();
    virtual ::java::awt::event::WindowListenerArray* getWindowListeners();
    virtual ::java::awt::event::WindowStateListenerArray* getWindowStateListeners();
    static WindowArray* getWindows();
    /*static WindowArray* getWindows(::sun::awt::AppContext* arg0); (private) */
    void hide() override;
    /*void init_(GraphicsConfiguration* arg0); (private) */
    /*void initDeserializedWindow(); (private) */
    /*GraphicsConfiguration* initGC(GraphicsConfiguration* arg0); (private) */
    /*static void initIDs(); (private) */
    virtual bool isActive();
    bool isAlwaysOnTop();
    virtual bool isAlwaysOnTopSupported();
    virtual bool isAutoRequestFocus();

public: /* package */
    virtual bool isDisposing();

public:
    bool isFocusCycleRoot() override;
    bool isFocusableWindow();
    virtual bool isFocused();
    virtual bool isLocationByPlatform();

public: /* package */
    virtual bool isModalBlocked();
    virtual bool isModalExcluded(Dialog_ModalExclusionType* arg0);

public:
    bool isOpaque() override;

public: /* package */
    bool isRecursivelyVisible() override;

public:
    bool isShowing() override;
    bool isValidateRoot() override;
    /*static double limit(double arg0, double arg1, double arg2); (private) */

public: /* package */
    void mixOnReshaping() override;
    /*void ownedInit(Window* arg0); (private) */

public:
    virtual void pack();
    void paint(Graphics* arg0) override;
    bool postEvent(Event* arg0) override;

public: /* package */
    void postProcessKeyEvent(::java::awt::event::KeyEvent* arg0) override;
    virtual void postWindowEvent(int32_t arg0);
    void preProcessKeyEvent(::java::awt::event::KeyEvent* arg0) override;

public: /* protected */
    void processEvent(AWTEvent* arg0) override;
    virtual void processWindowEvent(::java::awt::event::WindowEvent* arg0);
    virtual void processWindowFocusEvent(::java::awt::event::WindowEvent* arg0);
    virtual void processWindowStateEvent(::java::awt::event::WindowEvent* arg0);
    /*void readObject(::java::io::ObjectInputStream* arg0); (private) */
    /*void removeFromWindowList(); (private) */
    /*static void removeFromWindowList(::sun::awt::AppContext* arg0, ::java::lang::ref::WeakReference* arg1); (private) */

public:
    void removeNotify() override;

public: /* package */
    virtual void removeOwnedWindow(::java::lang::ref::WeakReference* arg0);

public:
    virtual void removeWindowFocusListener(::java::awt::event::WindowFocusListener* arg0);
    virtual void removeWindowListener(::java::awt::event::WindowListener* arg0);
    virtual void removeWindowStateListener(::java::awt::event::WindowStateListener* arg0);
    void reshape(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3) override;
    void setAlwaysOnTop(bool arg0);
    virtual void setAutoRequestFocus(bool arg0);
    void setBackground(Color* arg0) override;
    void setBounds(Rectangle* arg0) override;
    void setBounds(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3) override;

public: /* package */
    virtual void setClientSize(int32_t arg0, int32_t arg1);

public:
    void setCursor(Cursor* arg0) override;
    void setFocusCycleRoot(bool arg0) override;
    virtual void setFocusableWindowState(bool arg0);

public: /* package */
    void setGraphicsConfiguration(GraphicsConfiguration* arg0) override;

public:
    virtual void setIconImage(Image* arg0);
    virtual void setIconImages(::java::util::List* arg0);
    /*static void setLayersOpaque(Component* arg0, bool arg1); (private) */
    void setLocation(Point* arg0) override;
    void setLocation(int32_t arg0, int32_t arg1) override;
    virtual void setLocationByPlatform(bool arg0);
    virtual void setLocationRelativeTo(Component* arg0);
    void setMinimumSize(Dimension* arg0) override;

public: /* package */
    virtual void setModalBlocked(Dialog* arg0, bool arg1, bool arg2);

public:
    virtual void setModalExclusionType(Dialog_ModalExclusionType* arg0);
    virtual void setOpacity(float arg0);
    /*void setOwnedWindowsAlwaysOnTop(bool arg0); (private) */
    virtual void setShape(Shape* arg0);
    void setSize(Dimension* arg0) override;
    void setSize(int32_t arg0, int32_t arg1) override;

public: /* package */
    virtual Component* setTemporaryLostComponent(Component* arg0);

public:
    virtual void setType(Window_Type* arg0);
    void setVisible(bool arg0) override;
    /*void setWarningString(); (private) */
    void show() override;
    virtual void toBack();

public: /* package */
    void toBack_NoClientCode();

public:
    virtual void toFront();

public: /* package */
    void toFront_NoClientCode();
    static void updateChildFocusableWindowState(Window* arg0);
    virtual void updateChildrenBlocking();
    /*void updateWindow(); (private) */
    void updateZOrder() override;
    /*void writeObject(::java::io::ObjectOutputStream* arg0); (private) */

    // Generated
    Window();
    Window(GraphicsConfiguration* arg0);

public:
    Window(Frame* arg0);
    Window(Window* arg0);
    Window(Window* arg0, GraphicsConfiguration* arg1);
protected:
    Window(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    bool isFocusCycleRoot(Container* arg0);
    virtual void show(bool arg0);

private:
    static ::sun::awt::util::IdentityArrayList*& allWindows();
    static ::java::lang::String*& base();
    static ::java::util::concurrent::atomic::AtomicBoolean*& beforeFirstWindowShown();
    static bool& locationByPlatformProp();
    static ::sun::util::logging::PlatformLogger*& log();
    static int32_t& nameCounter();

public: /* package */
    static bool& systemSyncLWRequests();

private:
    virtual ::java::lang::Class* getClass0();
};
