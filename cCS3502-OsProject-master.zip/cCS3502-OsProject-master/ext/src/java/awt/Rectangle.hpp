// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/geom/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/geom/Rectangle2D.hpp>
#include <java/awt/Shape.hpp>
#include <java/io/Serializable.hpp>

struct default_init_tag;

class java::awt::Rectangle
    : public ::java::awt::geom::Rectangle2D
    , public virtual Shape
    , public virtual ::java::io::Serializable
{

public:
    typedef ::java::awt::geom::Rectangle2D super;
    int32_t height {  };

private:
    static constexpr int64_t serialVersionUID { int64_t(-4345857070255674764LL) };

public:
    int32_t width {  };
    int32_t x {  };
    int32_t y {  };

protected:
    void ctor();
    void ctor(Rectangle* arg0);
    void ctor(Point* arg0);
    void ctor(Dimension* arg0);
    void ctor(int32_t arg0, int32_t arg1);
    void ctor(Point* arg0, Dimension* arg1);
    void ctor(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3);

public:
    virtual void add(Point* arg0);
    virtual void add(Rectangle* arg0);
    virtual void add(int32_t arg0, int32_t arg1);
    /*static int32_t clip(double arg0, bool arg1); (private) */
    virtual bool contains(Point* arg0);
    virtual bool contains(Rectangle* arg0);
    virtual bool contains(int32_t arg0, int32_t arg1);
    virtual bool contains(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3);
    ::java::awt::geom::Rectangle2D* createIntersection(::java::awt::geom::Rectangle2D* arg0) override;
    ::java::awt::geom::Rectangle2D* createUnion(::java::awt::geom::Rectangle2D* arg0) override;
    bool equals(::java::lang::Object* arg0) override;
    Rectangle* getBounds() override;
    ::java::awt::geom::Rectangle2D* getBounds2D() override;
    double getHeight() override;
    virtual Point* getLocation();
    virtual Dimension* getSize();
    double getWidth() override;
    double getX() override;
    double getY() override;
    virtual void grow(int32_t arg0, int32_t arg1);
    /*static void initIDs(); (private) */
    virtual bool inside(int32_t arg0, int32_t arg1);
    virtual Rectangle* intersection(Rectangle* arg0);
    virtual bool intersects(Rectangle* arg0);
    bool isEmpty() override;
    virtual void move(int32_t arg0, int32_t arg1);
    int32_t outcode(double arg0, double arg1) override;
    virtual void reshape(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3);
    virtual void resize(int32_t arg0, int32_t arg1);
    virtual void setBounds(Rectangle* arg0);
    virtual void setBounds(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3);
    virtual void setLocation(Point* arg0);
    virtual void setLocation(int32_t arg0, int32_t arg1);
    void setRect(double arg0, double arg1, double arg2, double arg3) override;
    virtual void setSize(Dimension* arg0);
    virtual void setSize(int32_t arg0, int32_t arg1);
    ::java::lang::String* toString() override;
    virtual void translate(int32_t arg0, int32_t arg1);
    virtual Rectangle* union_(Rectangle* arg0);

    // Generated
    Rectangle();
    Rectangle(Rectangle* arg0);
    Rectangle(Point* arg0);
    Rectangle(Dimension* arg0);
    Rectangle(int32_t arg0, int32_t arg1);
    Rectangle(Point* arg0, Dimension* arg1);
    Rectangle(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3);
protected:
    Rectangle(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    virtual bool contains(double arg0, double arg1);
    virtual bool contains(double arg0, double arg1, double arg2, double arg3);
    virtual bool contains(::java::awt::geom::Point2D* arg0);
    virtual bool contains(::java::awt::geom::Rectangle2D* arg0);
    virtual ::java::awt::geom::PathIterator* getPathIterator(::java::awt::geom::AffineTransform* arg0);
    virtual ::java::awt::geom::PathIterator* getPathIterator(::java::awt::geom::AffineTransform* arg0, double arg1);
    virtual bool intersects(double arg0, double arg1, double arg2, double arg3);
    virtual bool intersects(::java::awt::geom::Rectangle2D* arg0);
    virtual void add(::java::awt::geom::Point2D* arg0);
    virtual void add(::java::awt::geom::Rectangle2D* arg0);
    virtual void add(double arg0, double arg1);
    virtual int32_t outcode(::java::awt::geom::Point2D* arg0);
    virtual void setRect(::java::awt::geom::Rectangle2D* arg0);
    static void union_(::java::awt::geom::Rectangle2D* arg0, ::java::awt::geom::Rectangle2D* arg1, ::java::awt::geom::Rectangle2D* arg2);

private:
    virtual ::java::lang::Class* getClass0();
};
