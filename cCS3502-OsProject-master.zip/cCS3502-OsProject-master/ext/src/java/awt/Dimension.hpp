// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/geom/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/geom/Dimension2D.hpp>
#include <java/io/Serializable.hpp>

struct default_init_tag;

class java::awt::Dimension
    : public ::java::awt::geom::Dimension2D
    , public virtual ::java::io::Serializable
{

public:
    typedef ::java::awt::geom::Dimension2D super;
    int32_t height {  };

private:
    static constexpr int64_t serialVersionUID { int64_t(4723952579491349524LL) };

public:
    int32_t width {  };

protected:
    void ctor();
    void ctor(Dimension* arg0);
    void ctor(int32_t arg0, int32_t arg1);

public:
    bool equals(::java::lang::Object* arg0) override;
    double getHeight() override;
    virtual Dimension* getSize();
    double getWidth() override;
    int32_t hashCode() override;
    /*static void initIDs(); (private) */
    virtual void setSize(Dimension* arg0);
    void setSize(double arg0, double arg1) override;
    virtual void setSize(int32_t arg0, int32_t arg1);
    ::java::lang::String* toString() override;

    // Generated
    Dimension();
    Dimension(Dimension* arg0);
    Dimension(int32_t arg0, int32_t arg1);
protected:
    Dimension(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    virtual void setSize(::java::awt::geom::Dimension2D* arg0);

private:
    virtual ::java::lang::Class* getClass0();
};
