// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/LayoutManager.hpp>

struct java::awt::LayoutManager2
    : public virtual LayoutManager
{

    virtual void addLayoutComponent(Component* arg0, ::java::lang::Object* arg1) = 0;
    virtual float getLayoutAlignmentX(Container* arg0) = 0;
    virtual float getLayoutAlignmentY(Container* arg0) = 0;
    virtual void invalidateLayout(Container* arg0) = 0;
    virtual Dimension* maximumLayoutSize(Container* arg0) = 0;

    // Generated
    static ::java::lang::Class *class_();
    virtual void addLayoutComponent(::java::lang::String* arg0, Component* arg1) = 0;
};
