// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/datatransfer/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace io
    {
typedef ::SubArray< ::java::io::Serializable, ::java::lang::ObjectArray > SerializableArray;
typedef ::SubArray< ::java::io::Externalizable, ::java::lang::ObjectArray, SerializableArray > ExternalizableArray;
    } // io

    namespace lang
    {
typedef ::SubArray< ::java::lang::Cloneable, ObjectArray > CloneableArray;
    } // lang

    namespace awt
    {
        namespace datatransfer
        {
typedef ::SubArray< ::java::awt::datatransfer::DataFlavor, ::java::lang::ObjectArray, ::java::io::ExternalizableArray, ::java::lang::CloneableArray > DataFlavorArray;
        } // datatransfer
    } // awt
} // java

struct java::awt::datatransfer::Transferable
    : public virtual ::java::lang::Object
{

    virtual ::java::lang::Object* getTransferData(DataFlavor* arg0) = 0;
    virtual DataFlavorArray* getTransferDataFlavors() = 0;
    virtual bool isDataFlavorSupported(DataFlavor* arg0) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
