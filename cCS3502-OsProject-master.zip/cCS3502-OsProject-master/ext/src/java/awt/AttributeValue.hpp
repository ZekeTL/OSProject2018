// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <sun/util/logging/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace io
    {
typedef ::SubArray< ::java::io::Serializable, ::java::lang::ObjectArray > SerializableArray;
    } // io

    namespace lang
    {
typedef ::SubArray< ::java::lang::CharSequence, ObjectArray > CharSequenceArray;
typedef ::SubArray< ::java::lang::Comparable, ObjectArray > ComparableArray;
typedef ::SubArray< ::java::lang::String, ObjectArray, ::java::io::SerializableArray, ComparableArray, CharSequenceArray > StringArray;
    } // lang
} // java

struct default_init_tag;

class java::awt::AttributeValue
    : public virtual ::java::lang::Object
{

public:
    typedef ::java::lang::Object super;

private:
    static ::sun::util::logging::PlatformLogger* log_;
    ::java::lang::StringArray* names {  };
    int32_t value {  };

protected:
    void ctor(int32_t arg0, ::java::lang::StringArray* arg1);

public:
    int32_t hashCode() override;
    ::java::lang::String* toString() override;

    // Generated

public: /* protected */
    AttributeValue(int32_t arg0, ::java::lang::StringArray* arg1);
protected:
    AttributeValue(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    static ::sun::util::logging::PlatformLogger*& log();
    virtual ::java::lang::Class* getClass0();
};
