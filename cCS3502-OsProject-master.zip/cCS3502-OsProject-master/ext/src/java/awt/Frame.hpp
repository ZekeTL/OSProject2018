// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/image/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <javax/accessibility/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/Window.hpp>
#include <java/awt/MenuContainer.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace awt
    {
        namespace image
        {
typedef ::SubArray< ::java::awt::image::ImageObserver, ::java::lang::ObjectArray > ImageObserverArray;
        } // image
typedef ::SubArray< ::java::awt::MenuContainer, ::java::lang::ObjectArray > MenuContainerArray;
    } // awt

    namespace io
    {
typedef ::SubArray< ::java::io::Serializable, ::java::lang::ObjectArray > SerializableArray;
    } // io

    namespace awt
    {
typedef ::SubArray< ::java::awt::Component, ::java::lang::ObjectArray, ::java::awt::image::ImageObserverArray, MenuContainerArray, ::java::io::SerializableArray > ComponentArray;
typedef ::SubArray< ::java::awt::Container, ComponentArray > ContainerArray;
    } // awt
} // java

namespace javax
{
    namespace accessibility
    {
typedef ::SubArray< ::javax::accessibility::Accessible, ::java::lang::ObjectArray > AccessibleArray;
    } // accessibility
} // javax

namespace java
{
    namespace awt
    {
typedef ::SubArray< ::java::awt::Window, ContainerArray, ::javax::accessibility::AccessibleArray > WindowArray;
typedef ::SubArray< ::java::awt::Frame, WindowArray, MenuContainerArray > FrameArray;
    } // awt
} // java

struct default_init_tag;

class java::awt::Frame
    : public Window
    , public virtual MenuContainer
{

public:
    typedef Window super;
    static constexpr int32_t CROSSHAIR_CURSOR { int32_t(1) };
    static constexpr int32_t DEFAULT_CURSOR { int32_t(0) };
    static constexpr int32_t E_RESIZE_CURSOR { int32_t(11) };
    static constexpr int32_t HAND_CURSOR { int32_t(12) };
    static constexpr int32_t ICONIFIED { int32_t(1) };
    static constexpr int32_t MAXIMIZED_BOTH { int32_t(6) };
    static constexpr int32_t MAXIMIZED_HORIZ { int32_t(2) };
    static constexpr int32_t MAXIMIZED_VERT { int32_t(4) };
    static constexpr int32_t MOVE_CURSOR { int32_t(13) };
    static constexpr int32_t NE_RESIZE_CURSOR { int32_t(7) };
    static constexpr int32_t NORMAL { int32_t(0) };
    static constexpr int32_t NW_RESIZE_CURSOR { int32_t(6) };
    static constexpr int32_t N_RESIZE_CURSOR { int32_t(8) };
    static constexpr int32_t SE_RESIZE_CURSOR { int32_t(5) };
    static constexpr int32_t SW_RESIZE_CURSOR { int32_t(4) };
    static constexpr int32_t S_RESIZE_CURSOR { int32_t(9) };
    static constexpr int32_t TEXT_CURSOR { int32_t(2) };
    static constexpr int32_t WAIT_CURSOR { int32_t(3) };
    static constexpr int32_t W_RESIZE_CURSOR { int32_t(10) };

private:
    static ::java::lang::String* base_;
    int32_t frameSerializedDataVersion {  };

public: /* package */
    Rectangle* maximizedBounds {  };
    bool mbManagement {  };
    MenuBar* menuBar {  };

private:
    static int32_t nameCounter_;

public: /* package */
    ::java::util::Vector* ownedWindows {  };
    bool resizable {  };

private:
    static constexpr int64_t serialVersionUID { int64_t(2673458971256075116LL) };
    int32_t state {  };

public: /* package */
    ::java::lang::String* title {  };
    bool undecorated {  };

protected:
    void ctor();
    void ctor(GraphicsConfiguration* arg0);
    void ctor(::java::lang::String* arg0);
    void ctor(::java::lang::String* arg0, GraphicsConfiguration* arg1);

public:
    void addNotify() override;

public: /* package */
    ::java::lang::String* constructComponentName() override;

public:
    ::javax::accessibility::AccessibleContext* getAccessibleContext() override;
    virtual int32_t getCursorType();
    virtual int32_t getExtendedState();
    static FrameArray* getFrames();
    virtual Image* getIconImage();
    virtual Rectangle* getMaximizedBounds();
    virtual MenuBar* getMenuBar();
    virtual int32_t getState();
    virtual ::java::lang::String* getTitle();
    /*void init_(::java::lang::String* arg0, GraphicsConfiguration* arg1); (private) */
    /*static void initIDs(); (private) */
    /*bool isFrameStateSupported(int32_t arg0); (private) */
    virtual bool isResizable();
    virtual bool isUndecorated();

public: /* protected */
    ::java::lang::String* paramString() override;

public: /* package */
    void postProcessKeyEvent(::java::awt::event::KeyEvent* arg0) override;
    /*void readObject(::java::io::ObjectInputStream* arg0); (private) */

public:
    void remove(MenuComponent* arg0) override;
    void removeNotify() override;
    void setBackground(Color* arg0) override;
    virtual void setCursor(int32_t arg0);
    virtual void setExtendedState(int32_t arg0);
    void setIconImage(Image* arg0) override;
    virtual void setMaximizedBounds(Rectangle* arg0);
    virtual void setMenuBar(MenuBar* arg0);
    void setOpacity(float arg0) override;
    virtual void setResizable(bool arg0);
    void setShape(Shape* arg0) override;
    virtual void setState(int32_t arg0);
    virtual void setTitle(::java::lang::String* arg0);
    virtual void setUndecorated(bool arg0);
    /*void writeObject(::java::io::ObjectOutputStream* arg0); (private) */

    // Generated
    Frame();
    Frame(GraphicsConfiguration* arg0);
    Frame(::java::lang::String* arg0);
    Frame(::java::lang::String* arg0, GraphicsConfiguration* arg1);
protected:
    Frame(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    virtual Font* getFont();
    virtual bool postEvent(Event* arg0);
    void setCursor(Cursor* arg0);
    virtual void remove(int32_t arg0);
    virtual void remove(Component* arg0);

private:
    static ::java::lang::String*& base();
    static int32_t& nameCounter();
    virtual ::java::lang::Class* getClass0();
};
