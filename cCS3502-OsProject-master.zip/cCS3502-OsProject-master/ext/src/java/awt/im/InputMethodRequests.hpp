// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/font/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/im/fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/text/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

template<typename ComponentType, typename... Bases> struct SubArray;
namespace java
{
    namespace io
    {
typedef ::SubArray< ::java::io::Serializable, ::java::lang::ObjectArray > SerializableArray;
    } // io

    namespace text
    {
typedef ::SubArray< ::java::text::AttributedCharacterIterator_Attribute, ::java::lang::ObjectArray, ::java::io::SerializableArray > AttributedCharacterIterator_AttributeArray;
    } // text
} // java

struct java::awt::im::InputMethodRequests
    : public virtual ::java::lang::Object
{

    virtual ::java::text::AttributedCharacterIterator* cancelLatestCommittedText(::java::text::AttributedCharacterIterator_AttributeArray* arg0) = 0;
    virtual ::java::text::AttributedCharacterIterator* getCommittedText(int32_t arg0, int32_t arg1, ::java::text::AttributedCharacterIterator_AttributeArray* arg2) = 0;
    virtual int32_t getCommittedTextLength() = 0;
    virtual int32_t getInsertPositionOffset() = 0;
    virtual ::java::awt::font::TextHitInfo* getLocationOffset(int32_t arg0, int32_t arg1) = 0;
    virtual ::java::text::AttributedCharacterIterator* getSelectedText(::java::text::AttributedCharacterIterator_AttributeArray* arg0) = 0;
    virtual ::java::awt::Rectangle* getTextLocation(::java::awt::font::TextHitInfo* arg0) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
