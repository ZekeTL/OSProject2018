// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/ref/fwd-CS3502-OsProject-master.hpp>
#include <sun/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <sun/java2d/DisposerRecord.hpp>

struct default_init_tag;

class java::awt::Window_WindowDisposerRecord
    : public virtual ::java::lang::Object
    , public virtual ::sun::java2d::DisposerRecord
{

public:
    typedef ::java::lang::Object super;

public: /* package */
    ::java::lang::ref::WeakReference* context {  };
    ::java::lang::ref::WeakReference* owner {  };
    ::java::lang::ref::WeakReference* weakThis {  };

protected:
    void ctor(::sun::awt::AppContext* arg0, Window* arg1);

public:
    void dispose() override;
    virtual void updateOwner();

    // Generated

public: /* package */
    Window_WindowDisposerRecord(::sun::awt::AppContext* arg0, Window* arg1);
protected:
    Window_WindowDisposerRecord(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
