// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/print/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct java::awt::print::Printable
    : public virtual ::java::lang::Object
{
    static constexpr int32_t NO_SUCH_PAGE { int32_t(1) };
    static constexpr int32_t PAGE_EXISTS { int32_t(0) };

    virtual int32_t print(::java::awt::Graphics* arg0, PageFormat* arg1, int32_t arg2) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
