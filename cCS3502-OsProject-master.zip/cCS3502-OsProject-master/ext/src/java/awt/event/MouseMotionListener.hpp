// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/util/EventListener.hpp>

struct java::awt::event::MouseMotionListener
    : public virtual ::java::util::EventListener
{

    virtual void mouseDragged(MouseEvent* arg0) = 0;
    virtual void mouseMoved(MouseEvent* arg0) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
