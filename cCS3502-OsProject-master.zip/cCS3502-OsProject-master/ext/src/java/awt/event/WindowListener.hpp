// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/awt/event/fwd-CS3502-OsProject-master.hpp>
#include <java/util/EventListener.hpp>

struct java::awt::event::WindowListener
    : public virtual ::java::util::EventListener
{

    virtual void windowActivated(WindowEvent* arg0) = 0;
    virtual void windowClosed(WindowEvent* arg0) = 0;
    virtual void windowClosing(WindowEvent* arg0) = 0;
    virtual void windowDeactivated(WindowEvent* arg0) = 0;
    virtual void windowDeiconified(WindowEvent* arg0) = 0;
    virtual void windowIconified(WindowEvent* arg0) = 0;
    virtual void windowOpened(WindowEvent* arg0) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
