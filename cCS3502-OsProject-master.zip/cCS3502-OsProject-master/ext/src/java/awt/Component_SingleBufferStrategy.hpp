// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/awt/image/BufferStrategy.hpp>

struct default_init_tag;

class java::awt::Component_SingleBufferStrategy
    : public ::java::awt::image::BufferStrategy
{

public:
    typedef ::java::awt::image::BufferStrategy super;

private:
    BufferCapabilities* caps {  };

public: /* package */
    Component* this$0 {  };

protected:
    void ctor(BufferCapabilities* arg0);

public:
    bool contentsLost() override;
    bool contentsRestored() override;
    BufferCapabilities* getCapabilities() override;
    Graphics* getDrawGraphics() override;
    void show() override;

    // Generated
    Component_SingleBufferStrategy(Component *Component_this, BufferCapabilities* arg0);
protected:
    Component_SingleBufferStrategy(Component *Component_this, const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    Component *Component_this;

private:
    virtual ::java::lang::Class* getClass0();
};
