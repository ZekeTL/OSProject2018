// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/awt/LayoutManager2.hpp>
#include <java/io/Serializable.hpp>

struct default_init_tag;

class java::awt::BorderLayout
    : public virtual ::java::lang::Object
    , public virtual LayoutManager2
    , public virtual ::java::io::Serializable
{

public:
    typedef ::java::lang::Object super;

private:
    static ::java::lang::String* AFTER_LAST_LINE_;
    static ::java::lang::String* AFTER_LINE_ENDS_;
    static ::java::lang::String* BEFORE_FIRST_LINE_;
    static ::java::lang::String* BEFORE_LINE_BEGINS_;
    static ::java::lang::String* CENTER_;
    static ::java::lang::String* EAST_;
    static ::java::lang::String* LINE_END_;
    static ::java::lang::String* LINE_START_;
    static ::java::lang::String* NORTH_;
    static ::java::lang::String* PAGE_END_;
    static ::java::lang::String* PAGE_START_;
    static ::java::lang::String* SOUTH_;
    static ::java::lang::String* WEST_;

public: /* package */
    Component* center {  };
    Component* east {  };
    Component* firstItem {  };
    Component* firstLine {  };
    int32_t hgap {  };
    Component* lastItem {  };
    Component* lastLine {  };
    Component* north {  };

private:
    static constexpr int64_t serialVersionUID { int64_t(-8658291919501921765LL) };

public: /* package */
    Component* south {  };
    int32_t vgap {  };
    Component* west {  };

protected:
    void ctor();
    void ctor(int32_t arg0, int32_t arg1);

public:
    void addLayoutComponent(Component* arg0, ::java::lang::Object* arg1) override;
    void addLayoutComponent(::java::lang::String* arg0, Component* arg1) override;
    /*Component* getChild(::java::lang::String* arg0, bool arg1); (private) */
    virtual ::java::lang::Object* getConstraints(Component* arg0);
    virtual int32_t getHgap();
    float getLayoutAlignmentX(Container* arg0) override;
    float getLayoutAlignmentY(Container* arg0) override;
    virtual Component* getLayoutComponent(::java::lang::Object* arg0);
    virtual Component* getLayoutComponent(Container* arg0, ::java::lang::Object* arg1);
    virtual int32_t getVgap();
    void invalidateLayout(Container* arg0) override;
    void layoutContainer(Container* arg0) override;
    Dimension* maximumLayoutSize(Container* arg0) override;
    Dimension* minimumLayoutSize(Container* arg0) override;
    Dimension* preferredLayoutSize(Container* arg0) override;
    void removeLayoutComponent(Component* arg0) override;
    virtual void setHgap(int32_t arg0);
    virtual void setVgap(int32_t arg0);
    ::java::lang::String* toString() override;

    // Generated
    BorderLayout();
    BorderLayout(int32_t arg0, int32_t arg1);
protected:
    BorderLayout(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    static ::java::lang::String*& AFTER_LAST_LINE();
    static ::java::lang::String*& AFTER_LINE_ENDS();
    static ::java::lang::String*& BEFORE_FIRST_LINE();
    static ::java::lang::String*& BEFORE_LINE_BEGINS();
    static ::java::lang::String*& CENTER();
    static ::java::lang::String*& EAST();
    static ::java::lang::String*& LINE_END();
    static ::java::lang::String*& LINE_START();
    static ::java::lang::String*& NORTH();
    static ::java::lang::String*& PAGE_END();
    static ::java::lang::String*& PAGE_START();
    static ::java::lang::String*& SOUTH();
    static ::java::lang::String*& WEST();

private:
    virtual ::java::lang::Class* getClass0();
};
