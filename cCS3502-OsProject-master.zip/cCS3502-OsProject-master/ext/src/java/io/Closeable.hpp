// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/AutoCloseable.hpp>

struct java::io::Closeable
    : public virtual ::java::lang::AutoCloseable
{

    /*void close(); (already declared) */

    // Generated
    static ::java::lang::Class *class_();
};
