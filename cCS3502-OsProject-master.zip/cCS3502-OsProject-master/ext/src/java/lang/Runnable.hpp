// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct java::lang::Runnable
    : public virtual Object
{

    virtual void run() = 0;

    // Generated
    static ::java::lang::Class *class_();
};
