// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/ref/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Thread.hpp>

struct default_init_tag;

class java::lang::ref::Reference_ReferenceHandler
    : public ::java::lang::Thread
{

public:
    typedef ::java::lang::Thread super;

protected:
    void ctor(::java::lang::ThreadGroup* arg0, ::java::lang::String* arg1);
    /*static void ensureClassInitialized(::java::lang::Class* arg0); (private) */

public:
    void run() override;

    // Generated

public: /* package */
    Reference_ReferenceHandler(::java::lang::ThreadGroup* arg0, ::java::lang::String* arg1);
protected:
    Reference_ReferenceHandler(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
