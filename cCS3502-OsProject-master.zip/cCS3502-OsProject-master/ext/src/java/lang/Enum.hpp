// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/io/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/lang/Comparable.hpp>
#include <java/io/Serializable.hpp>

struct default_init_tag;

class java::lang::Enum
    : public virtual Object
    , public virtual Comparable
    , public virtual ::java::io::Serializable
{

public:
    typedef Object super;

private:
    String* name_ {  };
    int32_t ordinal_ {  };

protected:
    void ctor(String* arg0, int32_t ordinal);

public: /* protected */
    Object* clone() override;

public:
    int32_t compareTo(Enum* o);
    bool equals(Object* other) override;

public: /* protected */
    void finalize() override;

public:
    Class* getDeclaringClass();
    int32_t hashCode() override;
    String* name();
    int32_t ordinal();
    /*void readObject(::java::io::ObjectInputStream* arg0); (private) */
    /*void readObjectNoData(); (private) */
    String* toString() override;
    static Enum* valueOf(Class* enumType, String* name);

    // Generated

public: /* protected */
    Enum(String* name, int32_t ordinal);
protected:
    Enum(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    virtual int32_t compareTo(Object* o) override;

private:
    virtual ::java::lang::Class* getClass0();
};
