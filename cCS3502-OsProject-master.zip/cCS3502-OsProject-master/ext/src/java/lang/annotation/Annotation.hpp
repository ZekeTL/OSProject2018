// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/annotation/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct java::lang::annotation::Annotation
    : public virtual ::java::lang::Object
{

    virtual ::java::lang::Class* annotationType() = 0;
    /*virtual bool equals(::java::lang::Object* arg0); (already declared) */
    /*virtual int32_t hashCode(); (already declared) */
    /*virtual ::java::lang::String* toString(); (already declared) */

    // Generated
    static ::java::lang::Class *class_();
};
