// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct java::lang::Cloneable
    : public virtual Object
{


    // Generated
    static ::java::lang::Class *class_();
};
