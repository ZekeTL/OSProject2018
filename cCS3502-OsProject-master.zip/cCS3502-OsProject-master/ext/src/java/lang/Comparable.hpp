// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct java::lang::Comparable
    : public virtual Object
{

    virtual int32_t compareTo(Object* arg0) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
