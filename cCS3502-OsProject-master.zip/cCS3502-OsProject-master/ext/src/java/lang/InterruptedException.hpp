// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Exception.hpp>

struct default_init_tag;

class java::lang::InterruptedException
    : public Exception
{

public:
    typedef Exception super;

private:
    static constexpr int64_t serialVersionUID { int64_t(6700697376100628473LL) };

protected:
    void ctor();
    void ctor(String* s);

    // Generated

public:
    InterruptedException();
    InterruptedException(String* s);
protected:
    InterruptedException(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
