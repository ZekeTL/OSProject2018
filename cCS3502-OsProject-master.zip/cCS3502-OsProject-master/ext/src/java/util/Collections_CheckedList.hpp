// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <java/util/function/fwd-CS3502-OsProject-master.hpp>
#include <java/util/stream/fwd-CS3502-OsProject-master.hpp>
#include <java/util/Collections_CheckedCollection.hpp>
#include <java/util/List.hpp>

struct default_init_tag;

class java::util::Collections_CheckedList
    : public Collections_CheckedCollection
    , public virtual List
{

public:
    typedef Collections_CheckedCollection super;

public: /* package */
    List* list {  };

private:
    static constexpr int64_t serialVersionUID { int64_t(65247728283967356LL) };

protected:
    void ctor(List* arg0, ::java::lang::Class* arg1);

public:
    void add(int32_t arg0, ::java::lang::Object* arg1) override;
    bool addAll(int32_t arg0, Collection* arg1) override;
    bool equals(::java::lang::Object* arg0) override;
    ::java::lang::Object* get(int32_t arg0) override;
    int32_t hashCode() override;
    int32_t indexOf(::java::lang::Object* arg0) override;
    int32_t lastIndexOf(::java::lang::Object* arg0) override;
    ListIterator* listIterator() override;
    ListIterator* listIterator(int32_t arg0) override;
    ::java::lang::Object* remove(int32_t arg0) override;
    void replaceAll(::java::util::function::UnaryOperator* arg0) override;
    ::java::lang::Object* set(int32_t arg0, ::java::lang::Object* arg1) override;
    void sort(Comparator* arg0) override;
    List* subList(int32_t arg0, int32_t arg1) override;

    // Generated

public: /* package */
    Collections_CheckedList(List* arg0, ::java::lang::Class* arg1);
protected:
    Collections_CheckedList(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    virtual void forEach(::java::util::function::Consumer* arg0);
    virtual ::java::util::stream::Stream* parallelStream();
    virtual bool removeIf(::java::util::function::Predicate* filter);
    virtual ::java::util::stream::Stream* stream();
    bool add(::java::lang::Object* arg0);
    bool addAll(Collection* arg0);
    void clear();
    bool contains(::java::lang::Object* arg0);
    bool containsAll(Collection* arg0);
    bool isEmpty();
    Iterator* iterator();
    bool remove(::java::lang::Object* arg0);
    bool removeAll(Collection* arg0);
    bool retainAll(Collection* arg0);
    int32_t size();
    Spliterator* spliterator();
    ::java::lang::ObjectArray* toArray_();
    ::java::lang::ObjectArray* toArray_(::java::lang::ObjectArray* arg0);

private:
    virtual ::java::lang::Class* getClass0();
};
