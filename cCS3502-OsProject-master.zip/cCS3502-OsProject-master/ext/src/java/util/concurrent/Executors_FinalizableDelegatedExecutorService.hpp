// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/util/concurrent/fwd-CS3502-OsProject-master.hpp>
#include <java/util/concurrent/Executors_DelegatedExecutorService.hpp>

struct default_init_tag;

class java::util::concurrent::Executors_FinalizableDelegatedExecutorService
    : public Executors_DelegatedExecutorService
{

public:
    typedef Executors_DelegatedExecutorService super;

protected:
    void ctor(ExecutorService* arg0);

public: /* protected */
    void finalize() override;

    // Generated

public: /* package */
    Executors_FinalizableDelegatedExecutorService(ExecutorService* arg0);
protected:
    Executors_FinalizableDelegatedExecutorService(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
