// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/security/fwd-CS3502-OsProject-master.hpp>
#include <java/util/concurrent/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct default_init_tag;

class java::util::concurrent::Executors
    : public virtual ::java::lang::Object
{

public:
    typedef ::java::lang::Object super;

    /*void ctor(); (private) */
    static Callable* callable(::java::lang::Runnable* arg0);
    static Callable* callable(::java::security::PrivilegedAction* arg0);
    static Callable* callable(::java::security::PrivilegedExceptionAction* arg0);
    static Callable* callable(::java::lang::Runnable* arg0, ::java::lang::Object* arg1);
    static ThreadFactory* defaultThreadFactory();
    static ExecutorService* newCachedThreadPool();
    static ExecutorService* newCachedThreadPool(ThreadFactory* arg0);
    static ExecutorService* newFixedThreadPool(int32_t arg0);
    static ExecutorService* newFixedThreadPool(int32_t arg0, ThreadFactory* arg1);
    static ScheduledExecutorService* newScheduledThreadPool(int32_t arg0);
    static ScheduledExecutorService* newScheduledThreadPool(int32_t arg0, ThreadFactory* arg1);
    static ExecutorService* newSingleThreadExecutor();
    static ExecutorService* newSingleThreadExecutor(ThreadFactory* arg0);
    static ScheduledExecutorService* newSingleThreadScheduledExecutor();
    static ScheduledExecutorService* newSingleThreadScheduledExecutor(ThreadFactory* arg0);
    static ExecutorService* newWorkStealingPool();
    static ExecutorService* newWorkStealingPool(int32_t arg0);
    static Callable* privilegedCallable(Callable* arg0);
    static Callable* privilegedCallableUsingCurrentClassLoader(Callable* arg0);
    static ThreadFactory* privilegedThreadFactory();
    static ExecutorService* unconfigurableExecutorService(ExecutorService* arg0);
    static ScheduledExecutorService* unconfigurableScheduledExecutorService(ScheduledExecutorService* arg0);

    // Generated
    Executors();
protected:
    Executors(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
