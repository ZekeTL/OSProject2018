// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <java/util/concurrent/fwd-CS3502-OsProject-master.hpp>
#include <java/util/concurrent/Executor.hpp>

struct java::util::concurrent::ExecutorService
    : public virtual Executor
{

    virtual bool awaitTermination(int64_t arg0, TimeUnit* arg1) = 0;
    virtual ::java::util::List* invokeAll(::java::util::Collection* arg0) = 0;
    virtual ::java::util::List* invokeAll(::java::util::Collection* arg0, int64_t arg1, TimeUnit* arg2) = 0;
    virtual ::java::lang::Object* invokeAny(::java::util::Collection* arg0) = 0;
    virtual ::java::lang::Object* invokeAny(::java::util::Collection* arg0, int64_t arg1, TimeUnit* arg2) = 0;
    virtual bool isShutdown() = 0;
    virtual bool isTerminated() = 0;
    virtual void shutdown() = 0;
    virtual ::java::util::List* shutdownNow() = 0;
    virtual Future* submit(Callable* arg0) = 0;
    virtual Future* submit(::java::lang::Runnable* arg0) = 0;
    virtual Future* submit(::java::lang::Runnable* arg0, ::java::lang::Object* arg1) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
