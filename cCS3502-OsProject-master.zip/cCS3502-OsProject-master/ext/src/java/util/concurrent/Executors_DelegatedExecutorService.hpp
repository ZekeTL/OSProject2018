// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <java/util/concurrent/fwd-CS3502-OsProject-master.hpp>
#include <java/util/concurrent/AbstractExecutorService.hpp>

struct default_init_tag;

class java::util::concurrent::Executors_DelegatedExecutorService
    : public AbstractExecutorService
{

public:
    typedef AbstractExecutorService super;

private:
    ExecutorService* e {  };

protected:
    void ctor(ExecutorService* arg0);

public:
    bool awaitTermination(int64_t arg0, TimeUnit* arg1) override;
    void execute(::java::lang::Runnable* arg0) override;
    ::java::util::List* invokeAll(::java::util::Collection* arg0) override;
    ::java::util::List* invokeAll(::java::util::Collection* arg0, int64_t arg1, TimeUnit* arg2) override;
    ::java::lang::Object* invokeAny(::java::util::Collection* arg0) override;
    ::java::lang::Object* invokeAny(::java::util::Collection* arg0, int64_t arg1, TimeUnit* arg2) override;
    bool isShutdown() override;
    bool isTerminated() override;
    void shutdown() override;
    ::java::util::List* shutdownNow() override;
    Future* submit(::java::lang::Runnable* arg0) override;
    Future* submit(Callable* arg0) override;
    Future* submit(::java::lang::Runnable* arg0, ::java::lang::Object* arg1) override;

    // Generated

public: /* package */
    Executors_DelegatedExecutorService(ExecutorService* arg0);
protected:
    Executors_DelegatedExecutorService(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
