// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <java/util/concurrent/fwd-CS3502-OsProject-master.hpp>
#include <java/util/concurrent/Executors_DelegatedExecutorService.hpp>
#include <java/util/concurrent/ScheduledExecutorService.hpp>

struct default_init_tag;

class java::util::concurrent::Executors_DelegatedScheduledExecutorService
    : public Executors_DelegatedExecutorService
    , public virtual ScheduledExecutorService
{

public:
    typedef Executors_DelegatedExecutorService super;

private:
    ScheduledExecutorService* e {  };

protected:
    void ctor(ScheduledExecutorService* arg0);

public:
    ScheduledFuture* schedule(::java::lang::Runnable* arg0, int64_t arg1, TimeUnit* arg2) override;
    ScheduledFuture* schedule(Callable* arg0, int64_t arg1, TimeUnit* arg2) override;
    ScheduledFuture* scheduleAtFixedRate(::java::lang::Runnable* arg0, int64_t arg1, int64_t arg2, TimeUnit* arg3) override;
    ScheduledFuture* scheduleWithFixedDelay(::java::lang::Runnable* arg0, int64_t arg1, int64_t arg2, TimeUnit* arg3) override;

    // Generated

public: /* package */
    Executors_DelegatedScheduledExecutorService(ScheduledExecutorService* arg0);
protected:
    Executors_DelegatedScheduledExecutorService(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();
    virtual void execute(::java::lang::Runnable* arg0);
    virtual bool awaitTermination(int64_t timeout, TimeUnit* unit);
    virtual ::java::util::List* invokeAll(::java::util::Collection* tasks);
    virtual ::java::util::List* invokeAll(::java::util::Collection* tasks, int64_t timeout, TimeUnit* unit);
    virtual ::java::lang::Object* invokeAny(::java::util::Collection* tasks);
    virtual ::java::lang::Object* invokeAny(::java::util::Collection* tasks, int64_t timeout, TimeUnit* unit);
    virtual bool isShutdown();
    virtual bool isTerminated();
    virtual void shutdown();
    virtual ::java::util::List* shutdownNow();
    virtual Future* submit(::java::lang::Runnable* task);
    virtual Future* submit(::java::lang::Runnable* task, ::java::lang::Object* result);
    virtual Future* submit(Callable* task);

private:
    virtual ::java::lang::Class* getClass0();
};
