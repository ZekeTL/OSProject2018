// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <java/util/concurrent/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/util/concurrent/ExecutorService.hpp>

struct default_init_tag;

class java::util::concurrent::AbstractExecutorService
    : public virtual ::java::lang::Object
    , public virtual ExecutorService
{

public:
    typedef ::java::lang::Object super;

private:
    static bool $assertionsDisabled_;

protected:
    void ctor();
    /*::java::lang::Object* doInvokeAny(::java::util::Collection* arg0, bool arg1, int64_t arg2); (private) */

public:
    ::java::util::List* invokeAll(::java::util::Collection* arg0) override;
    ::java::util::List* invokeAll(::java::util::Collection* arg0, int64_t arg1, TimeUnit* arg2) override;
    ::java::lang::Object* invokeAny(::java::util::Collection* arg0) override;
    ::java::lang::Object* invokeAny(::java::util::Collection* arg0, int64_t arg1, TimeUnit* arg2) override;

public: /* protected */
    virtual RunnableFuture* newTaskFor(Callable* arg0);
    virtual RunnableFuture* newTaskFor(::java::lang::Runnable* arg0, ::java::lang::Object* arg1);

public:
    Future* submit(::java::lang::Runnable* arg0) override;
    Future* submit(Callable* arg0) override;
    Future* submit(::java::lang::Runnable* arg0, ::java::lang::Object* arg1) override;

    // Generated
    AbstractExecutorService();
protected:
    AbstractExecutorService(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

public: /* package */
    static bool& $assertionsDisabled();

private:
    virtual ::java::lang::Class* getClass0();
};
