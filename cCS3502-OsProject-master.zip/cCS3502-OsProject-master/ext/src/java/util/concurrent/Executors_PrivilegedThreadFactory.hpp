// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/security/fwd-CS3502-OsProject-master.hpp>
#include <java/util/concurrent/fwd-CS3502-OsProject-master.hpp>
#include <java/util/concurrent/Executors_DefaultThreadFactory.hpp>

struct default_init_tag;

class java::util::concurrent::Executors_PrivilegedThreadFactory
    : public Executors_DefaultThreadFactory
{

public:
    typedef Executors_DefaultThreadFactory super;

private:
    ::java::security::AccessControlContext* acc {  };
    ::java::lang::ClassLoader* ccl {  };

protected:
    void ctor();

public:
    ::java::lang::Thread* newThread(::java::lang::Runnable* arg0) override;

    // Generated

public: /* package */
    Executors_PrivilegedThreadFactory();
protected:
    Executors_PrivilegedThreadFactory(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
