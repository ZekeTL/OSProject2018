// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <java/util/Collection.hpp>

struct java::util::Set
    : public virtual Collection
{

    /*bool add(::java::lang::Object* e); (already declared) */
    /*bool addAll(Collection* c); (already declared) */
    /*void clear(); (already declared) */
    /*bool contains(::java::lang::Object* o); (already declared) */
    /*bool containsAll(Collection* c); (already declared) */
    /*bool equals(::java::lang::Object* o); (already declared) */
    /*int32_t hashCode(); (already declared) */
    /*bool isEmpty(); (already declared) */
    /*Iterator* iterator(); (already declared) */
    /*bool remove(::java::lang::Object* o); (already declared) */
    /*bool removeAll(Collection* c); (already declared) */
    /*bool retainAll(Collection* c); (already declared) */
    /*int32_t size(); (already declared) */
    /*Spliterator* spliterator(); (already declared) */
    /*::java::lang::ObjectArray* toArray_(); (already declared) */
    /*::java::lang::ObjectArray* toArray_(::java::lang::ObjectArray* a); (already declared) */

    // Generated
    static ::java::lang::Class *class_();
};
