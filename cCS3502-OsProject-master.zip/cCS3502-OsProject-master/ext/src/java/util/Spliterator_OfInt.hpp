// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <java/util/function/fwd-CS3502-OsProject-master.hpp>
#include <java/util/Spliterator_OfPrimitive.hpp>

struct java::util::Spliterator_OfInt
    : public virtual Spliterator_OfPrimitive
{

    virtual void forEachRemaining(::java::util::function::IntConsumer* arg0);
    /*void forEachRemaining(::java::util::function::Consumer* arg0); (already declared) */
    virtual bool tryAdvance(::java::util::function::IntConsumer* arg0) = 0;
    /*bool tryAdvance(::java::util::function::Consumer* arg0); (already declared) */
    Spliterator_OfInt* trySplit() = 0;

    // Generated
    static ::java::lang::Class *class_();
    virtual void forEachRemaining(::java::util::function::Consumer* action);
    virtual bool tryAdvance(::java::util::function::Consumer* action) = 0;
};
