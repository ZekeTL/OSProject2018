// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <java/util/function/fwd-CS3502-OsProject-master.hpp>
#include <java/util/Spliterator.hpp>

struct java::util::Spliterator_OfPrimitive
    : public virtual Spliterator
{

    virtual void forEachRemaining(::java::lang::Object* arg0);
    virtual bool tryAdvance(::java::lang::Object* arg0) = 0;
    Spliterator_OfPrimitive* trySplit() = 0;

    // Generated
    static ::java::lang::Class *class_();
    virtual void forEachRemaining(::java::util::function::Consumer* action);
    virtual bool tryAdvance(::java::util::function::Consumer* action) = 0;
};
