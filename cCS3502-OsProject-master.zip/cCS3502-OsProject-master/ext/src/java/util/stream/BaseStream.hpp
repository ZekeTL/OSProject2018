// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <java/util/stream/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/AutoCloseable.hpp>

struct java::util::stream::BaseStream
    : public virtual ::java::lang::AutoCloseable
{

    /*void close(); (already declared) */
    virtual bool isParallel() = 0;
    virtual ::java::util::Iterator* iterator() = 0;
    virtual BaseStream* onClose(::java::lang::Runnable* arg0) = 0;
    virtual BaseStream* parallel() = 0;
    virtual BaseStream* sequential() = 0;
    virtual ::java::util::Spliterator* spliterator() = 0;
    virtual BaseStream* unordered() = 0;

    // Generated
    static ::java::lang::Class *class_();
};
