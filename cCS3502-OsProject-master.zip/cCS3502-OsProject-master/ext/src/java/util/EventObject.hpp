// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <java/io/Serializable.hpp>

struct default_init_tag;

class java::util::EventObject
    : public virtual ::java::lang::Object
    , public virtual ::java::io::Serializable
{

public:
    typedef ::java::lang::Object super;

private:
    static constexpr int64_t serialVersionUID { int64_t(5516075349620653480LL) };

public: /* protected */
    ::java::lang::Object* source {  };

protected:
    void ctor(::java::lang::Object* arg0);

public:
    virtual ::java::lang::Object* getSource();
    ::java::lang::String* toString() override;

    // Generated
    EventObject(::java::lang::Object* arg0);
protected:
    EventObject(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
