// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <java/util/function/fwd-CS3502-OsProject-master.hpp>
#include <java/util/Spliterator_OfPrimitive.hpp>

struct java::util::Spliterator_OfLong
    : public virtual Spliterator_OfPrimitive
{

    virtual void forEachRemaining(::java::util::function::LongConsumer* action);
    /*void forEachRemaining(::java::util::function::Consumer* action); (already declared) */
    virtual bool tryAdvance(::java::util::function::LongConsumer* action) = 0;
    /*bool tryAdvance(::java::util::function::Consumer* action); (already declared) */
    Spliterator_OfLong* trySplit() = 0;

    // Generated
    static ::java::lang::Class *class_();
    virtual void forEachRemaining(::java::util::function::Consumer* action);
    virtual bool tryAdvance(::java::util::function::Consumer* action) = 0;
};
