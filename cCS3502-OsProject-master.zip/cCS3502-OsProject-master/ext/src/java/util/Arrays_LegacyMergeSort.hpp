// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/util/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct default_init_tag;

class java::util::Arrays_LegacyMergeSort final
    : public ::java::lang::Object
{

public:
    typedef ::java::lang::Object super;

private:
    static bool userRequested_;

protected:
    void ctor();

    // Generated

public: /* package */
    Arrays_LegacyMergeSort();
protected:
    Arrays_LegacyMergeSort(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    static bool& userRequested();
    virtual ::java::lang::Class* getClass0();
};
