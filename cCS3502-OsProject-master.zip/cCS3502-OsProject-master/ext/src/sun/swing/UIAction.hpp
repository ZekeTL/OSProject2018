// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/beans/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/fwd-CS3502-OsProject-master.hpp>
#include <sun/swing/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>
#include <javax/swing/Action.hpp>

struct default_init_tag;

class sun::swing::UIAction
    : public virtual ::java::lang::Object
    , public virtual ::javax::swing::Action
{

public:
    typedef ::java::lang::Object super;

private:
    ::java::lang::String* name {  };

protected:
    void ctor(::java::lang::String* arg0);

public:
    void addPropertyChangeListener(::java::beans::PropertyChangeListener* arg0) override;
    ::java::lang::String* getName();
    ::java::lang::Object* getValue(::java::lang::String* arg0) override;
    bool isEnabled() override;
    virtual bool isEnabled(::java::lang::Object* arg0);
    void putValue(::java::lang::String* arg0, ::java::lang::Object* arg1) override;
    void removePropertyChangeListener(::java::beans::PropertyChangeListener* arg0) override;
    void setEnabled(bool arg0) override;

    // Generated
    UIAction(::java::lang::String* arg0);
protected:
    UIAction(const ::default_init_tag&);


public:
    static ::java::lang::Class *class_();

private:
    virtual ::java::lang::Class* getClass0();
};
