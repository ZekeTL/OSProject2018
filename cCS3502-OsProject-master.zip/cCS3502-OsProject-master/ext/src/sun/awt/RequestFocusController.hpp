// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar

#pragma once

#include <fwd-CS3502-OsProject-master.hpp>
#include <java/awt/fwd-CS3502-OsProject-master.hpp>
#include <sun/awt/fwd-CS3502-OsProject-master.hpp>
#include <java/lang/Object.hpp>

struct sun::awt::RequestFocusController
    : public virtual ::java::lang::Object
{

    virtual bool acceptRequestFocus(::java::awt::Component* arg0, ::java::awt::Component* arg1, bool arg2, bool arg3, CausedFocusEvent_Cause* arg4) = 0;

    // Generated
    static ::java::lang::Class *class_();
};
