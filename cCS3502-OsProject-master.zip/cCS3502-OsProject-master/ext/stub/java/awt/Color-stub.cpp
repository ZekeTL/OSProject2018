// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar
#include <java/awt/Color.hpp>

extern void unimplemented_(const char16_t* name);
java::awt::Color::Color(const ::default_init_tag&)
    : super(*static_cast< ::default_init_tag* >(0))
{
    clinit();
}

java::awt::Color::Color(int32_t arg0)
    : Color(*static_cast< ::default_init_tag* >(0))
{
    ctor(arg0);
}

java::awt::Color::Color(int32_t arg0, bool arg1)
    : Color(*static_cast< ::default_init_tag* >(0))
{
    ctor(arg0, arg1);
}

java::awt::Color::Color(int32_t arg0, int32_t arg1, int32_t arg2)
    : Color(*static_cast< ::default_init_tag* >(0))
{
    ctor(arg0, arg1, arg2);
}

java::awt::Color::Color(float arg0, float arg1, float arg2)
    : Color(*static_cast< ::default_init_tag* >(0))
{
    ctor(arg0, arg1, arg2);
}

java::awt::Color::Color(::java::awt::color::ColorSpace* arg0, ::floatArray* arg1, float arg2)
    : Color(*static_cast< ::default_init_tag* >(0))
{
    ctor(arg0, arg1, arg2);
}

java::awt::Color::Color(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3)
    : Color(*static_cast< ::default_init_tag* >(0))
{
    ctor(arg0, arg1, arg2, arg3);
}

java::awt::Color::Color(float arg0, float arg1, float arg2, float arg3)
    : Color(*static_cast< ::default_init_tag* >(0))
{
    ctor(arg0, arg1, arg2, arg3);
}

java::awt::Color*& java::awt::Color::BLACK()
{
    clinit();
    return BLACK_;
}
java::awt::Color* java::awt::Color::BLACK_;
java::awt::Color*& java::awt::Color::BLUE()
{
    clinit();
    return BLUE_;
}
java::awt::Color* java::awt::Color::BLUE_;
java::awt::Color*& java::awt::Color::CYAN()
{
    clinit();
    return CYAN_;
}
java::awt::Color* java::awt::Color::CYAN_;
java::awt::Color*& java::awt::Color::DARK_GRAY()
{
    clinit();
    return DARK_GRAY_;
}
java::awt::Color* java::awt::Color::DARK_GRAY_;
constexpr double java::awt::Color::FACTOR;
java::awt::Color*& java::awt::Color::GRAY()
{
    clinit();
    return GRAY_;
}
java::awt::Color* java::awt::Color::GRAY_;
java::awt::Color*& java::awt::Color::GREEN()
{
    clinit();
    return GREEN_;
}
java::awt::Color* java::awt::Color::GREEN_;
java::awt::Color*& java::awt::Color::LIGHT_GRAY()
{
    clinit();
    return LIGHT_GRAY_;
}
java::awt::Color* java::awt::Color::LIGHT_GRAY_;
java::awt::Color*& java::awt::Color::MAGENTA()
{
    clinit();
    return MAGENTA_;
}
java::awt::Color* java::awt::Color::MAGENTA_;
java::awt::Color*& java::awt::Color::ORANGE()
{
    clinit();
    return ORANGE_;
}
java::awt::Color* java::awt::Color::ORANGE_;
java::awt::Color*& java::awt::Color::PINK()
{
    clinit();
    return PINK_;
}
java::awt::Color* java::awt::Color::PINK_;
java::awt::Color*& java::awt::Color::RED()
{
    clinit();
    return RED_;
}
java::awt::Color* java::awt::Color::RED_;
java::awt::Color*& java::awt::Color::WHITE()
{
    clinit();
    return WHITE_;
}
java::awt::Color* java::awt::Color::WHITE_;
java::awt::Color*& java::awt::Color::YELLOW()
{
    clinit();
    return YELLOW_;
}
java::awt::Color* java::awt::Color::YELLOW_;
java::awt::Color*& java::awt::Color::black()
{
    clinit();
    return black_;
}
java::awt::Color* java::awt::Color::black_;
java::awt::Color*& java::awt::Color::blue()
{
    clinit();
    return blue_;
}
java::awt::Color* java::awt::Color::blue_;
java::awt::Color*& java::awt::Color::cyan()
{
    clinit();
    return cyan_;
}
java::awt::Color* java::awt::Color::cyan_;
java::awt::Color*& java::awt::Color::darkGray()
{
    clinit();
    return darkGray_;
}
java::awt::Color* java::awt::Color::darkGray_;
java::awt::Color*& java::awt::Color::gray()
{
    clinit();
    return gray_;
}
java::awt::Color* java::awt::Color::gray_;
java::awt::Color*& java::awt::Color::green()
{
    clinit();
    return green_;
}
java::awt::Color* java::awt::Color::green_;
java::awt::Color*& java::awt::Color::lightGray()
{
    clinit();
    return lightGray_;
}
java::awt::Color* java::awt::Color::lightGray_;
java::awt::Color*& java::awt::Color::magenta()
{
    clinit();
    return magenta_;
}
java::awt::Color* java::awt::Color::magenta_;
java::awt::Color*& java::awt::Color::orange()
{
    clinit();
    return orange_;
}
java::awt::Color* java::awt::Color::orange_;
java::awt::Color*& java::awt::Color::pink()
{
    clinit();
    return pink_;
}
java::awt::Color* java::awt::Color::pink_;
java::awt::Color*& java::awt::Color::red()
{
    clinit();
    return red_;
}
java::awt::Color* java::awt::Color::red_;
constexpr int64_t java::awt::Color::serialVersionUID;
java::awt::Color*& java::awt::Color::white()
{
    clinit();
    return white_;
}
java::awt::Color* java::awt::Color::white_;
java::awt::Color*& java::awt::Color::yellow()
{
    clinit();
    return yellow_;
}
java::awt::Color* java::awt::Color::yellow_;

void ::java::awt::Color::ctor(int32_t arg0)
{ /* stub */
    /* super::ctor(); */
    unimplemented_(u"void ::java::awt::Color::ctor(int32_t arg0)");
}

void ::java::awt::Color::ctor(int32_t arg0, bool arg1)
{ /* stub */
    /* super::ctor(); */
    unimplemented_(u"void ::java::awt::Color::ctor(int32_t arg0, bool arg1)");
}

void ::java::awt::Color::ctor(int32_t arg0, int32_t arg1, int32_t arg2)
{ /* stub */
    /* super::ctor(); */
    unimplemented_(u"void ::java::awt::Color::ctor(int32_t arg0, int32_t arg1, int32_t arg2)");
}

void ::java::awt::Color::ctor(float arg0, float arg1, float arg2)
{ /* stub */
    /* super::ctor(); */
    unimplemented_(u"void ::java::awt::Color::ctor(float arg0, float arg1, float arg2)");
}

void ::java::awt::Color::ctor(::java::awt::color::ColorSpace* arg0, ::floatArray* arg1, float arg2)
{ /* stub */
    /* super::ctor(); */
    unimplemented_(u"void ::java::awt::Color::ctor(::java::awt::color::ColorSpace* arg0, ::floatArray* arg1, float arg2)");
}

void ::java::awt::Color::ctor(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3)
{ /* stub */
    /* super::ctor(); */
    unimplemented_(u"void ::java::awt::Color::ctor(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3)");
}

void ::java::awt::Color::ctor(float arg0, float arg1, float arg2, float arg3)
{ /* stub */
    /* super::ctor(); */
    unimplemented_(u"void ::java::awt::Color::ctor(float arg0, float arg1, float arg2, float arg3)");
}

int32_t java::awt::Color::HSBtoRGB(float arg0, float arg1, float arg2)
{ /* stub */
    clinit();
    unimplemented_(u"int32_t java::awt::Color::HSBtoRGB(float arg0, float arg1, float arg2)");
    return 0;
}

floatArray* java::awt::Color::RGBtoHSB(int32_t arg0, int32_t arg1, int32_t arg2, ::floatArray* arg3)
{ /* stub */
    clinit();
    unimplemented_(u"floatArray* java::awt::Color::RGBtoHSB(int32_t arg0, int32_t arg1, int32_t arg2, ::floatArray* arg3)");
    return 0;
}

java::awt::Color* java::awt::Color::brighter()
{ /* stub */
    unimplemented_(u"java::awt::Color* java::awt::Color::brighter()");
    return 0;
}

java::awt::PaintContext* java::awt::Color::createContext(::java::awt::image::ColorModel* arg0, Rectangle* arg1, ::java::awt::geom::Rectangle2D* arg2, ::java::awt::geom::AffineTransform* arg3, RenderingHints* arg4)
{ /* stub */
    unimplemented_(u"java::awt::PaintContext* java::awt::Color::createContext(::java::awt::image::ColorModel* arg0, Rectangle* arg1, ::java::awt::geom::Rectangle2D* arg2, ::java::awt::geom::AffineTransform* arg3, RenderingHints* arg4)");
    return 0;
}

java::awt::Color* java::awt::Color::darker()
{ /* stub */
    unimplemented_(u"java::awt::Color* java::awt::Color::darker()");
    return 0;
}

java::awt::Color* java::awt::Color::decode(::java::lang::String* arg0)
{ /* stub */
    clinit();
    unimplemented_(u"java::awt::Color* java::awt::Color::decode(::java::lang::String* arg0)");
    return 0;
}

bool java::awt::Color::equals(::java::lang::Object* arg0)
{ /* stub */
    unimplemented_(u"bool java::awt::Color::equals(::java::lang::Object* arg0)");
    return 0;
}

int32_t java::awt::Color::getAlpha()
{ /* stub */
    unimplemented_(u"int32_t java::awt::Color::getAlpha()");
    return 0;
}

int32_t java::awt::Color::getBlue()
{ /* stub */
    unimplemented_(u"int32_t java::awt::Color::getBlue()");
    return 0;
}

java::awt::Color* java::awt::Color::getColor(::java::lang::String* arg0)
{ /* stub */
    clinit();
    unimplemented_(u"java::awt::Color* java::awt::Color::getColor(::java::lang::String* arg0)");
    return 0;
}

java::awt::Color* java::awt::Color::getColor(::java::lang::String* arg0, Color* arg1)
{ /* stub */
    clinit();
    unimplemented_(u"java::awt::Color* java::awt::Color::getColor(::java::lang::String* arg0, Color* arg1)");
    return 0;
}

java::awt::Color* java::awt::Color::getColor(::java::lang::String* arg0, int32_t arg1)
{ /* stub */
    clinit();
    unimplemented_(u"java::awt::Color* java::awt::Color::getColor(::java::lang::String* arg0, int32_t arg1)");
    return 0;
}

floatArray* java::awt::Color::getColorComponents(::floatArray* arg0)
{ /* stub */
    unimplemented_(u"floatArray* java::awt::Color::getColorComponents(::floatArray* arg0)");
    return 0;
}

floatArray* java::awt::Color::getColorComponents(::java::awt::color::ColorSpace* arg0, ::floatArray* arg1)
{ /* stub */
    unimplemented_(u"floatArray* java::awt::Color::getColorComponents(::java::awt::color::ColorSpace* arg0, ::floatArray* arg1)");
    return 0;
}

java::awt::color::ColorSpace* java::awt::Color::getColorSpace()
{ /* stub */
    unimplemented_(u"java::awt::color::ColorSpace* java::awt::Color::getColorSpace()");
    return 0;
}

floatArray* java::awt::Color::getComponents(::floatArray* arg0)
{ /* stub */
    unimplemented_(u"floatArray* java::awt::Color::getComponents(::floatArray* arg0)");
    return 0;
}

floatArray* java::awt::Color::getComponents(::java::awt::color::ColorSpace* arg0, ::floatArray* arg1)
{ /* stub */
    unimplemented_(u"floatArray* java::awt::Color::getComponents(::java::awt::color::ColorSpace* arg0, ::floatArray* arg1)");
    return 0;
}

int32_t java::awt::Color::getGreen()
{ /* stub */
    unimplemented_(u"int32_t java::awt::Color::getGreen()");
    return 0;
}

java::awt::Color* java::awt::Color::getHSBColor(float arg0, float arg1, float arg2)
{ /* stub */
    clinit();
    unimplemented_(u"java::awt::Color* java::awt::Color::getHSBColor(float arg0, float arg1, float arg2)");
    return 0;
}

int32_t java::awt::Color::getRGB()
{ /* stub */
    unimplemented_(u"int32_t java::awt::Color::getRGB()");
    return 0;
}

floatArray* java::awt::Color::getRGBColorComponents(::floatArray* arg0)
{ /* stub */
    unimplemented_(u"floatArray* java::awt::Color::getRGBColorComponents(::floatArray* arg0)");
    return 0;
}

floatArray* java::awt::Color::getRGBComponents(::floatArray* arg0)
{ /* stub */
    unimplemented_(u"floatArray* java::awt::Color::getRGBComponents(::floatArray* arg0)");
    return 0;
}

int32_t java::awt::Color::getRed()
{ /* stub */
    unimplemented_(u"int32_t java::awt::Color::getRed()");
    return 0;
}

int32_t java::awt::Color::getTransparency()
{ /* stub */
    unimplemented_(u"int32_t java::awt::Color::getTransparency()");
    return 0;
}

int32_t java::awt::Color::hashCode()
{ /* stub */
    unimplemented_(u"int32_t java::awt::Color::hashCode()");
    return 0;
}

/* private: void java::awt::Color::testColorValueRange(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3) */
/* private: void java::awt::Color::testColorValueRange(float arg0, float arg1, float arg2, float arg3) */
java::lang::String* java::awt::Color::toString()
{ /* stub */
    unimplemented_(u"java::lang::String* java::awt::Color::toString()");
    return 0;
}

extern java::lang::Class *class_(const char16_t *c, int n);

java::lang::Class* java::awt::Color::class_()
{
    static ::java::lang::Class* c = ::class_(u"java.awt.Color", 14);
    return c;
}

java::lang::Class* java::awt::Color::getClass0()
{
    return class_();
}

