// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar
#include <java/awt/Component_FlipSubRegionBufferStrategy.hpp>

#include <java/awt/Component.hpp>

extern void unimplemented_(const char16_t* name);
java::awt::Component_FlipSubRegionBufferStrategy::Component_FlipSubRegionBufferStrategy(Component *Component_this, const ::default_init_tag&)
    : super(Component_this, *static_cast< ::default_init_tag* >(0))
{
    clinit();
}

java::awt::Component_FlipSubRegionBufferStrategy::Component_FlipSubRegionBufferStrategy(Component *Component_this, int32_t arg0, BufferCapabilities* arg1)
    : Component_FlipSubRegionBufferStrategy(Component_this, *static_cast< ::default_init_tag* >(0))
{
    ctor(arg0, arg1);
}


void ::java::awt::Component_FlipSubRegionBufferStrategy::ctor(int32_t arg0, BufferCapabilities* arg1)
{ /* stub */
    /* super::ctor(); */
    unimplemented_(u"void ::java::awt::Component_FlipSubRegionBufferStrategy::ctor(int32_t arg0, BufferCapabilities* arg1)");
}

void java::awt::Component_FlipSubRegionBufferStrategy::show(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3)
{ /* stub */
    unimplemented_(u"void java::awt::Component_FlipSubRegionBufferStrategy::show(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3)");
}

bool java::awt::Component_FlipSubRegionBufferStrategy::showIfNotLost(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3)
{ /* stub */
    unimplemented_(u"bool java::awt::Component_FlipSubRegionBufferStrategy::showIfNotLost(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3)");
    return 0;
}

extern java::lang::Class *class_(const char16_t *c, int n);

java::lang::Class* java::awt::Component_FlipSubRegionBufferStrategy::class_()
{
    static ::java::lang::Class* c = ::class_(u"java.awt.Component.FlipSubRegionBufferStrategy", 46);
    return c;
}

void java::awt::Component_FlipSubRegionBufferStrategy::show()
{
    super::show();
}

java::lang::Class* java::awt::Component_FlipSubRegionBufferStrategy::getClass0()
{
    return class_();
}

