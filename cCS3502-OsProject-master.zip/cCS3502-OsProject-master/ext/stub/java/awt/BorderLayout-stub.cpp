// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar
#include <java/awt/BorderLayout.hpp>

extern void unimplemented_(const char16_t* name);
java::awt::BorderLayout::BorderLayout(const ::default_init_tag&)
    : super(*static_cast< ::default_init_tag* >(0))
{
    clinit();
}

java::awt::BorderLayout::BorderLayout()
    : BorderLayout(*static_cast< ::default_init_tag* >(0))
{
    ctor();
}

java::awt::BorderLayout::BorderLayout(int32_t arg0, int32_t arg1)
    : BorderLayout(*static_cast< ::default_init_tag* >(0))
{
    ctor(arg0, arg1);
}

java::lang::String*& java::awt::BorderLayout::AFTER_LAST_LINE()
{
    clinit();
    return AFTER_LAST_LINE_;
}
java::lang::String* java::awt::BorderLayout::AFTER_LAST_LINE_;
java::lang::String*& java::awt::BorderLayout::AFTER_LINE_ENDS()
{
    clinit();
    return AFTER_LINE_ENDS_;
}
java::lang::String* java::awt::BorderLayout::AFTER_LINE_ENDS_;
java::lang::String*& java::awt::BorderLayout::BEFORE_FIRST_LINE()
{
    clinit();
    return BEFORE_FIRST_LINE_;
}
java::lang::String* java::awt::BorderLayout::BEFORE_FIRST_LINE_;
java::lang::String*& java::awt::BorderLayout::BEFORE_LINE_BEGINS()
{
    clinit();
    return BEFORE_LINE_BEGINS_;
}
java::lang::String* java::awt::BorderLayout::BEFORE_LINE_BEGINS_;
java::lang::String*& java::awt::BorderLayout::CENTER()
{
    clinit();
    return CENTER_;
}
java::lang::String* java::awt::BorderLayout::CENTER_;
java::lang::String*& java::awt::BorderLayout::EAST()
{
    clinit();
    return EAST_;
}
java::lang::String* java::awt::BorderLayout::EAST_;
java::lang::String*& java::awt::BorderLayout::LINE_END()
{
    clinit();
    return LINE_END_;
}
java::lang::String* java::awt::BorderLayout::LINE_END_;
java::lang::String*& java::awt::BorderLayout::LINE_START()
{
    clinit();
    return LINE_START_;
}
java::lang::String* java::awt::BorderLayout::LINE_START_;
java::lang::String*& java::awt::BorderLayout::NORTH()
{
    clinit();
    return NORTH_;
}
java::lang::String* java::awt::BorderLayout::NORTH_;
java::lang::String*& java::awt::BorderLayout::PAGE_END()
{
    clinit();
    return PAGE_END_;
}
java::lang::String* java::awt::BorderLayout::PAGE_END_;
java::lang::String*& java::awt::BorderLayout::PAGE_START()
{
    clinit();
    return PAGE_START_;
}
java::lang::String* java::awt::BorderLayout::PAGE_START_;
java::lang::String*& java::awt::BorderLayout::SOUTH()
{
    clinit();
    return SOUTH_;
}
java::lang::String* java::awt::BorderLayout::SOUTH_;
java::lang::String*& java::awt::BorderLayout::WEST()
{
    clinit();
    return WEST_;
}
java::lang::String* java::awt::BorderLayout::WEST_;
constexpr int64_t java::awt::BorderLayout::serialVersionUID;

void ::java::awt::BorderLayout::ctor()
{ /* stub */
    /* super::ctor(); */
    unimplemented_(u"void ::java::awt::BorderLayout::ctor()");
}

void ::java::awt::BorderLayout::ctor(int32_t arg0, int32_t arg1)
{ /* stub */
    /* super::ctor(); */
    unimplemented_(u"void ::java::awt::BorderLayout::ctor(int32_t arg0, int32_t arg1)");
}

void java::awt::BorderLayout::addLayoutComponent(Component* arg0, ::java::lang::Object* arg1)
{ /* stub */
    unimplemented_(u"void java::awt::BorderLayout::addLayoutComponent(Component* arg0, ::java::lang::Object* arg1)");
}

void java::awt::BorderLayout::addLayoutComponent(::java::lang::String* arg0, Component* arg1)
{ /* stub */
    unimplemented_(u"void java::awt::BorderLayout::addLayoutComponent(::java::lang::String* arg0, Component* arg1)");
}

/* private: java::awt::Component* java::awt::BorderLayout::getChild(::java::lang::String* arg0, bool arg1) */
java::lang::Object* java::awt::BorderLayout::getConstraints(Component* arg0)
{ /* stub */
    unimplemented_(u"java::lang::Object* java::awt::BorderLayout::getConstraints(Component* arg0)");
    return 0;
}

int32_t java::awt::BorderLayout::getHgap()
{ /* stub */
return hgap ; /* getter */
}

float java::awt::BorderLayout::getLayoutAlignmentX(Container* arg0)
{ /* stub */
    unimplemented_(u"float java::awt::BorderLayout::getLayoutAlignmentX(Container* arg0)");
    return 0;
}

float java::awt::BorderLayout::getLayoutAlignmentY(Container* arg0)
{ /* stub */
    unimplemented_(u"float java::awt::BorderLayout::getLayoutAlignmentY(Container* arg0)");
    return 0;
}

java::awt::Component* java::awt::BorderLayout::getLayoutComponent(::java::lang::Object* arg0)
{ /* stub */
    unimplemented_(u"java::awt::Component* java::awt::BorderLayout::getLayoutComponent(::java::lang::Object* arg0)");
    return 0;
}

java::awt::Component* java::awt::BorderLayout::getLayoutComponent(Container* arg0, ::java::lang::Object* arg1)
{ /* stub */
    unimplemented_(u"java::awt::Component* java::awt::BorderLayout::getLayoutComponent(Container* arg0, ::java::lang::Object* arg1)");
    return 0;
}

int32_t java::awt::BorderLayout::getVgap()
{ /* stub */
return vgap ; /* getter */
}

void java::awt::BorderLayout::invalidateLayout(Container* arg0)
{ /* stub */
    unimplemented_(u"void java::awt::BorderLayout::invalidateLayout(Container* arg0)");
}

void java::awt::BorderLayout::layoutContainer(Container* arg0)
{ /* stub */
    unimplemented_(u"void java::awt::BorderLayout::layoutContainer(Container* arg0)");
}

java::awt::Dimension* java::awt::BorderLayout::maximumLayoutSize(Container* arg0)
{ /* stub */
    unimplemented_(u"java::awt::Dimension* java::awt::BorderLayout::maximumLayoutSize(Container* arg0)");
    return 0;
}

java::awt::Dimension* java::awt::BorderLayout::minimumLayoutSize(Container* arg0)
{ /* stub */
    unimplemented_(u"java::awt::Dimension* java::awt::BorderLayout::minimumLayoutSize(Container* arg0)");
    return 0;
}

java::awt::Dimension* java::awt::BorderLayout::preferredLayoutSize(Container* arg0)
{ /* stub */
    unimplemented_(u"java::awt::Dimension* java::awt::BorderLayout::preferredLayoutSize(Container* arg0)");
    return 0;
}

void java::awt::BorderLayout::removeLayoutComponent(Component* arg0)
{ /* stub */
    unimplemented_(u"void java::awt::BorderLayout::removeLayoutComponent(Component* arg0)");
}

void java::awt::BorderLayout::setHgap(int32_t arg0)
{ /* stub */
    this->hgap = arg0; /* setter */
}

void java::awt::BorderLayout::setVgap(int32_t arg0)
{ /* stub */
    this->vgap = arg0; /* setter */
}

java::lang::String* java::awt::BorderLayout::toString()
{ /* stub */
    unimplemented_(u"java::lang::String* java::awt::BorderLayout::toString()");
    return 0;
}

extern java::lang::Class *class_(const char16_t *c, int n);

java::lang::Class* java::awt::BorderLayout::class_()
{
    static ::java::lang::Class* c = ::class_(u"java.awt.BorderLayout", 21);
    return c;
}

java::lang::Class* java::awt::BorderLayout::getClass0()
{
    return class_();
}

