// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar
#include <java/awt/Component_DummyRequestFocusController.hpp>

extern void unimplemented_(const char16_t* name);
java::awt::Component_DummyRequestFocusController::Component_DummyRequestFocusController(const ::default_init_tag&)
    : super(*static_cast< ::default_init_tag* >(0))
{
    clinit();
}


/* private: void ::java::awt::Component_DummyRequestFocusController::ctor() */
bool java::awt::Component_DummyRequestFocusController::acceptRequestFocus(Component* arg0, Component* arg1, bool arg2, bool arg3, ::sun::awt::CausedFocusEvent_Cause* arg4)
{ /* stub */
    unimplemented_(u"bool java::awt::Component_DummyRequestFocusController::acceptRequestFocus(Component* arg0, Component* arg1, bool arg2, bool arg3, ::sun::awt::CausedFocusEvent_Cause* arg4)");
    return 0;
}

extern java::lang::Class *class_(const char16_t *c, int n);

java::lang::Class* java::awt::Component_DummyRequestFocusController::class_()
{
    static ::java::lang::Class* c = ::class_(u"java.awt.Component.DummyRequestFocusController", 46);
    return c;
}

java::lang::Class* java::awt::Component_DummyRequestFocusController::getClass0()
{
    return class_();
}

