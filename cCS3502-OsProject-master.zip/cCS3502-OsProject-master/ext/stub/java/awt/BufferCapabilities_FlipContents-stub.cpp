// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar
#include <java/awt/BufferCapabilities_FlipContents.hpp>

extern void unimplemented_(const char16_t* name);
java::awt::BufferCapabilities_FlipContents::BufferCapabilities_FlipContents(const ::default_init_tag&)
    : super(*static_cast< ::default_init_tag* >(0))
{
    clinit();
}

java::awt::BufferCapabilities_FlipContents*& java::awt::BufferCapabilities_FlipContents::BACKGROUND()
{
    clinit();
    return BACKGROUND_;
}
java::awt::BufferCapabilities_FlipContents* java::awt::BufferCapabilities_FlipContents::BACKGROUND_;
java::awt::BufferCapabilities_FlipContents*& java::awt::BufferCapabilities_FlipContents::COPIED()
{
    clinit();
    return COPIED_;
}
java::awt::BufferCapabilities_FlipContents* java::awt::BufferCapabilities_FlipContents::COPIED_;
int32_t& java::awt::BufferCapabilities_FlipContents::I_BACKGROUND()
{
    clinit();
    return I_BACKGROUND_;
}
int32_t java::awt::BufferCapabilities_FlipContents::I_BACKGROUND_;
int32_t& java::awt::BufferCapabilities_FlipContents::I_COPIED()
{
    clinit();
    return I_COPIED_;
}
int32_t java::awt::BufferCapabilities_FlipContents::I_COPIED_;
int32_t& java::awt::BufferCapabilities_FlipContents::I_PRIOR()
{
    clinit();
    return I_PRIOR_;
}
int32_t java::awt::BufferCapabilities_FlipContents::I_PRIOR_;
int32_t& java::awt::BufferCapabilities_FlipContents::I_UNDEFINED()
{
    clinit();
    return I_UNDEFINED_;
}
int32_t java::awt::BufferCapabilities_FlipContents::I_UNDEFINED_;
java::lang::StringArray*& java::awt::BufferCapabilities_FlipContents::NAMES()
{
    clinit();
    return NAMES_;
}
java::lang::StringArray* java::awt::BufferCapabilities_FlipContents::NAMES_;
java::awt::BufferCapabilities_FlipContents*& java::awt::BufferCapabilities_FlipContents::PRIOR()
{
    clinit();
    return PRIOR_;
}
java::awt::BufferCapabilities_FlipContents* java::awt::BufferCapabilities_FlipContents::PRIOR_;
java::awt::BufferCapabilities_FlipContents*& java::awt::BufferCapabilities_FlipContents::UNDEFINED()
{
    clinit();
    return UNDEFINED_;
}
java::awt::BufferCapabilities_FlipContents* java::awt::BufferCapabilities_FlipContents::UNDEFINED_;

/* private: void ::java::awt::BufferCapabilities_FlipContents::ctor(int32_t arg0) */
extern java::lang::Class *class_(const char16_t *c, int n);

java::lang::Class* java::awt::BufferCapabilities_FlipContents::class_()
{
    static ::java::lang::Class* c = ::class_(u"java.awt.BufferCapabilities.FlipContents", 40);
    return c;
}

java::lang::Class* java::awt::BufferCapabilities_FlipContents::getClass0()
{
    return class_();
}

