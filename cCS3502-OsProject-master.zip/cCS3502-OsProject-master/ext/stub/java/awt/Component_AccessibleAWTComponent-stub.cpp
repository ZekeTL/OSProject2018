// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar
#include <java/awt/Component_AccessibleAWTComponent.hpp>

#include <java/awt/Component.hpp>

extern void unimplemented_(const char16_t* name);
java::awt::Component_AccessibleAWTComponent::Component_AccessibleAWTComponent(Component *Component_this, const ::default_init_tag&)
    : super(*static_cast< ::default_init_tag* >(0))
    , Component_this(Component_this)
{
    clinit();
}

java::awt::Component_AccessibleAWTComponent::Component_AccessibleAWTComponent(Component *Component_this)
    : Component_AccessibleAWTComponent(Component_this, *static_cast< ::default_init_tag* >(0))
{
    ctor();
}

constexpr int64_t java::awt::Component_AccessibleAWTComponent::serialVersionUID;

void ::java::awt::Component_AccessibleAWTComponent::ctor()
{ /* stub */
    /* super::ctor(); */
    unimplemented_(u"void ::java::awt::Component_AccessibleAWTComponent::ctor()");
}

void java::awt::Component_AccessibleAWTComponent::addFocusListener(::java::awt::event::FocusListener* arg0)
{ /* stub */
    unimplemented_(u"void java::awt::Component_AccessibleAWTComponent::addFocusListener(::java::awt::event::FocusListener* arg0)");
}

void java::awt::Component_AccessibleAWTComponent::addPropertyChangeListener(::java::beans::PropertyChangeListener* arg0)
{ /* stub */
    unimplemented_(u"void java::awt::Component_AccessibleAWTComponent::addPropertyChangeListener(::java::beans::PropertyChangeListener* arg0)");
}

bool java::awt::Component_AccessibleAWTComponent::contains(Point* arg0)
{ /* stub */
    unimplemented_(u"bool java::awt::Component_AccessibleAWTComponent::contains(Point* arg0)");
    return 0;
}

javax::accessibility::Accessible* java::awt::Component_AccessibleAWTComponent::getAccessibleAt(Point* arg0)
{ /* stub */
    unimplemented_(u"javax::accessibility::Accessible* java::awt::Component_AccessibleAWTComponent::getAccessibleAt(Point* arg0)");
    return 0;
}

javax::accessibility::Accessible* java::awt::Component_AccessibleAWTComponent::getAccessibleChild(int32_t arg0)
{ /* stub */
    unimplemented_(u"javax::accessibility::Accessible* java::awt::Component_AccessibleAWTComponent::getAccessibleChild(int32_t arg0)");
    return 0;
}

int32_t java::awt::Component_AccessibleAWTComponent::getAccessibleChildrenCount()
{ /* stub */
    unimplemented_(u"int32_t java::awt::Component_AccessibleAWTComponent::getAccessibleChildrenCount()");
    return 0;
}

javax::accessibility::AccessibleComponent* java::awt::Component_AccessibleAWTComponent::getAccessibleComponent()
{ /* stub */
    unimplemented_(u"javax::accessibility::AccessibleComponent* java::awt::Component_AccessibleAWTComponent::getAccessibleComponent()");
    return 0;
}

java::lang::String* java::awt::Component_AccessibleAWTComponent::getAccessibleDescription()
{ /* stub */
    unimplemented_(u"java::lang::String* java::awt::Component_AccessibleAWTComponent::getAccessibleDescription()");
    return 0;
}

int32_t java::awt::Component_AccessibleAWTComponent::getAccessibleIndexInParent()
{ /* stub */
    unimplemented_(u"int32_t java::awt::Component_AccessibleAWTComponent::getAccessibleIndexInParent()");
    return 0;
}

java::lang::String* java::awt::Component_AccessibleAWTComponent::getAccessibleName()
{ /* stub */
    unimplemented_(u"java::lang::String* java::awt::Component_AccessibleAWTComponent::getAccessibleName()");
    return 0;
}

javax::accessibility::Accessible* java::awt::Component_AccessibleAWTComponent::getAccessibleParent()
{ /* stub */
    unimplemented_(u"javax::accessibility::Accessible* java::awt::Component_AccessibleAWTComponent::getAccessibleParent()");
    return 0;
}

javax::accessibility::AccessibleRole* java::awt::Component_AccessibleAWTComponent::getAccessibleRole()
{ /* stub */
    unimplemented_(u"javax::accessibility::AccessibleRole* java::awt::Component_AccessibleAWTComponent::getAccessibleRole()");
    return 0;
}

javax::accessibility::AccessibleStateSet* java::awt::Component_AccessibleAWTComponent::getAccessibleStateSet()
{ /* stub */
    unimplemented_(u"javax::accessibility::AccessibleStateSet* java::awt::Component_AccessibleAWTComponent::getAccessibleStateSet()");
    return 0;
}

java::awt::Color* java::awt::Component_AccessibleAWTComponent::getBackground()
{ /* stub */
    unimplemented_(u"java::awt::Color* java::awt::Component_AccessibleAWTComponent::getBackground()");
    return 0;
}

java::awt::Rectangle* java::awt::Component_AccessibleAWTComponent::getBounds()
{ /* stub */
    unimplemented_(u"java::awt::Rectangle* java::awt::Component_AccessibleAWTComponent::getBounds()");
    return 0;
}

java::awt::Cursor* java::awt::Component_AccessibleAWTComponent::getCursor()
{ /* stub */
    unimplemented_(u"java::awt::Cursor* java::awt::Component_AccessibleAWTComponent::getCursor()");
    return 0;
}

java::awt::Font* java::awt::Component_AccessibleAWTComponent::getFont()
{ /* stub */
    unimplemented_(u"java::awt::Font* java::awt::Component_AccessibleAWTComponent::getFont()");
    return 0;
}

java::awt::FontMetrics* java::awt::Component_AccessibleAWTComponent::getFontMetrics(Font* arg0)
{ /* stub */
    unimplemented_(u"java::awt::FontMetrics* java::awt::Component_AccessibleAWTComponent::getFontMetrics(Font* arg0)");
    return 0;
}

java::awt::Color* java::awt::Component_AccessibleAWTComponent::getForeground()
{ /* stub */
    unimplemented_(u"java::awt::Color* java::awt::Component_AccessibleAWTComponent::getForeground()");
    return 0;
}

java::util::Locale* java::awt::Component_AccessibleAWTComponent::getLocale()
{ /* stub */
    unimplemented_(u"java::util::Locale* java::awt::Component_AccessibleAWTComponent::getLocale()");
    return 0;
}

java::awt::Point* java::awt::Component_AccessibleAWTComponent::getLocation()
{ /* stub */
    unimplemented_(u"java::awt::Point* java::awt::Component_AccessibleAWTComponent::getLocation()");
    return 0;
}

java::awt::Point* java::awt::Component_AccessibleAWTComponent::getLocationOnScreen()
{ /* stub */
    unimplemented_(u"java::awt::Point* java::awt::Component_AccessibleAWTComponent::getLocationOnScreen()");
    return 0;
}

java::awt::Dimension* java::awt::Component_AccessibleAWTComponent::getSize()
{ /* stub */
    unimplemented_(u"java::awt::Dimension* java::awt::Component_AccessibleAWTComponent::getSize()");
    return 0;
}

bool java::awt::Component_AccessibleAWTComponent::isEnabled()
{ /* stub */
    unimplemented_(u"bool java::awt::Component_AccessibleAWTComponent::isEnabled()");
    return 0;
}

bool java::awt::Component_AccessibleAWTComponent::isFocusTraversable()
{ /* stub */
    unimplemented_(u"bool java::awt::Component_AccessibleAWTComponent::isFocusTraversable()");
    return 0;
}

bool java::awt::Component_AccessibleAWTComponent::isShowing()
{ /* stub */
    unimplemented_(u"bool java::awt::Component_AccessibleAWTComponent::isShowing()");
    return 0;
}

bool java::awt::Component_AccessibleAWTComponent::isVisible()
{ /* stub */
    unimplemented_(u"bool java::awt::Component_AccessibleAWTComponent::isVisible()");
    return 0;
}

void java::awt::Component_AccessibleAWTComponent::removeFocusListener(::java::awt::event::FocusListener* arg0)
{ /* stub */
    unimplemented_(u"void java::awt::Component_AccessibleAWTComponent::removeFocusListener(::java::awt::event::FocusListener* arg0)");
}

void java::awt::Component_AccessibleAWTComponent::removePropertyChangeListener(::java::beans::PropertyChangeListener* listener)
{ /* stub */
    unimplemented_(u"void java::awt::Component_AccessibleAWTComponent::removePropertyChangeListener(::java::beans::PropertyChangeListener* listener)");
}

void java::awt::Component_AccessibleAWTComponent::requestFocus()
{ /* stub */
    unimplemented_(u"void java::awt::Component_AccessibleAWTComponent::requestFocus()");
}

void java::awt::Component_AccessibleAWTComponent::setBackground(Color* c)
{ /* stub */
    unimplemented_(u"void java::awt::Component_AccessibleAWTComponent::setBackground(Color* c)");
}

void java::awt::Component_AccessibleAWTComponent::setBounds(Rectangle* r)
{ /* stub */
    unimplemented_(u"void java::awt::Component_AccessibleAWTComponent::setBounds(Rectangle* r)");
}

void java::awt::Component_AccessibleAWTComponent::setCursor(Cursor* cursor)
{ /* stub */
    unimplemented_(u"void java::awt::Component_AccessibleAWTComponent::setCursor(Cursor* cursor)");
}

void java::awt::Component_AccessibleAWTComponent::setEnabled(bool b)
{ /* stub */
    unimplemented_(u"void java::awt::Component_AccessibleAWTComponent::setEnabled(bool b)");
}

void java::awt::Component_AccessibleAWTComponent::setFont(Font* f)
{ /* stub */
    unimplemented_(u"void java::awt::Component_AccessibleAWTComponent::setFont(Font* f)");
}

void java::awt::Component_AccessibleAWTComponent::setForeground(Color* c)
{ /* stub */
    unimplemented_(u"void java::awt::Component_AccessibleAWTComponent::setForeground(Color* c)");
}

void java::awt::Component_AccessibleAWTComponent::setLocation(Point* p)
{ /* stub */
    unimplemented_(u"void java::awt::Component_AccessibleAWTComponent::setLocation(Point* p)");
}

void java::awt::Component_AccessibleAWTComponent::setSize(Dimension* d)
{ /* stub */
    unimplemented_(u"void java::awt::Component_AccessibleAWTComponent::setSize(Dimension* d)");
}

void java::awt::Component_AccessibleAWTComponent::setVisible(bool b)
{ /* stub */
    unimplemented_(u"void java::awt::Component_AccessibleAWTComponent::setVisible(bool b)");
}

extern java::lang::Class *class_(const char16_t *c, int n);

java::lang::Class* java::awt::Component_AccessibleAWTComponent::class_()
{
    static ::java::lang::Class* c = ::class_(u"java.awt.Component.AccessibleAWTComponent", 41);
    return c;
}

java::lang::Class* java::awt::Component_AccessibleAWTComponent::getClass0()
{
    return class_();
}

