// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar
#include <java/awt/Component_AWTTreeLock.hpp>

extern void unimplemented_(const char16_t* name);
java::awt::Component_AWTTreeLock::Component_AWTTreeLock(const ::default_init_tag&)
    : super(*static_cast< ::default_init_tag* >(0))
{
    clinit();
}

java::awt::Component_AWTTreeLock::Component_AWTTreeLock()
    : Component_AWTTreeLock(*static_cast< ::default_init_tag* >(0))
{
    ctor();
}


void ::java::awt::Component_AWTTreeLock::ctor()
{ /* stub */
    /* super::ctor(); */
    unimplemented_(u"void ::java::awt::Component_AWTTreeLock::ctor()");
}

extern java::lang::Class *class_(const char16_t *c, int n);

java::lang::Class* java::awt::Component_AWTTreeLock::class_()
{
    static ::java::lang::Class* c = ::class_(u"java.awt.Component.AWTTreeLock", 30);
    return c;
}

java::lang::Class* java::awt::Component_AWTTreeLock::getClass0()
{
    return class_();
}

