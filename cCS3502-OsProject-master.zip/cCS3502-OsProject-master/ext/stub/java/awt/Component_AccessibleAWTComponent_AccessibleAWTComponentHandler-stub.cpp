// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar
#include <java/awt/Component_AccessibleAWTComponent_AccessibleAWTComponentHandler.hpp>

#include <java/awt/Component_AccessibleAWTComponent.hpp>

extern void unimplemented_(const char16_t* name);
java::awt::Component_AccessibleAWTComponent_AccessibleAWTComponentHandler::Component_AccessibleAWTComponent_AccessibleAWTComponentHandler(Component_AccessibleAWTComponent *Component_AccessibleAWTComponent_this, const ::default_init_tag&)
    : super(*static_cast< ::default_init_tag* >(0))
    , Component_AccessibleAWTComponent_this(Component_AccessibleAWTComponent_this)
{
    clinit();
}

java::awt::Component_AccessibleAWTComponent_AccessibleAWTComponentHandler::Component_AccessibleAWTComponent_AccessibleAWTComponentHandler(Component_AccessibleAWTComponent *Component_AccessibleAWTComponent_this)
    : Component_AccessibleAWTComponent_AccessibleAWTComponentHandler(Component_AccessibleAWTComponent_this, *static_cast< ::default_init_tag* >(0))
{
    ctor();
}


void ::java::awt::Component_AccessibleAWTComponent_AccessibleAWTComponentHandler::ctor()
{ /* stub */
    /* super::ctor(); */
    unimplemented_(u"void ::java::awt::Component_AccessibleAWTComponent_AccessibleAWTComponentHandler::ctor()");
}

void java::awt::Component_AccessibleAWTComponent_AccessibleAWTComponentHandler::componentHidden(::java::awt::event::ComponentEvent* e)
{ /* stub */
    unimplemented_(u"void java::awt::Component_AccessibleAWTComponent_AccessibleAWTComponentHandler::componentHidden(::java::awt::event::ComponentEvent* e)");
}

void java::awt::Component_AccessibleAWTComponent_AccessibleAWTComponentHandler::componentMoved(::java::awt::event::ComponentEvent* e)
{ /* stub */
    unimplemented_(u"void java::awt::Component_AccessibleAWTComponent_AccessibleAWTComponentHandler::componentMoved(::java::awt::event::ComponentEvent* e)");
}

void java::awt::Component_AccessibleAWTComponent_AccessibleAWTComponentHandler::componentResized(::java::awt::event::ComponentEvent* e)
{ /* stub */
    unimplemented_(u"void java::awt::Component_AccessibleAWTComponent_AccessibleAWTComponentHandler::componentResized(::java::awt::event::ComponentEvent* e)");
}

void java::awt::Component_AccessibleAWTComponent_AccessibleAWTComponentHandler::componentShown(::java::awt::event::ComponentEvent* e)
{ /* stub */
    unimplemented_(u"void java::awt::Component_AccessibleAWTComponent_AccessibleAWTComponentHandler::componentShown(::java::awt::event::ComponentEvent* e)");
}

extern java::lang::Class *class_(const char16_t *c, int n);

java::lang::Class* java::awt::Component_AccessibleAWTComponent_AccessibleAWTComponentHandler::class_()
{
    static ::java::lang::Class* c = ::class_(u"java.awt.Component.AccessibleAWTComponent.AccessibleAWTComponentHandler", 71);
    return c;
}

java::lang::Class* java::awt::Component_AccessibleAWTComponent_AccessibleAWTComponentHandler::getClass0()
{
    return class_();
}

