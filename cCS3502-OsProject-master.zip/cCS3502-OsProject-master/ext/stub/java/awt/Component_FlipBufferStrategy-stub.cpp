// Generated from C:/Program Files/Java/jre1.8.0_121/lib/rt.jar
#include <java/awt/Component_FlipBufferStrategy.hpp>

#include <java/awt/Component.hpp>

extern void unimplemented_(const char16_t* name);
java::awt::Component_FlipBufferStrategy::Component_FlipBufferStrategy(Component *Component_this, const ::default_init_tag&)
    : super(*static_cast< ::default_init_tag* >(0))
    , Component_this(Component_this)
{
    clinit();
}

java::awt::Component_FlipBufferStrategy::Component_FlipBufferStrategy(Component *Component_this, int32_t arg0, BufferCapabilities* arg1)
    : Component_FlipBufferStrategy(Component_this, *static_cast< ::default_init_tag* >(0))
{
    ctor(arg0, arg1);
}


void ::java::awt::Component_FlipBufferStrategy::ctor(int32_t arg0, BufferCapabilities* arg1)
{ /* stub */
    /* super::ctor(); */
    unimplemented_(u"void ::java::awt::Component_FlipBufferStrategy::ctor(int32_t arg0, BufferCapabilities* arg1)");
}

bool java::awt::Component_FlipBufferStrategy::contentsLost()
{ /* stub */
    unimplemented_(u"bool java::awt::Component_FlipBufferStrategy::contentsLost()");
    return 0;
}

bool java::awt::Component_FlipBufferStrategy::contentsRestored()
{ /* stub */
    unimplemented_(u"bool java::awt::Component_FlipBufferStrategy::contentsRestored()");
    return 0;
}

void java::awt::Component_FlipBufferStrategy::createBuffers(int32_t numBuffers, BufferCapabilities* caps)
{ /* stub */
    unimplemented_(u"void java::awt::Component_FlipBufferStrategy::createBuffers(int32_t numBuffers, BufferCapabilities* caps)");
}

void java::awt::Component_FlipBufferStrategy::destroyBuffers()
{ /* stub */
    unimplemented_(u"void java::awt::Component_FlipBufferStrategy::destroyBuffers()");
}

void java::awt::Component_FlipBufferStrategy::dispose()
{ /* stub */
    unimplemented_(u"void java::awt::Component_FlipBufferStrategy::dispose()");
}

void java::awt::Component_FlipBufferStrategy::flip(BufferCapabilities_FlipContents* flipAction)
{ /* stub */
    unimplemented_(u"void java::awt::Component_FlipBufferStrategy::flip(BufferCapabilities_FlipContents* flipAction)");
}

void java::awt::Component_FlipBufferStrategy::flipSubRegion(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3, BufferCapabilities_FlipContents* arg4)
{ /* stub */
    unimplemented_(u"void java::awt::Component_FlipBufferStrategy::flipSubRegion(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3, BufferCapabilities_FlipContents* arg4)");
}

java::awt::Image* java::awt::Component_FlipBufferStrategy::getBackBuffer()
{ /* stub */
    unimplemented_(u"java::awt::Image* java::awt::Component_FlipBufferStrategy::getBackBuffer()");
    return 0;
}

java::awt::BufferCapabilities* java::awt::Component_FlipBufferStrategy::getCapabilities()
{ /* stub */
    unimplemented_(u"java::awt::BufferCapabilities* java::awt::Component_FlipBufferStrategy::getCapabilities()");
    return 0;
}

java::awt::Graphics* java::awt::Component_FlipBufferStrategy::getDrawGraphics()
{ /* stub */
    unimplemented_(u"java::awt::Graphics* java::awt::Component_FlipBufferStrategy::getDrawGraphics()");
    return 0;
}

void java::awt::Component_FlipBufferStrategy::revalidate()
{ /* stub */
    unimplemented_(u"void java::awt::Component_FlipBufferStrategy::revalidate()");
}

void java::awt::Component_FlipBufferStrategy::revalidate(bool arg0)
{ /* stub */
    unimplemented_(u"void java::awt::Component_FlipBufferStrategy::revalidate(bool arg0)");
}

void java::awt::Component_FlipBufferStrategy::show()
{ /* stub */
    unimplemented_(u"void java::awt::Component_FlipBufferStrategy::show()");
}

void java::awt::Component_FlipBufferStrategy::showSubRegion(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3)
{ /* stub */
    unimplemented_(u"void java::awt::Component_FlipBufferStrategy::showSubRegion(int32_t arg0, int32_t arg1, int32_t arg2, int32_t arg3)");
}

/* private: void java::awt::Component_FlipBufferStrategy::updateInternalBuffers() */
extern java::lang::Class *class_(const char16_t *c, int n);

java::lang::Class* java::awt::Component_FlipBufferStrategy::class_()
{
    static ::java::lang::Class* c = ::class_(u"java.awt.Component.FlipBufferStrategy", 37);
    return c;
}

java::lang::Class* java::awt::Component_FlipBufferStrategy::getClass0()
{
    return class_();
}

